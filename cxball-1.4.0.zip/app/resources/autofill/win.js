// win.js —— 调整宿主（CxBall.Shell，WPF + WebView2）窗口大小
//
// 宿主没有暴露改窗口尺寸的接口，所以这里从外部用 user32 的 SetWindowPos 调整：
// 面板窗与悬浮球窗都是无标题栏的顶层窗口，WPF 会跟随 WM_SIZE 重排，实测不会回弹。
// 面板放大后网页视口同比例变大，前端再把页面 zoom 设成「窗口宽 / 400」，整体就等比放大。
//
// 两个窗口标题都叫「学习通悬浮球」，靠扩展样式区分：
//   面板 = WS_EX_APPWINDOW(0x40000)，无分层
//   悬浮球 = WS_EX_LAYERED(0x80000)（透明+置顶）
// 不能用尺寸判断：面板缩到最小时会比球还窄，会把面板当球改成 64x64 搞坏布局。
//
// C# 帮助类编译一次缓存成 dll（%TEMP%\cxball-win.dll），以后只 Add-Type -Path，省掉编译开销。

const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const DLL = path.join(os.tmpdir(), "cxball-win.dll");
const SRC = path.join(os.tmpdir(), "cxball-win.cs");
const WIN_TITLE = "学习通悬浮球";

// 宿主面板默认 400x640（WPF 逻辑尺寸），前端的 zoom 就是以这个宽度为基准
const BASE_W = 400;
const BASE_H = 640;

const CS = `using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

public class CxBallWin
{
    public struct RECT { public int L, T, R, B; }
    public struct MI { public int cbSize; public RECT mon; public RECT work; public uint flags; }
    public delegate bool EnumProc(IntPtr h, IntPtr l);

    [DllImport("user32.dll")] static extern bool EnumWindows(EnumProc p, IntPtr l);
    [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern int GetClassName(IntPtr h, StringBuilder s, int n);
    [DllImport("user32.dll")] static extern int GetWindowLong(IntPtr h, int i);
    [DllImport("user32.dll")] static extern bool SetWindowPos(IntPtr h, IntPtr a, int x, int y, int cx, int cy, uint f);
    [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr h, uint f);
    [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr m, ref MI mi);

    const int EX_APPWINDOW = 0x00040000;
    const int EX_LAYERED = 0x00080000;

    // 返回 [面板句柄, 悬浮球句柄]，找不到给 0。
    // 同标题的窗口不止一个（WPF 还有 157x25 这类移屏隐藏的辅助窗），
    // 所以额外跳过离屏的，并在同类里取面积最大的那个。
    public static IntPtr[] Find()
    {
        IntPtr[] found = new IntPtr[2] { IntPtr.Zero, IntPtr.Zero };
        int[] area = new int[2] { 0, 0 };
        EnumWindows(delegate(IntPtr h, IntPtr l)
        {
            var t = new StringBuilder(256);
            GetWindowText(h, t, 256);
            if (t.ToString().IndexOf("${WIN_TITLE}", StringComparison.Ordinal) < 0) return true;
            var c = new StringBuilder(256);
            GetClassName(h, c, 256);
            if (c.ToString().IndexOf("HwndWrapper", StringComparison.Ordinal) < 0) return true;
            RECT r;
            GetWindowRect(h, out r);
            int w = r.R - r.L, ht = r.B - r.T;
            if (w < 30 || ht < 20) return true;
            if (r.L < -5000 || r.T < -5000) return true;
            int a = w * ht;
            int ex = GetWindowLong(h, -20);
            if ((ex & EX_LAYERED) != 0) { if (a > area[1]) { area[1] = a; found[1] = h; } }
            else if ((ex & EX_APPWINDOW) != 0) { if (a > area[0]) { area[0] = a; found[0] = h; } }
            return true;
        }, IntPtr.Zero);
        return found;
    }

    public static int W(IntPtr h) { RECT r; GetWindowRect(h, out r); return r.R - r.L; }
    public static int H(IntPtr h) { RECT r; GetWindowRect(h, out r); return r.B - r.T; }

    // 以窗口中心为基准改尺寸。工作区数据异常时（某些远程桌面/多屏会返回 0）不夹取，
    // 免得把窗口设成 0x0 被系统压成最小尺寸。
    public static int[] Resize(IntPtr h, int w, int ht)
    {
        if (h == IntPtr.Zero) return new int[] { 0, 0 };
        if (w < 60) w = 60;
        if (ht < 60) ht = 60;

        RECT r;
        GetWindowRect(h, out r);
        int oldW = r.R - r.L, oldH = r.B - r.T;
        int cx = (r.L + r.R) / 2, cy = (r.T + r.B) / 2;

        var mi = new MI();
        mi.cbSize = Marshal.SizeOf(typeof(MI));
        IntPtr mon = MonitorFromWindow(h, 2);
        bool has = mon != IntPtr.Zero && GetMonitorInfo(mon, ref mi);
        int maxW = mi.work.R - mi.work.L, maxH = mi.work.B - mi.work.T;
        bool ok = has && maxW > 200 && maxH > 200;

        if (ok)
        {
            if (w > maxW) w = maxW;
            if (ht > maxH) ht = maxH;
        }

        int x = cx - w / 2, y = cy - ht / 2;
        if (ok)
        {
            int minX = mi.work.L, maxX = mi.work.R - w;
            int minY = mi.work.T, maxY = mi.work.B - ht;
            if (maxX < minX) maxX = minX;
            if (maxY < minY) maxY = minY;
            if (x < minX) x = minX;
            if (x > maxX) x = maxX;
            if (y < minY) y = minY;
            if (y > maxY) y = maxY;
        }
        SetWindowPos(h, IntPtr.Zero, x, y, w, ht, 0x0014);

        // 回读校验：尺寸被系统改成奇怪值就退回原尺寸，避免窗口被压成一条
        int nowW = W(h), nowH = H(h);
        if (nowW < 100 || nowH < 100)
        {
            SetWindowPos(h, IntPtr.Zero, r.L, r.T, oldW, oldH, 0x0014);
            nowW = W(h);
            nowH = H(h);
        }
        return new int[] { nowW, nowH };
    }
}
`;

function ps(script, timeoutMs = 20000) {
  return new Promise((resolve) => {
    const b64 = Buffer.from(script, "utf16le").toString("base64");
    const p = spawn("powershell.exe", ["-NoProfile", "-NonInteractive", "-EncodedCommand", b64], {
      windowsHide: true,
    });
    let out = "";
    const timer = setTimeout(() => { try { p.kill(); } catch {} resolve(""); }, timeoutMs);
    p.stdout.on("data", (d) => (out += d.toString("utf8")));
    p.on("error", () => { clearTimeout(timer); resolve(""); });
    p.on("close", () => { clearTimeout(timer); resolve(out.trim()); });
  });
}

let compiling = null;

/// 确保帮助类 dll 可用（首次编译，之后复用缓存）
async function ensureDll() {
  try {
    if (fs.existsSync(DLL) && fs.statSync(DLL).size > 0) return true;
  } catch {}
  if (compiling) return compiling;
  compiling = (async () => {
    try {
      try { fs.unlinkSync(DLL); } catch {}
      fs.writeFileSync(SRC, CS, "utf8");
      await ps(
        `[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
Add-Type -TypeDefinition (Get-Content -LiteralPath '${SRC}' -Raw -Encoding UTF8) -OutputAssembly '${DLL}' -OutputType Library -ErrorAction Stop
'OK'`,
        90000,
      );
      return fs.existsSync(DLL) && fs.statSync(DLL).size > 0;
    } catch {
      return false;
    } finally {
      compiling = null;
    }
  })();
  return compiling;
}

const PRELUDE = `[Console]::OutputEncoding=[System.Text.Encoding]::UTF8
Add-Type -Path '${DLL}' -ErrorAction Stop
$w = [CxBallWin]::Find()
$panel = $w[0]; $ball = $w[1]
`;

/// 取当前面板与悬浮球的窗口尺寸。
/// 面板关掉时宿主会把它挪到屏幕外并压成很小一块，Find() 会跳过它 → panelW 返回 0，
/// 前端据此判断「窗口不在，别动页面比例」。found 是这个判断的显式标记。
async function state() {
  if (!(await ensureDll())) throw new Error("初始化窗口控制失败");
  const out = await ps(`${PRELUDE}
"$([CxBallWin]::W($panel)),$([CxBallWin]::W($ball))"
`);
  if (!out) throw new Error("找不到悬浮球窗口（程序可能已退出）");
  const [pw, bw] = out.split(",").map((v) => parseInt(v, 10) || 0);
  return { found: pw > 0, panelW: pw, ball: bw, baseW: BASE_W, baseH: BASE_H };
}

/// 应用尺寸：scale 为面板缩放（0.85~1.35）。
/// 悬浮球不在这里改尺寸——宿主按固定尺寸（128）排版球里的图标，硬改窗口只会把图标裁掉一块，
/// 之前「球只有左上角」就是这个原因。ball 参数保留只为兼容旧调用，值忽略。
async function apply({ scale }) {
  const s = Math.min(1.35, Math.max(0.85, Number(scale) || 1));
  const w = Math.round(BASE_W * s);
  const h = Math.round(BASE_H * s);

  if (!(await ensureDll())) throw new Error("初始化窗口控制失败");
  const out = await ps(`${PRELUDE}
if ($panel -eq [IntPtr]::Zero) { 'NONE'; exit }
$pr = [CxBallWin]::Resize($panel, ${w}, ${h})
"OK $($pr[0]) $($pr[1])"
`);
  if (!out || out.includes("NONE")) throw new Error("找不到悬浮球窗口（程序可能已退出）");
  const nums = (out.match(/OK\s+(\d+)\s+(\d+)/) || []).slice(1).map((v) => parseInt(v, 10));
  // panelW 为 0 表示面板此刻是关着的（窗口被宿主挪走），不能编一个值回去骗前端
  const pw = nums[0] || 0, ph = nums[1] || 0;
  return { ok: pw > 0, found: pw > 0, scale: s, panelW: pw, panelH: ph };
}

module.exports = { state, apply, BASE_W, BASE_H };
