param([string]$Base = "")

# fix-setup.ps1 -- prepare the WebView2 debug port before the floating ball starts.
#
# Why this exists:
#   AI answering needs to read the homework page through WebView2's debug port (9223).
#   The port is only opened if the WebView2 *browser process* is started with
#   WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS=--remote-debugging-port=9223.
#   Once a browser process for our user-data-dir is alive, every later start just
#   attaches to it and never re-reads the variable -- so a single "bad" start
#   poisons every start after it. Hence: make sure the variable is persisted, and
#   make sure no leftover browser process survives before we launch again.
#
# All output is ASCII on purpose: PowerShell 5.1 reads BOM-less files as ANSI,
# so non-ASCII text here would be mangled on some machines.

$ErrorActionPreference = 'SilentlyContinue'

if (-not $Base) { $Base = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) }
$root = $Base.TrimEnd('\')
if (-not $root) { exit 1 }

$logDir = Join-Path $root 'data\logs'
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$logFile = Join-Path $logDir 'startup.log'

function Log([string]$msg) {
  try {
    $line = ('[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg)
    Add-Content -LiteralPath $logFile -Value $line -Encoding UTF8
  } catch { }
}

Log ("fix-setup start, root=" + $root)

# ---- 1. persist the WebView2 argument in the user environment -------------
$name = 'WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS'
$flag = '--remote-debugging-port=9223'
try {
  $cur = [Environment]::GetEnvironmentVariable($name, 'User')
  if (-not $cur) {
    [Environment]::SetEnvironmentVariable($name, $flag, 'User')
    Log "env: created"
  }
  elseif ($cur -notmatch 'remote-debugging-port') {
    [Environment]::SetEnvironmentVariable($name, ($cur.Trim() + ' ' + $flag), 'User')
    Log ("env: appended -> " + $cur.Trim() + ' ' + $flag)
  }
  else {
    Log "env: already ok"
  }
} catch { Log ("env: failed " + $_.Exception.Message) }

# ---- 2. helpers ------------------------------------------------------------
function OurProcesses {
  Get-CimInstance Win32_Process -Filter "Name='launcher.exe' or Name='msedgewebview2.exe'" |
    Where-Object {
      ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) -or
      ($_.CommandLine  -and $_.CommandLine.IndexOf($root, [StringComparison]::OrdinalIgnoreCase) -ge 0)
    }
}

# ---- 3. kill leftovers that hold the browser profile ----------------------
$procs = @(OurProcesses)
if ($procs.Count -gt 0) {
  Log ("kill: " + (($procs | ForEach-Object { "$($_.Name)#$($_.ProcessId)" }) -join ', '))
  $procs | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
}
else {
  Log "kill: nothing to kill"
}

# ---- 4. wait until they are really gone (max ~8s) -------------------------
$gone = $false
for ($i = 0; $i -lt 40; $i++) {
  if (@(OurProcesses).Count -eq 0) { $gone = $true; break }
  Start-Sleep -Milliseconds 200
}
Log ("wait: gone=" + $gone)

# ---- 5. tell Explorer the environment changed (so future launches see it) --
try {
  $sig = '[DllImport("user32.dll", CharSet=CharSet.Auto, SetLastError=true)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);'
  $t = Add-Type -MemberDefinition $sig -Name 'EnvBroadcast' -Namespace 'CxBallFix' -PassThru
  [UIntPtr]$res = [UIntPtr]::Zero
  [void]$t::SendMessageTimeout([IntPtr]0xffff, 0x001A, [UIntPtr]::Zero, 'Environment', 2, 3000, [ref]$res)
} catch { }

Log "fix-setup done"
exit 0
