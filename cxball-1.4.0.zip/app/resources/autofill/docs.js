/*
 * docs.js —— 课程文档（老师上传的资料）列出与下载。
 *
 * 为什么放在本地小桥里而不是网页里：
 *   1. 学习通资料页是服务端渲染的老页面，接口返回整段 HTML，在网页端解析要跨域；
 *   2. 下载大文件（几百 MB）不能走浏览器内存，必须由本地进程直接流式落盘；
 *   3. 「选择文件夹」需要系统对话框，只有本地进程能做。
 *
 * Cookie 来源：WebView2 调试端口（Storage.getCookies），因此仍然要 9223 端口可用。
 *
 * 已探明的接口：
 *   POST https://mooc1-1.chaoxing.com/mooc-ans/visit/courselistdata   课程列表（HTML）
 *   GET  .../visit/stucoursemiddle?courseid&clazzid&cpi               302 到课程页，Location 带 enc
 *   GET  https://mooc2-ans.chaoxing.com/mooc2-ans/coursedata/stu-datalist?...&stuenc=enc   资料目录（HTML）
 *   GET  https://mooc1.chaoxing.com/coursedata/downloadData?dataId&classId&cpi&courseId&ut=s
 *        302 → https://dN.cldisk.com/download/<objectId>?at_&ak_&fn=<文件名>
 */
"use strict";

const fs = require("fs");
const path = require("path");
const os = require("os");
const { spawn } = require("child_process");
const { Readable } = require("stream");

const CDP_PORT = Number(process.env.CXBALL_CDP_PORT || 9223);
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.0.0 Safari/537.36 Edg/155.0.0.0";
const COURSE_HOST = "https://mooc1-1.chaoxing.com";
const DATA_HOST = "https://mooc2-ans.chaoxing.com";

// ---------------- Cookie（CDP） ----------------

let COOKIE = { str: "", at: 0 };

async function cookieStr(force) {
  if (!force && COOKIE.str && Date.now() - COOKIE.at < 180000) return COOKIE.str;
  let wsUrl;
  try {
    const r = await fetch(`http://127.0.0.1:${CDP_PORT}/json/version`, { signal: AbortSignal.timeout(4000) });
    if (!r.ok) throw new Error("bad status");
    wsUrl = (await r.json()).webSocketDebuggerUrl;
  } catch {
    const e = new Error("读不到学习通页面：请关掉悬浮球，从桌面图标重开一次再试");
    e.code = "CDP_DOWN";
    throw e;
  }
  const list = await new Promise((resolve, reject) => {
    const ws = new WebSocket(wsUrl);
    const timer = setTimeout(() => { try { ws.close(); } catch {} reject(new Error("读取学习通页面超时，请重开一次悬浮球")); }, 8000);
    ws.addEventListener("open", () => {
      ws.send(JSON.stringify({ id: 1, method: "Storage.getCookies", params: {} }));
    });
    ws.addEventListener("message", (ev) => {
      let m;
      try { m = JSON.parse(ev.data); } catch { return; }
      if (m.id !== 1) return;
      clearTimeout(timer);
      try { ws.close(); } catch {}
      resolve((m.result && m.result.cookies) || []);
    });
    ws.addEventListener("error", () => { clearTimeout(timer); reject(new Error("连不上学习通页面，请重开一次悬浮球")); });
  });
  const seen = new Map();
  for (const c of list) {
    if (!/chaoxing|edu\.cn|fanya/i.test(c.domain || "")) continue;
    if (!seen.has(c.name)) seen.set(c.name, c.value);
  }
  const str = [...seen].map(([k, v]) => `${k}=${v}`).join("; ");
  if (!str) {
    const e = new Error("没取到学习通登录状态，请先在悬浮球里登录");
    e.code = "NO_LOGIN";
    throw e;
  }
  COOKIE = { str, at: Date.now() };
  return str;
}

async function headers(referer) {
  return {
    "User-Agent": UA,
    Cookie: await cookieStr(),
    Referer: referer || "https://i.chaoxing.com/",
    "Accept-Language": "zh-CN,zh;q=0.9",
  };
}

const txt = (s) => String(s || "").replace(/<[^>]*>/g, "").replace(/&amp;/g, "&").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();

function decodeName(s) {
  const v = String(s || "").trim();
  if (!/%[0-9a-f]{2}/i.test(v)) return v;
  try { return decodeURIComponent(v); } catch { return v; }
}

// ---------------- 课程列表 ----------------

async function listCourses() {
  const H = await headers("https://i.chaoxing.com/");
  const r = await fetch(`${COURSE_HOST}/mooc-ans/visit/courselistdata`, {
    method: "POST",
    headers: { ...H, "Content-Type": "application/x-www-form-urlencoded" },
    body: "courseType=1&courseFolderId=0&baseEducation=0&superstarClass=&courseFolderSize=0",
  });
  const html = await r.text();
  if (/<title>\s*登录/i.test(html) || /passport2\.chaoxing\.com/.test(html)) {
    const e = new Error("登录状态已失效，请重新登录学习通");
    e.code = "NO_LOGIN";
    throw e;
  }
  const out = [];
  const re = /<li class="course clearfix"[^>]*courseId="(\d+)"[^>]*clazzId="(\d+)"[^>]*personId="(\d+)"[\s\S]*?<span class="course-name[^"]*"\s+title="([^"]*)"/g;
  let m;
  while ((m = re.exec(html))) {
    const name = decodeName(m[4]);
    if (out.some((c) => c.courseId === m[1] && c.clazzId === m[2])) continue;
    out.push({ courseId: m[1], clazzId: m[2], cpi: m[3], name });
  }
  return out;
}

// ---------------- 目录浏览 ----------------

const ENC = new Map(); // courseId_clazzId -> {enc, t, at}

async function courseEnc(c) {
  const key = `${c.courseId}_${c.clazzId}`;
  const hit = ENC.get(key);
  if (hit && Date.now() - hit.at < 120000) return hit;
  const H = await headers("https://i.chaoxing.com/");
  const u = `${COURSE_HOST}/mooc-ans/visit/stucoursemiddle?courseid=${c.courseId}&clazzid=${c.clazzId}&vc=1&cpi=${c.cpi}&ismooc2=1&v=2`;
  const r = await fetch(u, { headers: H, redirect: "manual" });
  const loc = r.headers.get("location") || "";
  if (/passport|login/i.test(loc)) {
    const e = new Error("登录状态已失效，请重新登录学习通");
    e.code = "NO_LOGIN";
    throw e;
  }
  let enc = (loc.match(/enc=([0-9a-f]+)/i) || [])[1] || "";
  let t = (loc.match(/[?&]t=(\d+)/) || [])[1] || String(Date.now());
  if (!enc) {
    const html = await r.text();
    enc = (html.match(/stuenc=([0-9a-f]+)/i) || [])[1] || (html.match(/name="enc"\s+value="([0-9a-f]+)"/i) || [])[1] || "";
  }
  if (!enc) {
    const e = new Error("这门课拿不到访问凭证（可能已结课或未开放资料）");
    e.code = "NO_ENC";
    throw e;
  }
  const v = { enc, t, at: Date.now() };
  ENC.set(key, v);
  return v;
}

function parseItems(html, isRoot) {
  const parts = html.split(/<ul\b[^>]*class="dataBody_td"/i).slice(1);
  const items = [];
  for (const p of parts) {
    const head = p.slice(0, 700);
    const type = (head.match(/\btype="([^"]*)"/i) || [])[1] || "";
    const id = (head.match(/\bid="([^"]*)"/i) || [])[1] || "";
    const name = decodeName((head.match(/\bdataName="([^"]*)"/i) || [])[1] || "");
    if (!id && !/courseware/i.test(type)) continue;
    if (/^tch-courseware$/i.test(type)) {
      // 子目录页面里也有这段模板，只有根目录才是真的「教师课件」入口
      if (!isRoot) continue;
      items.push({ id: "", name: name || "教师课件", type: "courseware", folder: true, online: true, size: "", owner: "", time: "" });
      continue;
    }
    if (!name) continue;
    const size = txt((p.match(/class="dataBody_size_stu"[^>]*>([\s\S]*?)<\/li>/i) || [])[1]);
    const owner = txt((p.match(/class="dataBody_creater_stu"[^>]*>([\s\S]*?)<\/li>/i) || [])[1]);
    const time = txt((p.match(/class="dataBody_time_stu"[^>]*>([\s\S]*?)<\/li>/i) || [])[1]);
    const folder = /^afolder$/i.test(type);
    items.push({
      id,
      name,
      type,
      folder,
      online: false,
      size: folder ? "" : size,
      owner: folder ? "" : owner,
      time,
    });
  }
  return items;
}

/**
 * 列出某门课某个目录。
 * @param {object} p {courseId, clazzId, cpi, folderId, folderName, parentId}
 */
async function listDir(p) {
  const c = { courseId: String(p.courseId || ""), clazzId: String(p.clazzId || ""), cpi: String(p.cpi || "0") };
  if (!c.courseId || !c.clazzId) throw new Error("缺少课程参数");
  const { enc, t } = await courseEnc(c);
  const H = await headers(`${DATA_HOST}/mooc2-ans/coursedata/stu-datalist`);

  let url;
  if (p.folderId) {
    const pageEnc = (p.enc || "").trim();
    url =
      `${DATA_HOST}/mooc2-ans/coursedata/stu-datalist?courseid=${c.courseId}` +
      `&dataName=${encodeURIComponent(p.folderName || "")}&dataId=${encodeURIComponent(p.folderId)}` +
      `&type=1&parent=${encodeURIComponent(p.parentId || "")}&flag=0` +
      `&clazzid=${c.clazzId}&enc=${encodeURIComponent(pageEnc)}&ut=s&cpi=${c.cpi}&t=${t}&microTopicId=0&isAjax`;
  } else {
    url = `${DATA_HOST}/mooc2-ans/coursedata/stu-datalist?courseid=${c.courseId}&clazzid=${c.clazzId}&cpi=${c.cpi}&ut=s&t=${t}&stuenc=${enc}`;
  }
  const r = await fetch(url, { headers: { ...H, Referer: url } });
  const html = await r.text();
  if (/passport2\.chaoxing\.com|请输入手机号|登录页/i.test(html.slice(0, 3000))) {
    const e = new Error("登录状态已失效，请重新登录学习通");
    e.code = "NO_LOGIN";
    throw e;
  }
  // 子目录页也带一份 enc，用来继续下钻
  const pageEnc =
    (html.match(/name="enc"\s+value="([0-9a-f]+)"/i) || [])[1] ||
    (html.match(/from"\s+value="[^"]*?_([0-9a-f]{20,})"/i) || [])[1] ||
    (p.enc || "");
  const items = parseItems(html, !p.folderId);
  const total = Number((html.match(/当前页共\s*([\d,]+)\s*个/) || html.match(/共\s*([\d,]+)\s*个/) || [])[1] || items.length) || items.length;
  items.sort((a, b) => (b.folder ? 1 : 0) - (a.folder ? 1 : 0));
  return { items, total, enc: pageEnc, courseId: c.courseId, clazzId: c.clazzId, cpi: c.cpi };
}

// ---------------- 下载 ----------------

const TASKS = new Map();
let TASK_SEQ = 0;

function safeName(s) {
  let v = String(s || "")
    .replace(/[\\/:*?"<>|\r\n\t]/g, "_")
    .replace(/^\.+/, "")
    .trim();
  if (!v) return "未命名文件";
  if (v.length > 120) {
    // 截断时保住扩展名，否则下载下来打不开
    const dot = v.lastIndexOf(".");
    const ext = dot > 0 && v.length - dot <= 12 ? v.slice(dot) : "";
    v = v.slice(0, 120 - ext.length) + ext;
  }
  return v;
}

function uniquePath(dir, name) {
  const ext = path.extname(name);
  const base = name.slice(0, name.length - ext.length);
  let p = path.join(dir, name);
  let i = 2;
  while (fs.existsSync(p)) {
    p = path.join(dir, `${base} (${i})${ext}`);
    i++;
    if (i > 999) break;
  }
  return p;
}

/// Node 的响应头按 latin1 解码，若对方直接塞 UTF-8 字节（cldisk 就是），
/// 中文文件名会变成「å®éªäº」这种乱码。这里按 latin1→utf8 还原一次。
function fixMojibake(s) {
  const v = String(s || "");
  if (!/[\u0080-\u00ff]/.test(v)) return v;
  const t = Buffer.from(v, "latin1").toString("utf8");
  return t.includes("\ufffd") ? v : t;
}

/// 把响应体流式写盘。课程资料和作业附件共用这一套（进度累计、重名加序号、空文件清理）。
async function saveStream(res, dir, fallbackName, task) {
  if (!res.ok) throw new Error(`服务器返回 ${res.status}`);

  const ct = (res.headers.get("content-type") || "").toLowerCase();
  // 有些文件（在线预览类）会返回 HTML 提示页，不能当成文件写盘
  if (ct.includes("text/html")) {
    const body = await res.text();
    const tip = (body.match(/<title>([^<]*)<\/title>/i) || [])[1] || "";
    throw new Error(`不是可下载的文件${tip ? "（" + tip + "）" : ""}`);
  }

  const cd = res.headers.get("content-disposition") || "";
  let name = fallbackName;
  const fnm = cd.match(/filename\*?=(?:UTF-8'')?["']?([^"';]+)/i);
  if (fnm) {
    let v = fnm[1].trim();
    if (/%[0-9a-f]{2}/i.test(v)) {
      try { v = decodeURIComponent(v); } catch { /* 保持原样 */ }
    } else {
      v = fixMojibake(v);
    }
    if (v) name = v;
  }
  name = safeName(name);

  fs.mkdirSync(dir, { recursive: true });
  const target = uniquePath(dir, name);

  const total = Number(res.headers.get("content-length") || 0);
  const out = fs.createWriteStream(target);
  await new Promise((resolve, reject) => {
    const src = Readable.fromWeb(res.body);
    src.on("data", (chunk) => {
      task.bytes += chunk.length;
      task.fileBytes = (task.fileBytes || 0) + chunk.length;
      if (total) task.fileTotal = total;
    });
    src.on("error", reject);
    out.on("error", reject);
    out.on("finish", resolve);
    src.pipe(out);
  });
  const size = fs.statSync(target).size;
  if (!size) {
    try { fs.unlinkSync(target); } catch {}
    throw new Error("下载到的文件是空的");
  }
  return { path: target, size, name };
}

async function downloadOne(f, dir, task) {
  const url =
    `https://mooc1.chaoxing.com/coursedata/downloadData?dataId=${encodeURIComponent(f.id)}` +
    `&classId=${encodeURIComponent(task.clazzId)}&cpi=${encodeURIComponent(task.cpi)}` +
    `&courseId=${encodeURIComponent(task.courseId)}&ut=s`;
  const H = await headers(`${DATA_HOST}/mooc2-ans/coursedata/stu-datalist`);

  let res = await fetch(url, { headers: H, redirect: "manual" });
  let finalUrl = url;
  if (res.status >= 300 && res.status < 400) {
    finalUrl = res.headers.get("location") || "";
    if (!finalUrl) throw new Error("下载地址为空（可能没有下载权限）");
    if (finalUrl.startsWith("//")) finalUrl = "https:" + finalUrl;
    // cldisk 直链只认 Referer，带上 Cookie 反而会被判 403
    res = await fetch(finalUrl, {
      headers: { "User-Agent": UA, Referer: "https://mooc1.chaoxing.com/" },
      redirect: "follow",
    });
  }

  let name = f.name;
  try {
    const fq = new URL(finalUrl).searchParams.get("fn");
    if (fq) name = fq;
  } catch {}
  const r = await saveStream(res, dir, name, task);
  return { path: r.path, size: r.size };
}

/**
 * 建下载任务。入参：
 * {courseId, clazzId, cpi, courseName, dir, relPath:[], files:[{id,name}]}
 */
function startDownload(p) {
  const dir = String(p.dir || "").trim();
  if (!dir) throw new Error("请先选择保存文件夹");
  const files = (p.files || []).filter((f) => f && f.id);
  if (!files.length) throw new Error("没有选中文件");

  const id = "d" + ++TASK_SEQ;
  const rootName = safeName(p.courseName || "课程资料");
  const flat = !!p.flat;

  const task = {
    id,
    state: "running",
    total: files.length,
    done: 0,
    failed: 0,
    current: "",
    bytes: 0,
    fileBytes: 0,
    fileTotal: 0,
    dir,
    courseId: String(p.courseId || ""),
    clazzId: String(p.clazzId || ""),
    cpi: String(p.cpi || "0"),
    flat,
    files: files.map((f) => ({
      id: String(f.id),
      name: String(f.name || ""),
      relPath: (f.relPath || []).map(safeName).filter(Boolean),
      state: "wait",
      size: 0,
      error: "",
    })),
    startedAt: Date.now(),
  };
  TASKS.set(id, task);

  (async () => {
    for (const f of task.files) {
      if (task.state === "stopped") break;
      task.current = f.name;
      task.fileBytes = 0;
      task.fileTotal = 0;
      f.state = "downloading";
      const targetDir = flat ? dir : path.join(dir, rootName, ...f.relPath);
      try {
        const r = await downloadOne(f, targetDir, task);
        f.state = "ok";
        f.size = r.size;
        f.path = r.path;
        task.done++;
        if (!task.dir || task.dir === dir) task.dir = targetDir;
      } catch (e) {
        f.state = "error";
        f.error = String(e.message || e);
        task.failed++;
      }
    }
    task.state = task.state === "stopped" ? "stopped" : "done";
    task.current = "";
    task.endedAt = Date.now();
    // 任务留一小时，够前端轮询
    setTimeout(() => TASKS.delete(id), 3600000).unref?.();
  })().catch(() => { task.state = "done"; });

  return { taskId: id, total: files.length };
}

function stopTask(id) {
  const t = TASKS.get(id);
  if (!t) return false;
  t.state = "stopped";
  return true;
}

function progress(id) {
  const t = TASKS.get(id);
  if (!t) return null;
  return {
    id: t.id,
    state: t.state,
    total: t.total,
    done: t.done,
    failed: t.failed,
    current: t.current,
    bytes: t.bytes,
    fileBytes: t.fileBytes,
    fileTotal: t.fileTotal,
    dir: t.dir,
    files: t.files.map((f) => ({ name: f.name, state: f.state, size: f.size, error: f.error })),
  };
}

// ---------------- 作业附件 ----------------
//
// 作业页里的附件不是普通链接，而是：
//   <iframe class="attach-iframe" objectid="<云盘对象 id>" filename="xx.docx" filetype="docx">
// 点开走的是「在线预览」，页面上那个下载按钮还要父级 postMessage 放行才出现，
// 所以在悬浮球的 WebView2 里点它经常什么都不发生（宿主没接管下载）。
// 这里绕开前端：直接读作业页 HTML 拿 objectid，再调 /ananas/status/<objectid>
// 取 cldisk 直链，由本地进程流式落盘。
//
// 已探明的接口：
//   GET  https://mooc1.chaoxing.com/mooc-ans/mooc2/work/task?...        作业页（HTML，含附件 iframe）
//   GET  https://mooc1.chaoxing.com/ananas/status/<objectid>            {download, filename, size, ...}
//        download 是 cldisk 直链，再拉一次即得文件本体

const STATUS_HOST = "https://mooc1.chaoxing.com";

/// HTML 实体还原（&#21016; / &quot; / &lt; 都要处理，超星文件名常带数字实体）
function decodeEnt(s) {
  return String(s || "")
    .replace(/&#x([0-9a-f]+);/gi, (_, h) => {
      const n = parseInt(h, 16);
      return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : _;
    })
    .replace(/&#(\d+);/g, (_, d) => {
      const n = parseInt(d, 10);
      return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : _;
    })
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&");
}

/// 取标签里的属性值（先还原实体，否则含 &amp; 的 href 会带进错误分隔符）
function attrOf(tag, name) {
  const m = String(tag).match(new RegExp(`\\b${name}\\s*=\\s*"([^"]*)"`, "i"));
  return m ? decodeEnt(m[1]) : "";
}

function sizeText(v) {
  const s = String(v || "").trim();
  if (!s) return "";
  if (/^[\d.]+\s*[KMGT]B?$/i.test(s)) return s.replace(/B?$/i, "B").replace(/^([\d.]+)\s*([KMGT])/i, "$1 $2");
  const n = Number(s);
  if (!Number.isFinite(n) || n <= 0) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1048576) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1073741824) return `${(n / 1048576).toFixed(1)} MB`;
  return `${(n / 1073741824).toFixed(2)} GB`;
}

/// 从一段 HTML 里抽 attach-iframe（超星云附件）
function iframesIn(html) {
  const out = [];
  const re = /<iframe\b[^>]*class\s*=\s*"[^"]*attach-iframe[^"]*"[^>]*>/gi;
  let m;
  while ((m = re.exec(html))) {
    const tag = m[0];
    let objectid = attrOf(tag, "objectid");
    let name = attrOf(tag, "filename");
    let ext = attrOf(tag, "filetype");
    let size = "";
    // name 属性是 base64(encodeURIComponent(JSON))，里面有准确的文件名和大小
    const pack = attrOf(tag, "name");
    if (pack) {
      try {
        const j = JSON.parse(decodeURIComponent(Buffer.from(pack, "base64").toString("utf8")));
        objectid = objectid || String(j.objectid || "");
        name = name || String(j.name || "");
        ext = ext || String(j.type || "");
        size = sizeText(j.size);
      } catch {
        /* 解不出来就用 filename 兜底 */
      }
    }
    if (!objectid) continue;
    if (!ext) ext = (name.split(".").pop() || "").toLowerCase();
    out.push({ id: objectid, name: name || "未命名附件", ext: ext.toLowerCase(), size });
  }
  return out;
}

/// 兜底：老版作业页把附件写成 <a href="...download...">文件名.docx</a>
function anchorsIn(html) {
  const out = [];
  const re = /<a\b[^>]*href\s*=\s*"([^"]+)"[^>]*>([\s\S]{0,160}?)<\/a>/gi;
  let m;
  while ((m = re.exec(html))) {
    const href = decodeEnt(m[1]);
    const text = txt(decodeEnt(m[2]));
    if (!href || /^javascript:/i.test(href)) continue;
    if (!/(download|attachment|\/attach)/i.test(href)) continue;
    if (!/\.[a-z0-9]{2,5}$/i.test(text)) continue;
    out.push({ id: "", href, name: text, ext: (text.split(".").pop() || "").toLowerCase(), size: "" });
  }
  return out;
}

function dedupe(list) {
  const seen = new Set();
  const out = [];
  for (const it of list) {
    const k = it.id ? "o:" + it.id : "h:" + it.href;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(it);
  }
  return out;
}

/**
 * 拆出「老师给的附件」和「我自己提交的附件」。
 * 两种页面结构都要认：
 *   未交：题干区 ... <textarea id="answerXxx">（自己草稿里也带 iframe，但是转义过的）
 *   已交：<div class="mark_item"> 一题一块，块里 <h3 class="mark_name"> 是题干、
 *         <div class="mark_answer"> 之后是「我的答案 / 正确答案」
 * 所以优先按 mark_item + mark_answer 切块，没有就退回 textarea 分割。
 */
function splitHwAttachments(html) {
  const teacher = [];
  const mine = [];
  const blocks = html.split(/<div[^>]*class\s*=\s*"[^"]*\bmark_item\b[^"]*"[^>]*>/i);
  if (blocks.length > 1) {
    // 第一块是题目列表之前的页面头部，附带的也算老师附件
    teacher.push(...iframesIn(blocks[0]), ...anchorsIn(blocks[0]));
    for (let i = 1; i < blocks.length; i++) {
      const b = blocks[i];
      const cut = b.search(/<div[^>]*class\s*=\s*"[^"]*\bmark_answer\b[^"]*"[^>]*>/i);
      const head = cut > 0 ? b.slice(0, cut) : b;
      const tail = cut > 0 ? b.slice(cut) : "";
      teacher.push(...iframesIn(head), ...anchorsIn(head));
      if (tail) mine.push(...iframesIn(decodeEnt(tail)), ...anchorsIn(decodeEnt(tail)));
    }
  } else {
    const cut = html.search(/<textarea\b/i);
    const head = cut > 0 ? html.slice(0, cut) : html;
    const tail = cut > 0 ? html.slice(cut) : "";
    teacher.push(...iframesIn(head), ...anchorsIn(head));
    // 草稿答案里的 iframe 是转义过的（&lt;iframe），还原后同样能抽出来
    if (tail) mine.push(...iframesIn(decodeEnt(tail)));
  }
  const t = dedupe(teacher);
  const m = dedupe(mine).filter((x) => !t.some((y) => y.id && y.id === x.id));
  return { teacher: t, mine: m };
}

/**
 * 读一份作业的附件清单。
 * @param {object} p {link}
 */
async function listHwAttachments(p) {
  const link = String(p.link || "").trim();
  if (!/^https?:\/\//i.test(link)) throw new Error("作业链接无效，请先刷新数据");
  if (!/chaoxing\.com|edu\.cn/i.test(link)) throw new Error("只支持学习通的作业页");

  const H = await headers(link);
  const r = await fetch(link, { headers: { ...H, Referer: "https://mooc1.chaoxing.com/" }, redirect: "follow" });
  if (!r.ok) throw new Error(`打不开作业页（${r.status}）`);
  const finalUrl = r.url || link;
  if (/passport2?\.chaoxing\.com|\/passport\//i.test(finalUrl)) {
    const e = new Error("登录状态已失效，请重新登录学习通");
    e.code = "NO_LOGIN";
    throw e;
  }
  const html = await r.text();
  if (/<title>\s*登录/i.test(html.slice(0, 2000))) {
    const e = new Error("登录状态已失效，请重新登录学习通");
    e.code = "NO_LOGIN";
    throw e;
  }

  const { teacher, mine } = splitHwAttachments(html);
  return { teacher, mine, url: finalUrl, count: teacher.length + mine.length };
}

/// 向学习通要某个云附件的直链
async function attachDirectUrl(f) {
  if (f.href) {
    return /^\/\//.test(f.href) ? "https:" + f.href : f.href;
  }
  const H = await headers(`${STATUS_HOST}/mooc-ans/mooc2/work/task`);
  const r = await fetch(`${STATUS_HOST}/ananas/status/${encodeURIComponent(f.id)}`, {
    headers: { ...H, "X-Requested-With": "XMLHttpRequest" },
  });
  if (!r.ok) throw new Error(`取下载地址失败（${r.status}）`);
  let j;
  try { j = await r.json(); } catch { throw new Error("取下载地址失败：返回内容不是 JSON"); }
  let u = String((j && j.download) || "");
  if (!u) throw new Error("老师没有开放这个附件的下载");
  if (u.startsWith("//")) u = "https:" + u;
  // 直链常是 http，页面是 https，跟着换协议免得被浏览器拦
  u = u.replace(/^http:\/\//i, "https://");
  if (!f.name && j.filename) f.name = String(j.filename);
  return u;
}

async function downloadAttach(f, dir, task) {
  const u = await attachDirectUrl(f);
  let res = await fetch(u, {
    headers: { "User-Agent": UA, Referer: "https://mooc1.chaoxing.com/" },
    redirect: "follow",
  });
  // cldisk 个别节点只认 http，https 被拒时回退一次
  if (!res.ok && /^https:\/\//i.test(u)) {
    res = await fetch(u.replace(/^https:/i, "http:"), {
      headers: { "User-Agent": UA, Referer: "https://mooc1.chaoxing.com/" },
      redirect: "follow",
    });
  }
  const r = await saveStream(res, dir, f.name || "附件", task);
  return { path: r.path, size: r.size, name: r.name };
}

/**
 * 建作业附件下载任务。入参：
 * {courseName, hwName, dir, flat, files:[{id, href, name}]}
 */
function startHwDownload(p) {
  const dir = String(p.dir || "").trim();
  if (!dir) throw new Error("请先选择保存文件夹");
  const files = (p.files || []).filter((f) => f && (f.id || f.href));
  if (!files.length) throw new Error("没有选中附件");

  const id = "h" + ++TASK_SEQ;
  const flat = !!p.flat;
  const task = {
    id,
    kind: "hw",
    state: "running",
    total: files.length,
    done: 0,
    failed: 0,
    current: "",
    bytes: 0,
    fileBytes: 0,
    fileTotal: 0,
    dir,
    flat,
    files: files.map((f) => ({
      id: String(f.id || ""),
      href: String(f.href || ""),
      name: String(f.name || ""),
      state: "wait",
      size: 0,
      error: "",
    })),
    startedAt: Date.now(),
  };
  TASKS.set(id, task);

  const root = [safeName(p.courseName || ""), safeName(p.hwName || "作业附件")].filter(Boolean);

  (async () => {
    for (const f of task.files) {
      if (task.state === "stopped") break;
      task.current = f.name;
      task.fileBytes = 0;
      task.fileTotal = 0;
      f.state = "downloading";
      const targetDir = flat ? dir : path.join(dir, ...root);
      try {
        const r = await downloadAttach(f, targetDir, task);
        f.state = "ok";
        f.size = r.size;
        f.path = r.path;
        f.name = r.name || f.name;
        task.done++;
        if (!task.dir || task.dir === dir) task.dir = targetDir;
      } catch (e) {
        f.state = "error";
        f.error = String(e.message || e);
        task.failed++;
      }
    }
    task.state = task.state === "stopped" ? "stopped" : "done";
    task.current = "";
    task.endedAt = Date.now();
    setTimeout(() => TASKS.delete(id), 3600000).unref?.();
  })().catch(() => { task.state = "done"; });

  return { taskId: id, total: files.length, dir };
}

// ---------------- 系统对话框 / 打开目录 ----------------

function runPowerShell(script, timeoutMs = 180000) {
  return new Promise((resolve) => {
    const b64 = Buffer.from(script, "utf16le").toString("base64");
    const ps = spawn("powershell.exe", ["-NoProfile", "-STA", "-EncodedCommand", b64], { windowsHide: true });
    let out = "";
    const timer = setTimeout(() => { try { ps.kill(); } catch {} resolve(""); }, timeoutMs);
    ps.stdout.on("data", (d) => { out += d.toString("utf8"); });
    ps.on("error", () => { clearTimeout(timer); resolve(""); });
    ps.on("close", () => { clearTimeout(timer); resolve(out.trim()); });
  });
}

async function pickDir(startDir) {
  const start = String(startDir || "").replace(/'/g, "''");
  const script = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Windows.Forms | Out-Null
$f = New-Object System.Windows.Forms.FolderBrowserDialog
$f.Description = '选择保存课程文档的文件夹'
$f.ShowNewFolderButton = $true
if ('${start}' -ne '' -and (Test-Path -LiteralPath '${start}')) { $f.SelectedPath = '${start}' }
$r = $f.ShowDialog()
if ($r -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.Write($f.SelectedPath) }
$f.Dispose()
`;
  const p = await runPowerShell(script);
  return p;
}

function openDir(dir) {
  const d = String(dir || "").trim();
  if (!d) return false;
  try {
    fs.mkdirSync(d, { recursive: true });
  } catch {
    return false;
  }
  try {
    spawn("explorer.exe", [d], { detached: true, windowsHide: false }).unref();
    return true;
  } catch {
    return false;
  }
}

function defaultDir() {
  const home = os.homedir();
  const dl = path.join(home, "Downloads");
  try {
    if (fs.existsSync(dl)) return path.join(dl, "学习通文档");
  } catch {}
  return path.join(home, "学习通文档");
}

module.exports = {
  listCourses,
  listDir,
  startDownload,
  progress,
  stopTask,
  pickDir,
  openDir,
  defaultDir,
  listHwAttachments,
  startHwDownload,
};
