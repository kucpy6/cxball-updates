/*
 * hw.js —— 注入到学习通作业页里执行的「抓题 / 填题」脚本。
 * 由 bridge.js 通过 CDP 注入，不随页面加载，也不需要用户手动粘贴。
 *
 * 对外暴露 __CX：
 *   __CX.info()            页面概况
 *   __CX.extract()         抓取题目（题号、题型、题干、选项）
 *   __CX.fill({answers})   把答案写回页面（只填不交）
 *   __CX.clear()           撤销填充（清空已填内容）
 *
 * 设计原则：学习通页面结构在各校/各版本间不一致，所以选择器一律多套兜底，
 * 并且给每道题打 data-cxq 标记，填题时只认标记，不依赖具体 DOM 层级。
 */
var __CX = (function () {
  var MARK = "data-cxq";
  var MARKED = "data-cxqf";

  function txt(el) {
    if (!el) return "";
    return String(el.innerText || el.textContent || "")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+/g, " ")
      .replace(/\n{2,}/g, "\n")
      .trim();
  }

  function visible(el) {
    if (!el) return false;
    if (el.type === "hidden") return false;
    var r = el.getBoundingClientRect();
    return r.width > 0 || r.height > 0 || el.getClientRects().length > 0;
  }

  // 题目容器候选：不同学校/不同版本的类名差得很远，全部合并后靠「内外层数量」判断
  var Q_SELECTORS = [
    ".questionLi",
    ".TiMu",
    ".mark_item",
    ".que-item",
    ".question-item",
    ".q-item",
    "[data-questionid]",
    "div[id^='question']",
    "div[id^='Question']",
    ".subject_describe",
  ];

  function hasControl(el) {
    return !!el.querySelector(
      'input[type=radio],input[type=checkbox],input[type=text],input:not([type]),textarea,[contenteditable="true"],iframe'
    );
  }

  var TYPED =
    'input[type=radio],input[type=checkbox],input[type=text],input:not([type]),textarea,[contenteditable="true"]';

  // 只看控件会把真题目漏掉：不少作业页把「题干」和「选项」拆成两个并列块，
  // 题干容器里一个 input 都没有。所以补一条「文本像不像题目」的判断。
  function looksLikeStem(el) {
    var t = txt(el);
    if (!t || t.length < 6) return false;
    var head = t.slice(0, 60);
    return /^\s*\d+\s*[.、．]/.test(head) || /[\(（][^\)）]{0,12}题/.test(head);
  }

  function isQBox(el) {
    if (!el || typeof el.matches !== "function") return false;
    if (el.matches(".questionLi,.TiMu,.mark_item,.que-item,.question-item,.q-item")) return true;
    return /^(question|Question)/.test(el.id || "");
  }

  // 找到真正能作答的那块：容器内没有控件时，选项多半紧跟在后面的兄弟节点里
  function answerScope(el) {
    if (el.querySelector(TYPED) || el.querySelector("iframe")) return el;
    var sib = el.nextElementSibling;
    var guard = 0;
    while (sib && guard++ < 3) {
      if (isQBox(sib)) break;
      if (sib.querySelector(TYPED)) return sib;
      sib = sib.nextElementSibling;
    }
    return el;
  }

  // ---------- 超星 mooc2 版式 ----------
  // 选项不是 input，而是 <div class="answerBg" onclick="addChoice(this)" role="radio">；
  // 每题的最终答案存在隐藏框 <input id="answer{题目id}"> 里，值是选项字母。
  // 填空/简答用 UEditor（edui-editor），内容在它的 iframe 里。
  function choiceEls(el) {
    var scope = answerScope(el);
    var list = Array.prototype.slice.call(scope.querySelectorAll(".answerBg"));
    if (!list.length) {
      list = Array.prototype.slice.call(scope.querySelectorAll('[role="radio"],[role="checkbox"]'));
    }
    return list;
  }

  function optLabel(box) {
    var n = box.querySelector(".num_option,.num_option_dx,.num_option_pd");
    if (n) {
      var d = String(n.getAttribute("data") || "").trim();
      if (d) return d.toUpperCase();
    }
    var m = txt(box).match(/^\s*([A-H])\b/);
    return m ? m[1] : "";
  }

  // 只去掉「A. / A、/ A) / A 」这种选项编号。
  // 注意分隔符不能是可选的：老写法会把「A类地址」「B类掩码」的 A/B 一起吃掉，
  // 变成「类地址」——模型看到这种选项只能瞎猜，正确率就是这样掉下来的。
  function stripLabel(s) {
    return String(s || "")
      .replace(/^[A-H]\s*[、.．:：)）]\s*/, "")
      .replace(/^[A-H][ \u00a0]+(?=\S)/, "")
      .trim();
  }

  function optText(box) {
    var p = box.querySelector(".answer_p");
    return stripLabel(txt(p || box)).slice(0, 300);
  }

  // 优先调页面自己的处理函数：多选是 toggle，自己 click 容易把已选的又取消掉
  function clickBox(box) {
    var oc = String(box.getAttribute("onclick") || "");
    try {
      if (/addMultipleChoice/i.test(oc) && typeof window.addMultipleChoice === "function") {
        window.addMultipleChoice(box);
        return;
      }
      if (/addChoice/i.test(oc) && typeof window.addChoice === "function") {
        window.addChoice(box);
        return;
      }
    } catch (e) { /* 落到原生 click */ }
    box.click();
  }

  function ansInput(el) {
    var ins = Array.prototype.slice.call(el.querySelectorAll("input"));
    for (var i = 0; i < ins.length; i++) {
      if (/^answer\d+$/i.test(ins[i].id || "")) return ins[i];
    }
    for (var j = 0; j < ins.length; j++) {
      var id = ins[j].id || "";
      if (/^answer/i.test(id) && !/answertype/i.test(id)) return ins[j];
    }
    return null;
  }

  // 读回隐藏框里的实际答案，用来校验有没有点对（单选会自动顶掉旧的）
  function readAns(el) {
    var inp = ansInput(el);
    return inp ? String(inp.value || "").toUpperCase().replace(/[^A-H]/g, "") : "";
  }

  // 找到「这一题」的编辑器实例。踩过的坑：
  //  UE.getEditor(id) 对不认识的 id 会新建一个空实例，拿它 setContent 会写在别处；
  //  同一个编辑器外层 id（edui153）和 textarea id（answer406123973）取到的对象并不相同。
  // 所以先按 container.id 精确匹配外层，再退到「唯一包含关系」，都不确定就返回 null。
  function editorOf(wrap) {
    if (typeof window.UE === "undefined" || !wrap) return null;
    var wid = wrap.id || "";
    var ins = window.UE.instants || {};
    var k, ed;
    if (wid) {
      try {
        for (k in ins) {
          ed = ins[k];
          if (ed && ed.setContent && ed.container && ed.container.id === wid) return ed;
        }
      } catch (e) { /* 继续 */ }
      try {
        if (window.UE.getEditor) {
          ed = window.UE.getEditor(wid);
          if (ed && ed.setContent && ed.container && ed.container.id === wid) return ed;
        }
      } catch (e) { /* 继续 */ }
    }
    try {
      var cands = [];
      for (k in ins) {
        ed = ins[k];
        if (ed && ed.setContent && ed.container && wrap.contains(ed.container)) cands.push(ed);
      }
      if (cands.length === 1) return cands[0];
    } catch (e) { /* 放弃 */ }
    return null;
  }

  // UEditor 的正文必须通过实例写，只改 iframe 里的 HTML 提交时会丢
  function setEditor(wrap, text) {
    var s = String(text == null ? "" : text);
    var ed = editorOf(wrap);
    if (ed) {
      try {
        ed.setContent(s);
        if (ed.fireEvent) ed.fireEvent("contentchange");
        return true;
      } catch (e) { /* 落到 iframe */ }
    }
    try {
      var ifr = wrap.querySelector("iframe");
      if (ifr && ifr.contentDocument && ifr.contentDocument.body) {
        ifr.contentDocument.body.innerHTML = s.replace(/\n/g, "<br>");
        return true;
      }
    } catch (e) { /* 跨域读不到 */ }
    return false;
  }

  // 有些学校的作业页把答题区塞在同源 iframe 里，主文档扫不到 —— 一并纳入搜索范围
  function roots() {
    var out = [document];
    var fs = document.querySelectorAll("iframe");
    for (var i = 0; i < fs.length && i < 12; i++) {
      try {
        var d = fs[i].contentDocument;
        if (d && d.body && d.querySelector) out.push(d);
      } catch (e) { /* 跨域 iframe 读不到，跳过 */ }
    }
    return out;
  }

  function pickIn(root) {
    // 把所有选择器的命中合并起来，再用「内外层数量」判断哪一层才是「一道题」。
    // 只取单一选择器会漏题：不同题型分组常用不同类名。
    var set = [];
    for (var i = 0; i < Q_SELECTORS.length; i++) {
      var els = Array.prototype.slice.call(root.querySelectorAll(Q_SELECTORS[i]));
      for (var j = 0; j < els.length; j++) {
        if (set.indexOf(els[j]) < 0) set.push(els[j]);
      }
    }
    if (!set.length) {
      var ctrls = Array.prototype.slice.call(
        root.querySelectorAll('textarea,input[type=text],input[type=radio],input[type=checkbox]')
      );
      var seen = [];
      ctrls.forEach(function (c) {
        if (!visible(c)) return;
        var box = c.closest(".questionLi,.TiMu,li,form>div,form>section") || c.parentElement;
        if (box && seen.indexOf(box) < 0) seen.push(box);
      });
      return seen.filter(hasControl);
    }
    // 最外层（不被别的命中元素包住）与最内层（不再包住别的命中元素）
    var outer = set.filter(function (el) {
      return !set.some(function (o) { return o !== el && o.contains(el); });
    });
    var inner = set.filter(function (el) {
      return !set.some(function (o) { return o !== el && el.contains(o); });
    });
    // 内层明显更多 → 说明外层是「大题分组」，真正的一道题在内层
    var use = inner.length > outer.length * 1.5 ? inner : outer;
    return use.filter(function (el) {
      return hasControl(el) || looksLikeStem(el);
    });
  }

  // 多个文档（主文档 + 同源 iframe）都要合并，不能只挑最多的那个：
  // 有些作业页把不同题型分装在不同 iframe 里。
  function containers() {
    var out = [];
    roots().forEach(function (r) {
      var got = pickIn(r);
      for (var i = 0; i < got.length; i++) {
        if (out.indexOf(got[i]) < 0) out.push(got[i]);
      }
    });
    return out;
  }

  // 分步滚到底再回顶：作业页常用懒渲染，没滚到的题根本不在 DOM 里。
  // 注意必须「停在底部」等一会儿 —— 滚到底后立刻回顶，两次 scrollTo 会被合并成一帧，
  // 懒加载那次判断就落到 scrollY=0 上，等于白滚。
  function warmup() {
    return new Promise(function (done) {
      var round = 0;
      var lastH = 0;

      function sweep() {
        round++;
        var y = 0;
        var step = Math.max(320, Math.floor(window.innerHeight * 0.85));
        var guard = 0;
        var timer = setInterval(function () {
          var h = document.body ? document.body.scrollHeight : 0;
          y += step;
          try { window.scrollTo(0, y); } catch (e) {}
          guard++;
          if (y >= h - window.innerHeight || guard > 80) {
            clearInterval(timer);
            // 在底部停留，给懒加载留出渲染时间
            setTimeout(function () {
              var h2 = document.body ? document.body.scrollHeight : 0;
              if (h2 > lastH + 40 && round < 3) {
                lastH = h2;
                sweep();                 // 内容又长出来了，再滚一轮
                return;
              }
              try { window.scrollTo(0, 0); } catch (e) {}
              setTimeout(function () {
                done({
                  height: h2,
                  rounds: round,
                  count: containers().length,
                });
              }, 350);
            }, 750);
          }
        }, 180);
      }

      lastH = document.body ? document.body.scrollHeight : 0;
      sweep();
    });
  }

  // 按标记找回元素：不经过 document，题目在 iframe 里也能找到
  function byMark(qs, n) {
    var key = String(n);
    for (var i = 0; i < qs.length; i++) {
      if (qs[i].getAttribute(MARK) === key) return qs[i];
    }
    return null;
  }

  function typeOf(el) {
    // 超星在容器上直接标了 typename，这是最可靠的来源
    var tn = (el.getAttribute && el.getAttribute("typename")) || "";
    if (tn) {
      if (/单选|单项/.test(tn)) return "single";
      if (/多选|多项/.test(tn)) return "multi";
      if (/判断/.test(tn)) return "judge";
      if (/填空/.test(tn)) return "blank";
      if (/简答|论述|名词|计算|分析/.test(tn)) return "short";
    }
    var head = txt(el).slice(0, 160);
    if (/\[?\s*(单项?选择|单选)\s*\]?/.test(head)) return "single";
    if (/\[?\s*(多项?选择|多选)\s*\]?/.test(head)) return "multi";
    if (/\[?\s*判断\s*\]?/.test(head)) return "judge";
    if (/\[?\s*填空\s*\]?/.test(head)) return "blank";
    if (/\[?\s*(简答|论述|名词解释|计算|分析)题?\s*\]?/.test(head)) return "short";
    // 题干里没写题型时看控件；注意选项可能不在容器内部
    var scope = answerScope(el);
    var boxes = scope.querySelectorAll(".answerBg");
    if (boxes.length) {
      return boxes[0].getAttribute("role") === "checkbox" ? "multi" : "single";
    }
    if (scope.querySelector('input[type=checkbox]')) return "multi";
    if (scope.querySelector('input[type=radio]')) return "single";
    if (scope.querySelector("textarea,.edui-editor")) return "short";
    if (scope.querySelector('input[type=text],input:not([type])')) return "blank";
    return "unknown";
  }

  // 去掉题干前缀「1.」「(单选题, 5.5分)」，让题干更干净
  function cleanStem(t) {
    return String(t || "")
      .replace(/\u00a0/g, " ")
      .replace(/\s+/g, " ")
      .replace(/^\s*\d+\s*[.、．]\s*/, "")
      .replace(/^\s*[(（]\s*[^)）]{0,22}题[^)）]{0,16}[)）]\s*/, "")
      .trim();
  }

  function stemOf(el) {
    // 超星标准题干在 h3.mark_name（题号+题型+题干都在里面）。
    // 注意 .stem_answer 是「答题区」，简答题里放的是 UEditor，纯文本会变成
    // 「段落格式 字体 字号」这种工具栏文字，所以绝不能优先取它。
    var sels = [".mark_name", ".subject_describe", ".qtContent", ".Zy_TItle", ".timu", ".queTitle", ".questionTitle"];
    for (var i = 0; i < sels.length; i++) {
      var b = el.querySelector(sels[i]);
      var t = cleanStem(txt(b));
      // 1200 字够长材料题用；截太短会把关键条件切掉，模型只能猜
      if (t.length >= 4) return t.slice(0, 1200);
    }
    // 兜底：整块文本，剔掉答题区（编辑器工具栏）和选项列表，避免 AI 把选项当题干
    var clone = el.cloneNode(true);
    Array.prototype.forEach.call(
      clone.querySelectorAll(
        ".stem_answer,.edui-editor,.eidtDiv,.edui-default,ul.answerList,.answerList,.Zy_ulTop,iframe,script,style,textarea"
      ),
      function (n) {
        n.parentNode && n.parentNode.removeChild(n);
      }
    );
    return cleanStem(txt(clone)).slice(0, 900);
  }

  function optionsOf(el) {
    var out = [];
    var boxes = choiceEls(el);
    if (boxes.length) {
      boxes.forEach(function (b, i) {
        out.push({ i: i, label: optLabel(b) || String.fromCharCode(65 + i), text: optText(b) });
      });
      return out;
    }
    var scope = answerScope(el);
    var ins = Array.prototype.slice.call(scope.querySelectorAll("input[type=radio],input[type=checkbox]"));
    ins.forEach(function (inp, i) {
      var lab = inp.closest("label") || inp.parentElement;
      var t = stripLabel(txt(lab));
      out.push({ i: i, label: String.fromCharCode(65 + i), text: t.slice(0, 300) });
    });
    if (!out.length) {
      var lis = Array.prototype.slice.call(scope.querySelectorAll(".answerList li,.Zy_ulTop li,ul.answerList>li,.option"));
      lis.forEach(function (li, i) {
        var t = stripLabel(txt(li));
        if (t) out.push({ i: i, label: String.fromCharCode(65 + i), text: t.slice(0, 300) });
      });
    }
    return out;
  }

  function fieldsOf(el) {
    // 超星填空/简答每题一个或多个 UEditor，每个编辑器就是一空
    var eds = Array.prototype.slice.call(el.querySelectorAll(".edui-editor"));
    if (eds.length) return eds;
    var f = Array.prototype.slice.call(el.querySelectorAll(TYPED));
    return f.filter(visible);
  }

  function info() {
    var qs = containers();
    return {
      url: location.href,
      title: document.title,
      count: qs.length,
      ready: document.readyState,
      types: qs.map(typeOf),
    };
  }

  function extract() {
    // 先滚一遍触发懒渲染，再数题：直接抓会漏掉还没进视口的题
    return warmup().then(function () {
      var qs = containers();
      var out = [];
      qs.forEach(function (el, i) {
        el.setAttribute(MARK, String(i + 1));
        out.push({
          n: i + 1,
          type: typeOf(el),
          stem: stemOf(el),
          options: optionsOf(el),
          fields: fieldsOf(el).length,
        });
      });
      return { ok: true, url: location.href, count: out.length, questions: out, frames: roots().length - 1 };
    });
  }

  function setVal(el, v) {
    var s = String(v == null ? "" : v);
    if (el.isContentEditable) {
      el.innerHTML = s.replace(/\n/g, "<br>");
      el.dispatchEvent(new Event("input", { bubbles: true }));
      return true;
    }
    var proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    var d = Object.getOwnPropertyDescriptor(proto, "value");
    if (d && d.set) d.set.call(el, s);
    else el.value = s;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
    return true;
  }

  // 判断题的「正确 / 错误」映射到实际选项文本
  function judgeIndex(el, want) {
    var yes = /正确|对|是|√|true/i.test(want) && !/不正确|错|否/i.test(want);
    var re = yes ? /(正确|对|√|是)\s*$/ : /(错误|错|×|否)\s*$/;
    var lis = Array.prototype.slice.call(el.querySelectorAll("label,li"));
    for (var i = 0; i < lis.length; i++) {
      var t = txt(lis[i]);
      if (re.test(t.replace(/^[A-B][、.．:：)）]?\s*/, ""))) return { el: lis[i], yes: yes };
    }
    return null;
  }

  function fillChoice(el, a) {
    var pick = String(a.pick || a.answer || "");
    var boxes = choiceEls(el);
    var letters = pick.toUpperCase().match(/[A-H]/g) || [];

    // 安全网：选项若来自相邻的另一道题，第 1 个选项文本会对不上 —— 宁可报错也不乱填
    if (a.opt0 && boxes.length) {
      var k = norm(optText(boxes[0])).slice(0, 10);
      var w = norm(a.opt0).slice(0, 10);
      if (k && w && k.indexOf(w) < 0 && w.indexOf(k) < 0) {
        throw new Error("选项和这道题对不上，已跳过（避免填到别的题上）");
      }
    }

    // 判断题：AI 常回「正确 / 错误」，映射到选项文本
    if (!letters.length && /正确|错误|对|错|√|×/.test(pick) && boxes.length) {
      var yes = /正确|对|是|√/i.test(pick) && !/不正确|错误|错|否/.test(pick);
      var re = yes ? /^(正确|对|是|√|true)/i : /^(错误|错|否|×|false)/i;
      for (var j = 0; j < boxes.length; j++) {
        if (re.test(optText(boxes[j]))) {
          clickBox(boxes[j]);
          return 1;
        }
      }
    }

    // 超星 div 选项：按字母找到对应块再点
    if (boxes.length && letters.length) {
      var done = 0;
      letters.forEach(function (L) {
        if (readAns(el).indexOf(L) >= 0) { done++; return; }   // 多选是 toggle，已选就别再点
        for (var i = 0; i < boxes.length; i++) {
          if (optLabel(boxes[i]) === L) {
            clickBox(boxes[i]);
            done++;
            break;
          }
        }
      });
      // 用隐藏答案框回读校验，点没点上心里有数
      var after = readAns(el);
      if (after) {
        var miss = letters.filter(function (L) { return after.indexOf(L) < 0; });
        if (miss.length) throw new Error("点了但页面没记上（当前是 " + after + "），选项结构可能变了");
      }
      if (done) return done;
    }

    // 老结构：原生 radio / checkbox
    var scope = answerScope(el);
    var ins = Array.prototype.slice.call(scope.querySelectorAll("input[type=radio],input[type=checkbox]"));
    if (letters.length && ins.length) {
      var n2 = 0;
      letters.forEach(function (L) {
        var idx = L.charCodeAt(0) - 65;
        if (idx >= 0 && idx < ins.length) {
          if (!ins[idx].checked) ins[idx].click();
          n2++;
        }
      });
      if (n2) return n2;
    }
    if (/正确|错误|对|错|√|×/.test(pick)) {
      var hit = judgeIndex(scope, pick);
      if (hit) {
        var tgt = hit.el.querySelector("input") || hit.el;
        tgt.click();
        return 1;
      }
    }
    // 最后兜底：按选项文本模糊匹配
    var want = pick.trim();
    if (!want) return 0;
    var lis2 = Array.prototype.slice.call(scope.querySelectorAll("label,li,.option"));
    for (var m = 0; m < lis2.length; m++) {
      var t2 = txt(lis2[m]);
      if (t2 && (t2.indexOf(want) >= 0 || want.indexOf(t2.replace(/^[A-Z][、.．]\s*/, "")) >= 0)) {
        (lis2[m].querySelector("input") || lis2[m]).click();
        return 1;
      }
    }
    return 0;
  }

  function fillText(el, a) {
    var vals = a.blanks && a.blanks.length ? a.blanks : [a.text || a.answer || a.pick || ""];

    // 超星填空/简答：UEditor，一题可能多个空（多个编辑器）
    var eds = Array.prototype.slice.call(el.querySelectorAll(".edui-editor"));
    if (eds.length) {
      var n0 = 0;
      for (var e = 0; e < eds.length && e < vals.length; e++) {
        if (setEditor(eds[e], vals[e])) n0++;
      }
      if (n0) return n0;
    }

    var scope = answerScope(el);
    var ifr = scope.querySelector("iframe") || el.querySelector("iframe");
    if (ifr && ifr.contentDocument && ifr.contentDocument.body) {
      ifr.contentDocument.body.innerHTML = String(vals.join(" ")).replace(/\n/g, "<br>");
      return 1;
    }
    var fields = fieldsOf(scope);
    if (!fields.length) return 0;
    if (fields.length === 1) {
      setVal(fields[0], Array.isArray(vals) ? vals.join(" ") : vals);
      return 1;
    }
    var n = 0;
    for (var i = 0; i < fields.length && i < vals.length; i++) {
      setVal(fields[i], vals[i]);
      n++;
    }
    return n;
  }

  // 归一化文本：去空白与标点，用于题干指纹比对（页面重渲染后靠它重新认题）
  function norm(s) {
    return String(s || "")
      .replace(/\s+/g, "")
      .replace(/[，。、；：？！“”‘’（）()【】\[\]<>《》.,;:?!"'`~@#$%^&*_+=|\\/\-—…·]/g, "")
      .toLowerCase();
  }

  // 按题干指纹在「重新扫出来的题目」里找回原来的那道题
  function matchByStem(qs, stem) {
    var key = norm(stem).slice(0, 28);
    if (key.length < 6) return null;
    var best = null;
    var bestScore = 0;
    qs.forEach(function (el) {
      var t = norm(stemOf(el)).slice(0, 400);
      if (!t) return;
      var score;
      var at = t.indexOf(key);
      if (at >= 0) {
        score = 1000 - at;           // 完整命中，越靠前越像
      } else {
        score = 0;                    // 算最长公共前缀
        while (score < key.length && score < t.length && key.charAt(score) === t.charAt(score)) score++;
      }
      if (score > bestScore) { bestScore = score; best = el; }
    });
    return bestScore >= Math.min(8, key.length) ? best : null;
  }

  function fill(payload) {
    var answers = (payload && payload.answers) || [];
    var res = { ok: 0, total: answers.length, items: [], scanned: 0, rebuilt: false };
    if (!answers.length) return res;

    // 抓题到回填之间隔着 AI 作答（几十秒），超星答题区常会自己重渲染，
    // data-cxq 标记会一起消失 —— 所以这里先重新扫一遍，标记不够就补打。
    var qs = containers();
    res.scanned = qs.length;
    var live = document.querySelectorAll("[" + MARK + "]").length;
    if (!live || live < Math.min(qs.length, answers.length)) {
      qs.forEach(function (el, i) { el.setAttribute(MARK, String(i + 1)); });
      res.rebuilt = true;
    }
    if (!qs.length) {
      answers.forEach(function (a) {
        res.items.push({ n: a.n, ok: 0, why: "这个页面上找不到题目，可能已经跳离作业页" });
      });
      return res;
    }

    answers.forEach(function (a, idx) {
      if (!a || typeof a !== "object") return;
      var n = parseInt(a.n, 10);
      var el = null;
      var how = "";
      // 标记是刚补打的（页面重渲染过），序号可能与抓题时错位 → 先按题干认题
      if (res.rebuilt && a.stem) { el = matchByStem(qs, a.stem); how = "题干"; }
      if (!el && n > 0) { el = byMark(qs, n); how = "标记"; }
      if (!el && a.stem) { el = matchByStem(qs, a.stem); how = "题干"; }
      if (!el && n > 0 && qs[n - 1]) { el = qs[n - 1]; how = "序列"; }

      if (!el) {
        res.items.push({ n: a.n, ok: 0, why: "这道题在页面上定位不到（页面结构变了）" });
        return;
      }
      var t = typeOf(el);
      var done = 0;
      try {
        if (t === "single" || t === "multi" || t === "judge") done = fillChoice(el, a);
        else done = fillText(el, a);
      } catch (e) {
        res.items.push({ n: a.n, ok: 0, type: t, why: String((e && e.message) || e) });
        return;
      }
      if (done) {
        el.setAttribute(MARKED, "1");
        el.style.outline = "2px solid rgba(45,140,240,.55)";
        el.style.outlineOffset = "2px";
        res.ok++;
      }
      res.items.push({
        n: a.n,
        ok: done ? 1 : 0,
        type: t,
        how: how,
        why: done ? "" : t === "unknown" ? "没认出题型" : "没找到可填的输入框",
      });
    });
    return res;
  }

  // 诊断用：把当前页面的结构情况吐出来，方便对着真实作业页校正选择器
  function debug() {
    return warmup().then(function () {
      var qs = containers();
      var perRoot = roots().map(function (r, i) {
        return {
          doc: i === 0 ? "主文档" : "iframe#" + i,
          url: r.location ? r.location.href : "",
          hit: pickIn(r).length,
        };
      });
      return {
        url: location.href,
        ready: document.readyState,
        frames: window.frames.length,
        scrollHeight: document.body ? document.body.scrollHeight : 0,
        perRoot: perRoot,
        counts: Q_SELECTORS.map(function (s) {
          return { sel: s, hit: document.querySelectorAll(s).length };
        }),
        questions: qs.slice(0, 60).map(function (el, i) {
          var sc = answerScope(el);
          return {
            n: i + 1,
            type: typeOf(el),
            fields: fieldsOf(sc).length,
            options: optionsOf(el).length,
            hasControl: hasControl(el),
            scope: sc === el ? "self" : "sibling",
            head: txt(el).slice(0, 70),
          };
        }),
        // 每种题型留一个 HTML 样本：结构对不上时直接看，不用再猜
        samples: (function () {
          var seen = {};
          var out = [];
          qs.forEach(function (el) {
            var t = typeOf(el);
            if (seen[t] || out.length >= 4) return;
            seen[t] = 1;
            var sc = answerScope(el);
            out.push({
              type: t,
              cls: String(el.className || ""),
              html: String(el.outerHTML || "").replace(/\s+/g, " ").slice(0, 900),
              scopeHtml: sc === el ? "" : String(sc.outerHTML || "").replace(/\s+/g, " ").slice(0, 700),
            });
          });
          return out;
        })(),
        controls: document.querySelectorAll("input,textarea,[contenteditable=true]").length,
      };
    });
  }

  function clear() {
    var n = 0;
    roots().forEach(function (root) {
      Array.prototype.forEach.call(root.querySelectorAll("[" + MARKED + "]"), function (el) {
        Array.prototype.forEach.call(el.querySelectorAll("input,textarea"), function (i) {
          if (i.type === "radio" || i.type === "checkbox") {
            if (i.checked) { i.checked = false; i.dispatchEvent(new Event("change", { bubbles: true })); }
          } else if (i.type !== "hidden") {
            setVal(i, "");
          }
        });
        Array.prototype.forEach.call(el.querySelectorAll('[contenteditable="true"]'), function (c) {
          c.innerHTML = "";
        });
        // 超星：选项是 div，清空要点掉选中态并清空隐藏答案框；编辑器用 setContent("")
        Array.prototype.forEach.call(el.querySelectorAll(".answerBg"), function (b) {
          b.classList.remove("check_answer", "answerBg_checked", "checkAnswer");
        });
        var ans = ansInput(el);
        if (ans) ans.value = "";
        Array.prototype.forEach.call(el.querySelectorAll(".edui-editor"), function (w) {
          setEditor(w, "");
        });
        el.style.outline = "";
        el.removeAttribute(MARKED);
        n++;
      });
    });
    return { ok: true, cleared: n };
  }

  return { info: info, extract: extract, fill: fill, clear: clear, debug: debug, warmup: warmup, edOf: editorOf };
})();
