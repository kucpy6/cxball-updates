/*
 * update.js —— 在线更新：检查 → 下载 → 校验 → 交给独立的更新脚本替换文件并重启。
 *
 * 为什么单独一个文件：报名表（bridge.js）已经够长了，更新这块只碰 app/resources 这一层，
 * 万一写坏了也容易单独回退；而且它必须在没有 launcher 参与的情况下自己跑完。
 *
 * 目录约定（都相对程序根，也就是 app 的上一层）：
 *   app/resources/**        会被更新覆盖的唯一范围
 *   data/**                 用户数据，永远不动
 *   data/tmp/update/        下载包、解压暂存、失败备份
 *   data/tmp/update/result.json  上一次更新的结果，界面启动时读它显示成功/失败
 *
 * 关键点：更新时 launcher.exe / bridge 自己都正在运行，覆盖文件必然失败。
 * 所以本模块只负责把包准备好、写一个 PS 脚本、把它以独立进程拉起来；
 * 真正的替换由那个脚本在主程序退出之后做。
 */
"use strict";

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { spawn } = require("child_process");

const ROOT = path.resolve(__dirname, "..", "..", "..");
const RES = path.join(ROOT, "app", "resources");
const TMP = path.join(ROOT, "data", "tmp", "update");
const LOG = path.join(ROOT, "data", "logs", "update.log");
const VER_FILE = path.join(RES, "version.json");
const RESULT_FILE = path.join(TMP, "result.json");

// 更新包只允许改这里面的东西。故意不放开 app/ 根：launcher.exe / jre / node
// 一旦被半个包覆盖，程序就再也起不来了，这种版本只能走安装包。
const ALLOW_PREFIX = ["app/resources/"];
const MAX_PKG = 300 * 1024 * 1024;

const TASK = { phase: "idle", done: 0, total: 0, version: "", error: "" };

function log(msg) {
  try {
    fs.mkdirSync(path.dirname(LOG), { recursive: true });
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    const ts =
      d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " +
      p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    fs.appendFileSync(LOG, ts + "  " + msg + "\r\n", "utf8");
  } catch {
    /* 日志写不了不影响更新 */
  }
}

function readJson(file, fallback) {
  try {
    const raw = fs.readFileSync(file, "utf8").replace(/^\uFEFF/, "");
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function localVersion() {
  const v = readJson(VER_FILE, {});
  // 备源：主源连不上（国内访问 raw.githubusercontent.com 经常失败）时自动顶上
  const fb = Array.isArray(v.updateFallbacks) ? v.updateFallbacks : [];
  return {
    version: String(v.version || "0.0.0"),
    build: String(v.build || ""),
    notes: String(v.notes || ""),
    updateSource: String(v.updateSource || ""),
    updateFallbacks: fb.map((x) => String(x || "").trim()).filter(Boolean),
  };
}

// 1.3.0 vs 1.10.2 —— 按段比数字，不能直接字符串比较
function cmpVer(a, b) {
  const pa = String(a).split(/[.\-+]/).map((x) => parseInt(x, 10) || 0);
  const pb = String(b).split(/[.\-+]/).map((x) => parseInt(x, 10) || 0);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0, y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function normalizeSource(src) {
  const s = String(src || "").trim();
  if (!s) throw new Error("还没有设置更新源地址");
  if (!/^https?:\/\//i.test(s)) throw new Error("更新源地址要以 http:// 或 https:// 开头");
  // 直接把仓库主页填进来是最常见的错误，这里拦一下，省得用户对着一片 404 发懵
  if (/gitee\.com|github\.com/i.test(s) && !/\/raw\/|raw\.githubusercontent/i.test(s)) {
    throw new Error("地址要填到 raw 这一级，例如 https://gitee.com/用户名/仓库名/raw/master");
  }
  return s.replace(/\/+$/, "");
}

function joinUrl(base, name) {
  return /^https?:\/\//i.test(name) ? name : base + "/" + String(name).replace(/^\/+/, "");
}

async function fetchJson(url, timeoutMs) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), timeoutMs || 12000);
  try {
    // 加个随机参数，避开 Gitee / jsDelivr 这类 CDN 的缓存
    const u = url + (url.includes("?") ? "&" : "?") + "_=" + Date.now();
    const res = await fetch(u, {
      signal: ctl.signal,
      cache: "no-store",
      headers: { "Cache-Control": "no-cache", "User-Agent": "cxball-updater" },
    });
    if (!res.ok) {
      if (res.status === 404) throw new Error("更新源里还没有版本清单（仓库还没建好，或地址填错了）");
      if (res.status === 403) throw new Error("更新源拒绝访问，确认仓库是公开的");
      throw new Error("更新源返回 " + res.status);
    }
    const txt = await res.text();
    try {
      return JSON.parse(txt.replace(/^\uFEFF/, ""));
    } catch {
      throw new Error("更新源返回的不是有效内容（可能地址填错了）");
    }
  } catch (e) {
    if (e.name === "AbortError") throw new Error("连接更新源超时，请检查网络后重试");
    throw e;
  } finally {
    clearTimeout(t);
  }
}

function lastResult() {
  const r = readJson(RESULT_FILE, null);
  if (!r) return null;
  // 结果文件留着，但只报告最近 7 天内的，免得一年前的失败一直挂着
  const at = Date.parse(r.at || "");
  if (at && Date.now() - at > 7 * 864e5) return null;
  return r;
}

function state() {
  const v = localVersion();
  return {
    ok: true,
    current: v.version,
    build: v.build,
    notes: v.notes,
    updateSource: v.updateSource,
    root: ROOT,
    busy: TASK.phase === "downloading" || TASK.phase === "verifying" || TASK.phase === "extracting",
    lastResult: lastResult(),
  };
}

async function check(src) {
  const cur = localVersion().version;
  const m = await fetchManifest(src);

  const latest = {
    version: String(m.version),
    date: String(m.date || ""),
    notes: String(m.notes || ""),
    size: Number(m.size || 0),
    sha256: String(m.sha256 || "").toLowerCase(),
    url: String(m.url || ("cxball-" + m.version + ".zip")),
    force: m.force === true,
    minFrom: String(m.minFrom || ""),
  };
  const hasUpdate = cmpVer(latest.version, cur) > 0;
  // 跨代更新（比如从 1.x 到 2.x 换了启动器）不再走增量，避免把程序拼坏
  const needSetup = !!(latest.minFrom && cmpVer(cur, latest.minFrom) < 0);
  return { ok: true, current: cur, source: m.__source, latest, hasUpdate, needSetup };
}

// 先试主源，不行再试备源；返回清单对象，并在 __source 上带上是哪个源给的
async function fetchManifest(src) {
  const cands = [];
  const preferred = String(src || "").trim() || localVersion().updateSource;
  if (preferred) cands.push(preferred);
  for (const f of localVersion().updateFallbacks || []) addCandidate(cands, f);

  if (!cands.length) throw new Error("还没有设置更新源地址");

  const errs = [];
  for (const raw of cands) {
    let source;
    try {
      source = normalizeSource(raw);
    } catch (e) {
      errs.push(e.message);
      continue;
    }
    try {
      const m = await fetchJson(joinUrl(source, "latest.json"), 8000);
      if (!m || !m.version) throw new Error("更新源里的 latest.json 格式不对");
      Object.defineProperty(m, "__source", { value: source, enumerable: false });
      return m;
    } catch (e) {
      errs.push(hostOf(source) + " " + String(e.message || e));
      log("source failed: " + source + " -> " + (e.message || e));
    }
  }
  throw new Error("连不上更新源，请检查网络后重试（" + errs.join("；") + "）");
}

function addCandidate(list, v) {
  const s = String(v || "").trim().replace(/\/+$/, "");
  if (s && !list.some((x) => String(x).trim().replace(/\/+$/, "") === s)) list.push(s);
}

function hostOf(u) {
  const m = /^https?:\/\/([^/]+)/i.exec(String(u || ""));
  return m ? m[1] : "更新源";
}

// ---------------- 下载 ----------------

async function download(url, dest, expectSha, expectSize) {
  TASK.phase = "downloading";
  TASK.done = 0;
  TASK.total = expectSize || 0;

  const ctl = new AbortController();
  const firstByte = setTimeout(() => ctl.abort(), 20000);
  const hardStop = setTimeout(() => ctl.abort(), 10 * 60000);
  let res;
  try {
    res = await fetch(url, {
      signal: ctl.signal,
      headers: { "User-Agent": "cxball-updater", "Cache-Control": "no-cache" },
    });
  } catch (e) {
    clearTimeout(firstByte); clearTimeout(hardStop);
    throw new Error(e.name === "AbortError" ? "下载超时，请检查网络" : "连不上下载地址：" + e.message);
  }
  clearTimeout(firstByte);
  if (!res.ok) {
    clearTimeout(hardStop);
    if (res.status === 404) throw new Error("更新包已经不在服务器上了，请稍后重试");
    throw new Error("下载更新包失败（服务器返回 " + res.status + "）");
  }
  const len = Number(res.headers.get("content-length") || 0);
  if (len) TASK.total = len;
  if (TASK.total && TASK.total > MAX_PKG) {
    clearTimeout(hardStop);
    throw new Error("更新包异常大，已中止");
  }

  const hash = crypto.createHash("sha256");
  const fd = fs.openSync(dest, "w");
  let done = 0;
  try {
    const reader = res.body.getReader();
    for (;;) {
      const { done: end, value } = await reader.read();
      if (end) break;
      done += value.length;
      if (done > MAX_PKG) throw new Error("更新包异常大，已中止");
      hash.update(value);
      fs.writeSync(fd, value);
      TASK.done = done;
    }
  } finally {
    fs.closeSync(fd);
    clearTimeout(hardStop);
  }

  const sha = hash.digest("hex");
  TASK.phase = "verifying";
  if (done < 1024) throw new Error("下载到的文件不完整，请重试");
  if (expectSize && Math.abs(done - expectSize) > 1024) {
    throw new Error("下载大小和更新源标注的不一致，可能被截断，请重试");
  }
  if (expectSha && sha !== expectSha) {
    throw new Error("更新包校验失败（内容损坏或被篡改），已中止");
  }
  return sha;
}

// ---------------- 解压与校验 ----------------

function tarExe() {
  const p = path.join(process.env.SystemRoot || "C:\\Windows", "System32", "tar.exe");
  return fs.existsSync(p) ? p : "";
}

function run(cmd, args) {
  return new Promise((resolve, reject) => {
    const p = spawn(cmd, args, { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    let out = "";
    p.stdout.on("data", (d) => (out += d));
    p.stderr.on("data", (d) => (out += d));
    p.on("error", reject);
    p.on("close", (code) => (code === 0 ? resolve(out) : reject(new Error(out.trim() || "解压失败"))));
  });
}

async function extract(zip, dest) {
  fs.mkdirSync(dest, { recursive: true });
  const tar = tarExe();
  if (tar) {
    // Windows 10 1803+ 自带 bsdtar，能直接解 zip，比 Expand-Archive 快得多
    try {
      await run(tar, ["-xf", zip, "-C", dest]);
      return;
    } catch (e) {
      log("tar 解压失败，改用 Expand-Archive：" + e.message);
    }
  }
  const ps = path.join(process.env.SystemRoot || "C:\\Windows", "System32\\WindowsPowerShell\\v1.0\\powershell.exe");
  await run(ps, [
    "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
    "Expand-Archive -LiteralPath '" + zip.replace(/'/g, "''") + "' -DestinationPath '" + dest.replace(/'/g, "''") + "' -Force",
  ]);
}

function walk(dir, base, out) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const fp = path.join(dir, e.name);
    if (e.isSymbolicLink()) throw new Error("更新包里含有快捷方式链接，已拒绝");
    if (e.isDirectory()) walk(fp, base, out);
    else if (e.isFile()) out.push(path.relative(base, fp).replace(/\\/g, "/"));
  }
  return out;
}

function verifyStage(stage) {
  const files = walk(stage, stage, []);
  if (!files.length) throw new Error("更新包是空的");
  for (const rel of files) {
    if (rel.includes("..") || /^[A-Za-z]:/.test(rel) || rel.startsWith("/")) {
      throw new Error("更新包路径不合法：" + rel);
    }
    if (!ALLOW_PREFIX.some((p) => rel.startsWith(p))) {
      throw new Error("更新包里含有不允许覆盖的文件：" + rel);
    }
  }
  // 一定要带页面和版本号，不然重启后可能起不来或版本号对不上
  const must = ["app/resources/web/index.html", "app/resources/web/app.js", "app/resources/version.json"];
  for (const m of must) {
    if (!files.includes(m)) throw new Error("更新包缺少必要文件：" + m);
  }
  return files;
}

// ---------------- 生成更新脚本 ----------------

// ---------------- 结束程序与替换文件 ----------------
// 替换文件必须由还活着的进程来做。Windows 上让「另起的 PowerShell」去等主程序退出并不可靠
// （实测 detached 起不来、父进程一退子进程也跟着被回收），所以反过来：
// 由小桥自己同步做完「结束主程序 → 覆盖文件 → 重新拉起」，小桥只在最后才退出。

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function psExe() {
  return path.join(process.env.SystemRoot || "C:\\Windows", "System32\\WindowsPowerShell\\v1.0\\powershell.exe");
}

// 同步跑一小段 PowerShell，只用来「按安装目录精确结束进程」，跑完就返回，寿命很短
function runPs(args, timeoutMs) {
  return new Promise((resolve) => {
    let out = "";
    let p;
    try {
      p = spawn(psExe(), args, { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    } catch (e) {
      return resolve({ code: -1, out: String(e.message || e) });
    }
    const t = setTimeout(() => { try { p.kill(); } catch {} }, timeoutMs || 15000);
    p.stdout.on("data", (d) => (out += d));
    p.stderr.on("data", (d) => (out += d));
    p.on("error", (e) => { clearTimeout(t); resolve({ code: -1, out: String(e.message || e) }); });
    p.on("close", (code) => { clearTimeout(t); resolve({ code, out }); });
  });
}

// 只结束「这个安装目录下」的窗口进程。不能按进程名一把梭：同一台机器可能装了别的副本。
async function stopApp() {
  const script = path.join(TMP, "stop.ps1");
  const body = `param([string]$Root)
$pat = $Root.ToLower()
Get-CimInstance Win32_Process -Filter "Name='launcher.exe' OR Name='msedgewebview2.exe'" -ErrorAction SilentlyContinue |
  Where-Object {
    ($_.ExecutablePath -and $_.ExecutablePath.ToLower().StartsWith($pat)) -or
    ($_.CommandLine -and $_.CommandLine.ToLower().Contains($pat))
  } |
  ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop } catch {} }
`;
  fs.mkdirSync(TMP, { recursive: true });
  fs.writeFileSync(script, "\uFEFF" + body, "utf8");
  const r = await runPs(["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", script, "-Root", ROOT], 20000);
  if (r.code !== 0) log("stop.ps1 异常(" + r.code + "): " + r.out.trim().slice(0, 200));
}

function fileFree(p) {
  if (!fs.existsSync(p)) return true;
  try {
    const fd = fs.openSync(p, "r+");
    fs.closeSync(fd);
    return true;
  } catch {
    return false;
  }
}

async function waitFree(file, ms) {
  const end = Date.now() + (ms || 15000);
  while (Date.now() < end) {
    if (fileFree(file)) return true;
    await sleep(250);
  }
  return fileFree(file);
}

// 逐个文件覆盖：覆盖前先把原文件备份，任何一个写不进去就整体回滚，
// 不允许出现「一半新一半旧」的程序。
async function installFiles(files) {
  const backup = path.join(TMP, "bak-" + (TASK.version || "new"));
  const done = [];
  try {
    for (const rel of files) {
      const src = path.join(TMP, "stage", rel.split("/").join(path.sep));
      const dst = path.join(ROOT, rel.split("/").join(path.sep));
      fs.mkdirSync(path.dirname(dst), { recursive: true });
      if (fs.existsSync(dst)) {
        const bk = path.join(backup, rel.split("/").join(path.sep));
        fs.mkdirSync(path.dirname(bk), { recursive: true });
        try { fs.copyFileSync(dst, bk); } catch { /* 备份失败也继续 */ }
      }
      let last = null;
      for (let i = 0; i < 5; i++) {
        try { fs.copyFileSync(src, dst); last = null; break; }
        catch (e) { last = e; await sleep(200); }
      }
      if (last) throw new Error("写入失败：" + rel + "（" + (last.code || last.message) + "）");
      done.push(rel);
    }
  } catch (e) {
    for (const rel of done) {
      const bk = path.join(backup, rel.split("/").join(path.sep));
      const dst = path.join(ROOT, rel.split("/").join(path.sep));
      if (fs.existsSync(bk)) { try { fs.copyFileSync(bk, dst); } catch { /* 尽力而为 */ } }
    }
    throw e;
  }
  return done.length;
}

// 装包三步：关程序 → 覆盖 → 重新拉起。调用方 await 它，直到文件都换完才返回。
async function finishInstall(files) {
  // 先让界面把「正在重启」画出来，再关掉窗口；否则用户看到的是突然消失
  TASK.phase = "installing";
  await sleep(1200);
  await stopApp();
  const free = await waitFree(path.join(ROOT, "app", "launcher.exe"), 15000);
  if (!free) log("launcher.exe 仍被占用，硬着头皮继续覆盖");
  const n = await installFiles(files);
  log("installed " + n + " file(s), free=" + free);
  writeResult(true, n, "");
  const up = relaunch();
  log("update " + TASK.version + " done, relaunch=" + up);
  // 给启动脚本一点时间接上手，然后本进程退出（新的一份会读到新代码）
  setTimeout(() => process.exit(0), 1500);
  return n;
}

function writeResult(okFlag, n, errMsg) {
  try {
    fs.mkdirSync(TMP, { recursive: true });
    const o = { ok: !!okFlag, version: TASK.version, at: new Date().toISOString(), files: n || 0, error: errMsg || "" };
    fs.writeFileSync(RESULT_FILE, JSON.stringify(o), "utf8");
  } catch { /* 写不下就算了，界面下次只是看不到结果 */ }
}

// 更新完重新拉起：优先走启动脚本，它会顺手把小桥和 9223 端口一起修好。
// 拉起之前必须先把自己占的 8799 让出来，否则新的一份会因为端口被占用而直接退出，
// 结果就是「更新完了但小桥没了」。这个回调由 bridge.js 注册。
let ON_EXIT = null;
function setShutdown(fn) { ON_EXIT = fn; }

function relaunch() {
  if (ON_EXIT) { try { ON_EXIT(); } catch { /* 忽略 */ } }
  try {
    const vbs = fs.readdirSync(ROOT).find((n) => /\.vbs$/i.test(n));
    if (vbs) {
      spawn("wscript.exe", [path.join(ROOT, vbs)], { stdio: "ignore", windowsHide: true, detached: true }).unref();
      return true;
    }
  } catch (e) {
    log("relaunch via vbs 失败: " + e.message);
  }
  try {
    const exe = path.join(ROOT, "app", "launcher.exe");
    if (fs.existsSync(exe)) {
      spawn(exe, [], { stdio: "ignore", detached: true }).unref();
      return true;
    }
  } catch (e) {
    log("relaunch via exe 失败: " + e.message);
  }
  return false;
}

// ---------------- 主流程 ----------------

async function runApply(src) {
  try {
    const info = await check(src);
    if (!info.hasUpdate) throw new Error("已经是最新版本了");
    if (info.needSetup) throw new Error("这个版本跨度太大，请重新运行安装程序完成更新");

    TASK.version = info.latest.version;
    TASK.error = "";

    fs.rmSync(TMP, { recursive: true, force: true });
    fs.mkdirSync(TMP, { recursive: true });

    const zip = path.join(TMP, "pkg.zip");
    const url = joinUrl(info.source, info.latest.url);
    log("download " + url);
    await download(url, zip, info.latest.sha256, info.latest.size);

    TASK.phase = "extracting";
    const stage = path.join(TMP, "stage");
    await extract(zip, stage);
    const files = verifyStage(stage);
    log("stage ok, " + files.length + " file(s)");

    // 包里的版本号必须和清单一致，防止拿到旧包反复提示更新
    const packVer = readJson(path.join(stage, "app", "resources", "version.json"), {});
    if (String(packVer.version || "") !== info.latest.version) {
      throw new Error("更新包里的版本号和清单不一致，已中止");
    }

    const n = await finishInstall(files);
    return { ok: true, started: true, version: info.latest.version, files: n };
  } catch (e) {
    TASK.phase = "error";
    TASK.error = String(e.message || e);
    writeResult(false, 0, TASK.error);
    log("apply failed: " + TASK.error);
    throw e;
  }
}

function apply(src) {
  if (TASK.phase === "downloading" || TASK.phase === "verifying" || TASK.phase === "extracting" || TASK.phase === "installing") {
    const e = new Error("更新正在进行中，请稍候");
    e.code = "BUSY";
    throw e;
  }
  TASK.phase = "downloading";
  TASK.done = 0;
  TASK.total = 0;
  TASK.error = "";
  // 立刻返回，前端靠 /update/progress 看进度
  runApply(src).catch(() => {});
  return { ok: true, started: true };
}

function progress() {
  const total = TASK.total || 0;
  return {
    ok: true,
    phase: TASK.phase,
    done: TASK.done,
    total,
    pct: total ? Math.min(100, Math.round((TASK.done / total) * 100)) : 0,
    version: TASK.version,
    error: TASK.error,
  };
}

// 手动导入：用户拿到别人发的 zip，直接拖进面板也能装（不依赖任何网络）
async function importZip(buf) {
  if (!buf || !buf.length) throw new Error("没有收到文件");
  if (TASK.phase === "installing") throw new Error("更新正在进行中");
  TASK.phase = "verifying";
  TASK.done = buf.length;
  TASK.total = buf.length;
  TASK.error = "";
  try {
    fs.rmSync(TMP, { recursive: true, force: true });
    fs.mkdirSync(TMP, { recursive: true });
    const zip = path.join(TMP, "pkg.zip");
    fs.writeFileSync(zip, buf);
    TASK.phase = "extracting";
    const stage = path.join(TMP, "stage");
    await extract(zip, stage);
    const files = verifyStage(stage);
    const packVer = readJson(path.join(stage, "app", "resources", "version.json"), {});
    const v = String(packVer.version || "");
    if (!v) throw new Error("这个压缩包不是更新包（缺少版本信息）");
    TASK.version = v;
    // 装包放在后台跑：这个请求要立刻返回，否则等主程序被关掉时连接就断了
    finishInstall(files).catch((e) => {
      TASK.phase = "error";
      TASK.error = String(e.message || e);
      writeResult(false, 0, TASK.error);
      log("import install failed: " + TASK.error);
    });
    return { ok: true, started: true, version: v, files: files.length };
  } catch (e) {
    TASK.phase = "error";
    TASK.error = String(e.message || e);
    log("import failed: " + TASK.error);
    throw e;
  }
}

module.exports = { state, check, apply, progress, importZip, localVersion, cmpVer, setShutdown };
