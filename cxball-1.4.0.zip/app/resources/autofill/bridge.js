/*
 * bridge.js —— 悬浮球前端 ↔ WebView2 调试端口的本地小桥。
 *
 * 为什么需要它：宿主 launcher.exe 只暴露 login.open / auth.setCookies / refresh 三个动作，
 * 没有 ExecuteScriptAsync，前端 JS 无法跨窗口操作学习通作业页。于是改走 WebView2 自带的
 * CDP（Chrome DevTools Protocol）：launcher 启动时带 --remote-debugging-port=9223，
 * 本进程读 /json/list 找到作业页，用 WebSocket 直接在页面里执行 hw.js。
 *
 * 只监听 127.0.0.1，不对外网开放；无第三方依赖，Node 22+ 自带 WebSocket。
 *
 * 接口：
 *   GET  /ping                        健康检查 + 当前学习通页面清单
 *   POST /act {action, payload, workId}  action = info | extract | fill | clear
 */
"use strict";

const http = require("http");
const fs = require("fs");
const path = require("path");
const docs = require("./docs");
const win = require("./win");

// 更新模块单独一个文件，加载失败不能连累小桥本身（老版本目录里可能没有它）
let upd = null;
try {
  upd = require("./update");
} catch (e) {
  try {
    const dir = path.join(__dirname, "..", "..", "..", "data", "logs");
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, "bridge.log"), "update 模块加载失败: " + ((e && e.stack) || e) + "\r\n", "utf8");
  } catch { /* 忽略 */ }
}

const PORT = Number(process.env.CXBALL_BRIDGE_PORT || 8799);
const CDP_PORT = Number(process.env.CXBALL_CDP_PORT || 9223);
const HW_FILE = path.join(__dirname, "hw.js");
const PAGE_HINT = /chaoxing\.com|edu\.cn|chaoxing/i;

// 小桥是隐藏窗口跑的，崩了没人看得见。装到别人电脑上出问题时，
// data\logs\bridge.log 里能直接看到它为什么没起来。
function bridgeLog(msg) {
  try {
    const dir = path.join(__dirname, "..", "..", "..", "data", "logs");
    fs.mkdirSync(dir, { recursive: true });
    // 用本地时间，用户在日志里看到的时间和自己的表对得上
    const d = new Date();
    const p = (n) => String(n).padStart(2, "0");
    const ts =
      d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) + " " +
      p(d.getHours()) + ":" + p(d.getMinutes()) + ":" + p(d.getSeconds());
    fs.appendFileSync(path.join(dir, "bridge.log"), ts + "  " + msg + "\r\n", "utf8");
  } catch {
    /* 写日志失败不影响主流程 */
  }
}
process.on("uncaughtException", (e) => { bridgeLog("崩溃: " + ((e && e.stack) || e)); process.exit(1); });
process.on("unhandledRejection", (e) => { bridgeLog("未处理异常: " + ((e && e.stack) || e)); });

// 最近一次抓题用的页面（target id / url / 作业编号），回填时优先回到这里
let LAST = { id: "", url: "", workId: "" };

function cors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  // file:// 页面访问本地 127.0.0.1 属于 Private Network Access，需要显式放行
  res.setHeader("Access-Control-Allow-Private-Network", "true");
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
}

function json(res, code, obj) {
  cors(res);
  res.statusCode = code;
  res.end(JSON.stringify(obj));
}

// ---------------- CDP ----------------

class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.seq = 0;
    this.waiters = new Map();
    ws.addEventListener("message", (ev) => {
      let m;
      try { m = JSON.parse(ev.data); } catch { return; }
      const w = this.waiters.get(m.id);
      if (w) { this.waiters.delete(m.id); w(m); }
    });
  }

  static connect(wsUrl) {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(wsUrl);
      const timer = setTimeout(() => { try { ws.close(); } catch {} reject(new Error("连不上学习通页面，请重开一次悬浮球")); }, 8000);
      ws.addEventListener("open", () => { clearTimeout(timer); resolve(new Cdp(ws)); });
      ws.addEventListener("error", () => { clearTimeout(timer); reject(new Error("连不上学习通页面，请重开一次悬浮球")); });
    });
  }

  send(method, params) {
    const id = ++this.seq;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.waiters.delete(id); reject(new Error("CDP 调用超时")); }, 25000);
      this.waiters.set(id, (m) => { clearTimeout(timer); resolve(m); });
      try { this.ws.send(JSON.stringify({ id, method, params })); }
      catch (e) { clearTimeout(timer); reject(e); }
    });
  }

  async evalExpr(expression) {
    const r = await this.send("Runtime.evaluate", {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.error) throw new Error(r.error.message || "页面脚本报错，请重试");
    const ex = r.result && r.result.exceptionDetails;
    if (ex) throw new Error((ex.exception && ex.exception.description) || ex.text || "页面脚本报错");
    const v = r.result && r.result.result;
    return v ? v.value : undefined;
  }

  close() { try { this.ws.close(); } catch {} }
}

async function cdpTargets() {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 4000);
  try {
    const res = await fetch(`http://127.0.0.1:${CDP_PORT}/json/list`, { signal: ctl.signal });
    if (!res.ok) throw new Error("读不到学习通页面");
    return await res.json();
  } finally {
    clearTimeout(t);
  }
}

async function pickTarget(workId) {
  let list;
  try {
    list = await cdpTargets();
  } catch {
    const e = new Error("读不到学习通页面：请关掉悬浮球，从桌面图标重开一次再试");
    e.code = "CDP_DOWN";
    throw e;
  }
  const pages = list.filter((t) => t.type === "page" && PAGE_HINT.test(t.url || ""));
  if (!pages.length) {
    const e = new Error("还没有打开学习通作业页。请先点「打开作业」，等页面加载完再试");
    e.code = "NO_PAGE";
    throw e;
  }
  // 抓题用过的那一页还在，且作业编号一致 → 直接回到同一页，
  // 避免 AI 作答期间又开了别的学习通窗口导致回填打到空页面。
  if (LAST.id && (!workId || LAST.workId === String(workId))) {
    const same = pages.find((p) => p.id === LAST.id);
    if (same) return same;
  }
  // 同一窗口里可能既开了课程页又开了作业页，优先挑作业页
  const workPages = pages.filter((p) => /doHomeWork|\/work\/|\/mooc-ans\/work/i.test(p.url || ""));
  const pool = workPages.length ? workPages : pages;
  if (workId) {
    const key = String(workId);
    const hit = pool.find((p) => (p.url || "").includes(key)) || pages.find((p) => (p.url || "").includes(key));
    if (hit) return hit;
    if (pages.length > 1) {
      const e = new Error("打开了多个学习通页面，但都没有这道作业的编号，请只留作业页再试");
      e.code = "NO_MATCH";
      throw e;
    }
  }
  return pool[pool.length - 1];
}

// ---------------- 动作 ----------------

const ACTIONS = new Set(["info", "extract", "fill", "clear", "debug"]);

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// 每次动作都把 hw.js 全文注入执行，脚本自带 __CX。
// 注意 src 必须和调用表达式在同一函数作用域里，否则拿不到 __CX。
async function evalOn(cdp, action, payload) {
  const src = fs.readFileSync(HW_FILE, "utf8");
  const call =
    action === "fill" || action === "clear"
      ? `__CX.${action}(${JSON.stringify(payload || {})})`
      : `__CX.${action}()`;
  const expr = `(function(){
${src}
var __r = ${call};
if (__r && typeof __r.then === "function") {
  return __r.then(function (v) { return JSON.stringify(v); });
}
return JSON.stringify(__r);
})()`;
  const raw = await cdp.evalExpr(expr);
  return typeof raw === "string" ? JSON.parse(raw) : raw;
}

// 等页面把题目渲染出来（超星答题区是异步挂载的）
async function waitQuestions(cdp, maxMs) {
  const end = Date.now() + maxMs;
  while (Date.now() < end) {
    await sleep(500);
    try {
      const info = await evalOn(cdp, "info", null);
      if (info && info.count > 0) return info.count;
    } catch {
      /* 页面还在跳，重试 */
    }
  }
  return 0;
}

async function runAction(action, payload, workId) {
  if (!ACTIONS.has(action)) throw new Error("未知动作：" + action);
  const target = await pickTarget(workId);
  const cdp = await Cdp.connect(target.webSocketDebuggerUrl);
  try {
    if (action === "extract") {
      LAST = { id: target.id, url: target.url, workId: String(workId || "") };
    }
    // 回填前再滚一遍：万一抓题之后页面自己刷新过，懒渲染的题会重新「藏起来」
    if (action === "fill") {
      try {
        await evalOn(cdp, "warmup", null);
      } catch {
        /* 预热失败不挡主流程 */
      }
    }

    let data = await evalOn(cdp, action, payload);

    // 诊断结果顺手存一份：页面对不上时可以直接看真实结构，不用靠猜
    if (action === "debug") {
      try {
        const dir = path.join(__dirname, "..", "..", "..", "data", "logs");
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(
          path.join(dir, "hw-debug.json"),
          JSON.stringify({ at: new Date().toISOString(), page: target.url, data }, null, 2),
          "utf8"
        );
      } catch {
        /* 落盘失败不影响返回 */
      }
    }

    // 回填时发现页面上没题目了（跳走 / 重载到别的页面）→ 自动回航重试一次
    if (action === "fill" && data && data.scanned === 0 && LAST.url) {
      try {
        await cdp.send("Page.navigate", { url: LAST.url });
        const n = await waitQuestions(cdp, 15000);
        if (n > 0) {
          const retry = await evalOn(cdp, action, payload);
          retry.returned = true;
          data = retry;
        }
      } catch {
        /* 回航失败就保留原始结果，让前端报清楚 */
      }
    }
    return { ok: true, page: { url: target.url, title: target.title }, data };
  } finally {
    cdp.close();
  }
}

// ---------------- HTTP ----------------

function readBody(req) {
  return new Promise((resolve) => {
    let b = "";
    req.on("data", (c) => { b += c; if (b.length > 4e6) req.destroy(); });
    req.on("end", () => resolve(b));
    req.on("error", () => resolve(""));
  });
}

// 更新包是二进制，不能按字符串拼，否则 utf-8 解码会把字节改坏
function readBuf(req, limit) {
  return new Promise((resolve) => {
    const chunks = [];
    let size = 0;
    let dead = false;
    req.on("data", (c) => {
      if (dead) return;
      size += c.length;
      if (size > limit) { dead = true; req.destroy(); resolve(null); return; }
      chunks.push(c);
    });
    req.on("end", () => { if (!dead) resolve(Buffer.concat(chunks)); });
    req.on("error", () => { if (!dead) resolve(null); });
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  if (req.method === "OPTIONS") { cors(res); res.statusCode = 204; return res.end(); }

  try {
    if (url.pathname === "/ping") {
      let pages = [], cdpOk = false, err = "";
      try {
        const list = await cdpTargets();
        cdpOk = true;
        pages = list
          .filter((t) => t.type === "page" && PAGE_HINT.test(t.url || ""))
          .map((t) => ({ url: t.url, title: t.title }));
      } catch (e) { err = String(e.message || e); }
      return json(res, 200, { ok: true, cdp: cdpOk, port: CDP_PORT, pages, error: err, version: upd ? upd.localVersion().version : "1.2", docs: true, hwFiles: true });
    }

    // ---- 在线更新：检查 / 应用 / 进度 / 手动导入 ----
    if (url.pathname === "/update/state") {
      if (!upd) return json(res, 200, { ok: false, error: "这个版本还不带更新功能" });
      try { return json(res, 200, upd.state()); }
      catch (e) { return json(res, 200, { ok: false, error: String(e.message || e) }); }
    }

    if (url.pathname === "/update/check" && req.method === "POST") {
      if (!upd) return json(res, 200, { ok: false, error: "这个版本还不带更新功能" });
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { /* 用默认源 */ }
      try { return json(res, 200, await upd.check(p.source)); }
      catch (e) { return json(res, 200, { ok: false, error: String(e.message || e) }); }
    }

    if (url.pathname === "/update/apply" && req.method === "POST") {
      if (!upd) return json(res, 200, { ok: false, error: "这个版本还不带更新功能" });
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { /* 用默认源 */ }
      try { return json(res, 200, upd.apply(p.source)); }
      catch (e) { return json(res, 200, { ok: false, code: e.code || "ERR", error: String(e.message || e) }); }
    }

    if (url.pathname === "/update/progress") {
      if (!upd) return json(res, 200, { ok: false, error: "这个版本还不带更新功能" });
      return json(res, 200, upd.progress());
    }

    // 手动导入：请求体就是 zip 原始字节，不走 JSON
    if (url.pathname === "/update/import" && req.method === "POST") {
      if (!upd) return json(res, 200, { ok: false, error: "这个版本还不带更新功能" });
      const buf = await readBuf(req, 300 * 1024 * 1024);
      try { return json(res, 200, await upd.importZip(buf)); }
      catch (e) { return json(res, 200, { ok: false, error: String(e.message || e) }); }
    }

    // ---- 作业附件：读作业页 / 下载附件（和课程资料共用进度接口） ----
    if (url.pathname === "/hw/attach" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { return json(res, 400, { ok: false, error: "请求体不是合法 JSON" }); }
      try {
        return json(res, 200, { ok: true, ...(await docs.listHwAttachments(p)) });
      } catch (e) {
        return json(res, 200, { ok: false, code: e.code || "ERR", error: String(e.message || e) });
      }
    }

    if (url.pathname === "/hw/download" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { return json(res, 400, { ok: false, error: "请求体不是合法 JSON" }); }
      try {
        return json(res, 200, { ok: true, ...docs.startHwDownload(p) });
      } catch (e) {
        return json(res, 200, { ok: false, error: String(e.message || e) });
      }
    }

    // ---- 课程文档：课程列表 / 目录浏览 / 下载 / 选目录 ----
    if (url.pathname === "/docs/courses") {
      try {
        const courses = await docs.listCourses();
        return json(res, 200, { ok: true, courses, dir: docs.defaultDir() });
      } catch (e) {
        return json(res, 200, { ok: false, code: e.code || "ERR", error: String(e.message || e) });
      }
    }

    if (url.pathname === "/docs/list" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { return json(res, 400, { ok: false, error: "请求体不是合法 JSON" }); }
      try {
        const out = await docs.listDir(p);
        return json(res, 200, { ok: true, ...out });
      } catch (e) {
        return json(res, 200, { ok: false, code: e.code || "ERR", error: String(e.message || e) });
      }
    }

    if (url.pathname === "/docs/download" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch { return json(res, 400, { ok: false, error: "请求体不是合法 JSON" }); }
      try {
        return json(res, 200, { ok: true, ...docs.startDownload(p) });
      } catch (e) {
        return json(res, 200, { ok: false, error: String(e.message || e) });
      }
    }

    if (url.pathname === "/docs/progress") {
      const t = docs.progress(url.searchParams.get("id"));
      if (!t) return json(res, 404, { ok: false, error: "任务不存在或已过期" });
      return json(res, 200, { ok: true, ...t });
    }

    if (url.pathname === "/docs/stop" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch {}
      return json(res, 200, { ok: docs.stopTask(p.id) });
    }

    if (url.pathname === "/docs/pickdir" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch {}
      const dir = await docs.pickDir(p.dir);
      return json(res, 200, { ok: true, dir });
    }

    if (url.pathname === "/docs/open" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch {}
      return json(res, 200, { ok: docs.openDir(p.dir) });
    }

    if (url.pathname === "/docs/default-dir") {
      return json(res, 200, { ok: true, dir: docs.defaultDir() });
    }

    // ---- 窗口尺寸：面板等比缩放 + 悬浮球大小 ----
    if (url.pathname === "/win/state") {
      try {
        return json(res, 200, { ok: true, ...(await win.state()) });
      } catch (e) {
        return json(res, 200, { ok: false, error: String(e.message || e) });
      }
    }

    if (url.pathname === "/win/apply" && req.method === "POST") {
      const body = await readBody(req);
      let p = {};
      try { p = JSON.parse(body || "{}"); } catch {}
      try {
        return json(res, 200, { ok: true, ...(await win.apply(p)) });
      } catch (e) {
        return json(res, 200, { ok: false, error: String(e.message || e) });
      }
    }

    if (url.pathname === "/act" && req.method === "POST") {
      const body = await readBody(req);
      let reqObj = {};
      try { reqObj = JSON.parse(body || "{}"); } catch { return json(res, 400, { ok: false, error: "请求体不是合法 JSON" }); }
      try {
        const out = await runAction(reqObj.action, reqObj.payload, reqObj.workId);
        return json(res, 200, out);
      } catch (e) {
        return json(res, 200, { ok: false, code: e.code || "ERR", error: String(e.message || e) });
      }
    }

    json(res, 404, { ok: false, error: "not found" });
  } catch (e) {
    json(res, 500, { ok: false, error: String(e.message || e) });
  }
});

server.on("error", (e) => {
  if (e.code === "EADDRINUSE") {
    // 端口已被占用：多半是上一份 bridge 还在跑，直接退出，避免开一堆进程
    bridgeLog("端口 " + PORT + " 已被占用，本实例退出（不影响已在跑的那份）");
    process.exit(0);
  }
  bridgeLog("监听失败: " + ((e && e.stack) || e));
  process.exit(1);
});

server.listen(PORT, "127.0.0.1", () => {
  console.log(`[cxball bridge] listening http://127.0.0.1:${PORT}  (cdp ${CDP_PORT})`);
  bridgeLog("已启动 http://127.0.0.1:" + PORT + " (cdp " + CDP_PORT + ")");
});

// 更新完要重新拉起程序，得先把 8799 让出来，不然新的一份会因端口占用直接退出
if (upd && upd.setShutdown) {
  upd.setShutdown(() => {
    try { server.close(); } catch { /* 忽略 */ }
    try { if (server.closeAllConnections) server.closeAllConnections(); } catch { /* 忽略 */ }
    bridgeLog("更新：已让出端口，等待重新拉起");
  });
}
