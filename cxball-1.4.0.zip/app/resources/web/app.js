/* 前端 ↔ C# Bridge 封装 + 主面板逻辑（协议见 Bridge.cs） */
"use strict";

// ---------- Bridge ----------
const bridge = (() => {
  let seq = 0;
  const pending = new Map();
  const listeners = {};
  window.chrome.webview.addEventListener("message", (e) => {
    const m = e.data;
    if (m.id && pending.has(m.id)) {
      const p = pending.get(m.id);
      pending.delete(m.id);
      m.ok ? p.resolve(m.payload) : p.reject(m.error || { code: "INTERNAL", message: "未知错误" });
    } else if (m.event) {
      (listeners[m.event] || []).forEach((f) => f(m.payload));
    }
  });
  return {
    call(action, payload = {}) {
      const id = "u" + ++seq;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        window.chrome.webview.postMessage({ id, action, payload });
      });
    },
    on(event, f) { (listeners[event] ??= []).push(f); },
  };
})();

// ---------- 状态 ----------
const S = {
  settings: null,
  account: null,       // {id, meta, state}
  snapshot: null,      // {fetchedAt, courses, items, failures}
  tab: "unfinished",   // unfinished | expired | ignored | all
  refreshing: false,
};
const $ = (id) => document.getElementById(id);
const itemKey = (it) => `${it.type}|${it.courseId}|${it.title}`;
// 忽略列表兼容两种格式：旧版纯字符串 key、新版 {key,ts}（§8.2.1 按操作时间排序）
const ignoredEntries = () => (S.account?.state?.ignored || []);
const entryKey = (e) => (typeof e === "string" ? e : e?.key);
const ignoredSet = () => new Set(ignoredEntries().map(entryKey).filter(Boolean));
const ignoredTs = (key) => {
  const e = ignoredEntries().find((x) => entryKey(x) === key);
  return e && typeof e === "object" ? (e.ts ?? 0) : 0;
};
const UNFINISHED = ["未交", "未完成", "待做", "未开始"];
const isUnfinished = (it) => UNFINISHED.includes(it.status);

// ---------- 视图切换 ----------
function show(view) {
  ["view-login", "view-panel", "view-settings", "view-ai", "view-docs"].forEach((v) => $(v).classList.add("hidden"));
  $(view).classList.remove("hidden");
}

// 主面板 ↔ 设置 / AI 切换动画（§7.8）：进二级页向右滑入，返回向左滑入
function switchView(fromId, toId) {
  $(fromId).classList.add("hidden");
  const el = $(toId);
  el.classList.remove("hidden", "slide-in-left", "slide-in-right");
  void el.offsetWidth;   // 强制重排，保证动画可重复播放
  el.classList.add(toId === "view-settings" || toId === "view-ai" ? "slide-in-right" : "slide-in-left");
}

// ---------- Toast ----------
let toastTimer = null;
function toast(msg, ms = 2600) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add("hidden"), ms);
}

// ---------- 通用确认弹窗（替代原生 confirm：自适应内容、位于面板内容上层；danger=红色确定键） ----------
function cxConfirm(msg, danger = false) {
  return new Promise((resolve) => {
    const overlay = $("confirm-overlay");
    $("confirm-text").textContent = msg;
    const ok = $("btn-confirm-ok");
    ok.className = "btn btn-sm " + (danger ? "btn-danger" : "btn-primary");
    overlay.classList.remove("hidden");
    const done = (v) => { overlay.classList.add("hidden"); resolve(v); };
    ok.onclick = () => done(true);
    $("btn-confirm-cancel").onclick = () => done(false);
    overlay.onclick = (e) => { if (e.target === overlay) done(false); };
  });
}

// ---------- 作业分类（§v1.4） ----------
function classify() {
  const now = Date.now();
  const ignored = ignoredSet();
  const r = { unfinished: [], expired: [], ignored: [], all: [] };
  for (const it of (S.snapshot?.items || [])) {
    if (it.type !== "assignment") continue;
    if (ignored.has(itemKey(it))) { r.ignored.push(it); continue; }
    r.all.push(it);
    if (isUnfinished(it)) {
      (it.deadline && it.deadline <= now ? r.expired : r.unfinished).push(it);
    }
  }
  const byDeadline = (a, b) => (a.deadline ?? Infinity) - (b.deadline ?? Infinity);
  r.unfinished.sort(byDeadline);
  r.expired.sort(byDeadline);
  // 已忽略：操作时间近→远（§8.2.1；旧数据无时间戳则排在后）
  r.ignored.sort((a, b) => ignoredTs(itemKey(b)) - ignoredTs(itemKey(a)));
  // 全部：未完成置顶（§v1.4）
  r.all.sort((a, b) => (isUnfinished(b) ? 1 : 0) - (isUnfinished(a) ? 1 : 0) || byDeadline(a, b));
  return r;
}

// ---------- 时间文本（§7.5：两个独立开关，都不勾 = 不显示时间） ----------
function timeText(it) {
  if (!it.deadline) return "";
  const mode = S.settings?.timeDisplay ?? "remainingHours";
  if (mode === "none") return "";
  const d = new Date(it.deadline);
  const p = (n) => String(n).padStart(2, "0");
  const deadlineStr = `截止 ${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  if (mode === "deadline") return deadlineStr;
  const h = Math.floor((it.deadline - Date.now()) / 3600000);   // 向下取整（§v1.4）
  const remainStr = h >= 0 ? `剩 ${h} 小时` : "已截止";
  return mode === "both" ? `${remainStr} · ${deadlineStr}` : remainStr;
}

function courseNameOf(it) {
  return it.courseName || (S.snapshot?.courses || []).find((c) => c.courseId === it.courseId)?.courseName || "";
}

// ---------- 去做作业：直接跳到网页版学习通的该作业页面 ----------
// 作业条目自带 link（含 courseId / workId / enc），点击后交给浏览器打开；
// 悬浮球与登录窗口共用同一个 WebView2 用户目录，宿主放行新窗口时即为已登录状态。
function openWork(it) {
  const url = it?.link;
  if (!url) { toast("该作业没有可用链接，请先刷新"); return; }
  let w = null;
  try { w = window.open(url, "_blank"); } catch { w = null; }
  if (!w) {
    // 弹窗被拦截时的退路：临时 a 标签触发一次跳转
    const a = document.createElement("a");
    a.href = url;
    a.target = "_blank";
    a.rel = "noopener noreferrer";
    document.body.appendChild(a);
    a.click();
    a.remove();
  }
  if (!w) { copyText(url); toast("未能直接打开窗口，作业链接已复制"); }
}

// 复制到剪贴板（execCommand 兜底，WebView 内通常无需额外授权）
function copyText(text) {
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  } catch { /* 忽略：复制失败不影响主流程 */ }
}

// ---------- 背景图（§7.5：cxball.assets 虚拟主机映射到 data/assets） ----------
function applyBackground() {
  const bg = S.settings?.background || {};
  const layer = $("bg-layer");
  if (bg.image) {
    layer.style.backgroundImage = `url("https://cxball.assets/${bg.image}")`;
    layer.style.opacity = ((bg.opacity ?? 75) / 100).toString();
    layer.classList.remove("hidden");
  } else {
    layer.classList.add("hidden");
  }
}

// ---------- 模块透明度（§7.5：统一调所有卡片背景，文字不跟随） ----------
function applyModuleOpacity() {
  const v = S.settings?.moduleOpacity ?? 92;
  document.documentElement.style.setProperty("--card-alpha", (v / 100).toString());
}

// ---------- 渲染：主面板 ----------
function renderPanel() {
  applyBackground();
  applyModuleOpacity();
  const meta = S.account?.meta || {};
  $("nickname").textContent = meta.nickname || (meta.uid ? `账号 ${meta.uid}` : "已登录");
  const av = $("avatar");
  if (meta.avatar) { av.style.backgroundImage = `url("${meta.avatar}")`; av.textContent = ""; }
  else { av.style.backgroundImage = ""; av.textContent = "学"; }
  $("refresh-time").textContent = S.snapshot?.fetchedAt
    ? "上次刷新 " + new Date(S.snapshot.fetchedAt).toLocaleString("zh-CN", { hour12: false })
    : "尚未刷新";

  const mods = S.settings?.modules || {};
  $("mod-notice").classList.toggle("hidden", mods.notice === false);
  $("mod-exam").classList.toggle("hidden", mods.exam === false);

  renderAssignments();
  renderNotices();

  const cls = classify();
  bridge.call("badge", { unfinished: cls.unfinished.length });
  updateRefreshCooldown();
}

// ---------- 刷新冷却倒计时（§4.2：冷却中禁用并显示剩余秒数） ----------
let cdTimer = null;
function updateRefreshCooldown() {
  clearInterval(cdTimer); cdTimer = null;
  const btn = $("btn-refresh");
  const last = S.account?.state?.lastManualRefreshAt ?? 0;
  const throttle = (S.settings?.manualThrottleSec ?? 15) * 1000;
  const tick = () => {
    if (S.refreshing) return;   // 刷新中文案由 doRefresh / fetch.progress 控制
    const remain = Math.ceil((last + throttle - Date.now()) / 1000);
    if (remain > 0) { btn.disabled = true; btn.textContent = `冷却 ${remain}s`; }
    else {
      btn.disabled = false; btn.textContent = "刷新";
      clearInterval(cdTimer); cdTimer = null;
    }
  };
  tick();
  if (btn.disabled) cdTimer = setInterval(tick, 1000);
}

function renderAssignments() {
  const cls = classify();
  const tabs = [
    ["unfinished", `未完成 ${cls.unfinished.length}`],
    ["expired", `已过期 ${cls.expired.length}`],
    ["ignored", `已忽略 ${cls.ignored.length}`],
    ["all", `全部 ${cls.all.length}`],
  ];
  $("assign-tabs").innerHTML = "";
  for (const [key, label] of tabs) {
    const el = document.createElement("span");
    el.className = "tab" + (S.tab === key ? " active" : "");
    el.textContent = label;
    el.onclick = () => { S.tab = key; renderAssignments(); };
    $("assign-tabs").appendChild(el);
  }

  const list = $("assign-list");
  list.innerHTML = "";
  const items = cls[S.tab];
  if (!items.length) {
    list.innerHTML = `<div class="empty-tip">暂无条目</div>`;
    return;
  }
  const ignored = ignoredSet();
  for (const it of items) {
    const el = document.createElement("div");
    el.className = "item";
    const t = isUnfinished(it) && it.deadline ? timeText(it) : "";
    const deadlineHtml = t ? `<span class="item-deadline">${t}</span>` : "";
    const statusCls = isUnfinished(it) ? "" : " item-status-done";
    el.innerHTML = `
      <div class="item-title" title="${escapeHtml(it.title)}">${escapeHtml(it.title)}</div>
      <div class="item-meta">
        <span>${escapeHtml(courseNameOf(it))}</span>
        ${deadlineHtml || `<span class="${statusCls.trim()}">${escapeHtml(it.status || "")}</span>`}
      </div>`;
    el.oncontextmenu = (e) => {
      e.preventDefault();
      showCtxMenu(e.clientX, e.clientY, it, ignored.has(itemKey(it)));
    };
    if (isUnfinished(it) && it.link) {
      el.classList.add("has-go");
      const go = document.createElement("button");
      go.type = "button";
      go.className = "item-go";
      go.textContent = "去做 ›";
      go.title = "在网页版学习通打开该作业";
      go.onclick = (e) => { e.stopPropagation(); openWork(it); };
      el.appendChild(go);
    }
    list.appendChild(el);
  }
}

function renderNotices() {
  const list = $("notice-list");
  list.innerHTML = "";
  const items = (S.snapshot?.items || []).filter((i) => i.type === "notice");
  if (!items.length) {
    list.innerHTML = `<div class="empty-tip">暂无消息</div>`;
    return;
  }
  for (const it of items) {
    const el = document.createElement("div");
    el.className = "item" + (it.status === "未读" ? " unread" : "");
    const time = it.publishedAt
      ? new Date(it.publishedAt).toLocaleString("zh-CN", { hour12: false, month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })
      : "";
    el.innerHTML = `
      <div class="item-title" title="${escapeHtml(it.title)}">${it.status === "未读" ? '<span class="unread-dot"></span>' : ""}${escapeHtml(it.title)}</div>
      <div class="item-meta"><span>${escapeHtml(it.courseName || "")}</span><span>${time}</span></div>`;
    list.appendChild(el);
  }
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---------- 右键菜单（§v1.4：忽略/取消忽略；详情预留点击无反应） ----------
function showCtxMenu(x, y, it, isIgnored) {
  const menu = $("ctx-menu");
  menu.innerHTML = "";
  const mk = (label, fn, disabled = false) => {
    const el = document.createElement("div");
    el.className = "ctx-item" + (disabled ? " disabled" : "");
    el.textContent = label;
    if (!disabled) el.onclick = () => { hideCtxMenu(); fn(); };
    menu.appendChild(el);
  };
  mk("去做作业", () => openWork(it), !it.link);
  if (it.type === "assignment") mk("下载作业附件", () => hwdOpenFor(it), !it.link);
  mk(isIgnored ? "取消忽略" : "忽略", async () => {
    const r = await bridge.call("ignore.set", { key: itemKey(it), ignored: !isIgnored });
    (S.account.state ??= {}).ignored = r.ignored || [];
    renderAssignments();
  });
  mk("详情（预留）", () => {}, true);
  menu.style.left = Math.min(x, innerWidth - 130) + "px";
  menu.style.top = Math.min(y, innerHeight - 152) + "px";
  menu.classList.remove("hidden");
}
function hideCtxMenu() { $("ctx-menu").classList.add("hidden"); }
document.addEventListener("click", hideCtxMenu);

// ---------- 刷新 ----------
// opts.login=true → 登录事件触发的刷新（§4.1/§4.2，走登录冷却，不计入手动节流）
async function doRefresh(opts = {}) {
  const login = !!opts.login;
  if (S.refreshing) return;
  S.refreshing = true;
  const btn = $("btn-refresh");
  btn.disabled = true;
  btn.textContent = "刷新中…";
  try {
    const r = await bridge.call("refresh", { login });
    S.snapshot = r.snapshot;
    if (!login) (S.account.state ??= {}).lastManualRefreshAt = Date.now();   // 本地同步冷却时间戳
    renderPanel();
    const fails = r.snapshot?.failures?.length || 0;
    if (fails) toast(`刷新完成，${fails} 项获取失败`);
    else if (!opts.quiet) toast("刷新完成");
  } catch (e) {
    if (e.code !== "RATE_LIMITED" && !login)                    // 手动刷新失败也占冷却（§4.3）
      (S.account.state ??= {}).lastManualRefreshAt = Date.now();
    if (!(login && e.code === "RATE_LIMITED" && opts.quiet))     // 登录冷却命中时静默沿用旧快照
      toast(e.message || "刷新失败");
  } finally {
    S.refreshing = false;
    updateRefreshCooldown();
  }
}
bridge.on("fetch.progress", (p) => {
  const btn = $("btn-refresh");
  if (S.refreshing && p) btn.textContent = `${p.currentTitle || p.stage} ${p.done}/${p.total}`;
});

// ---------- 版本更新 ----------
// 更新只覆盖 app/resources（一般几百 KB），账号、设置、AI Key 都在 data 与浏览器配置里，
// 全程不碰，所以「更新」和「卸载重装」不一样，更新完什么都不用重新登录。
const UPD = {
  base: "http://127.0.0.1:8799",
  cur: "",
  source: "",
  latest: null,
  busy: false,
  timer: null,
};

function updPill(text, on) {
  const el = $("upd-pill");
  if (!el) return;
  el.textContent = text;
  el.classList.toggle("off", !on);
}

function updNote(html) {
  const box = $("upd-body");
  if (box) box.innerHTML = html;
}

async function updPost(pathname, body) {
  let r;
  try {
    r = await fetch(UPD.base + pathname, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
  } catch {
    throw new Error("更新助手没响应：关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次");
  }
  const j = await r.json().catch(() => ({ ok: false, error: "更新助手返回的内容看不懂" }));
  if (!j.ok) throw new Error(j.error || "操作失败");
  return j;
}

function updRememberSource(src) {
  UPD.source = src || "";
  try {
    localStorage.setItem("cxball.update.src", UPD.source);
  } catch {
    /* 隐私模式写不了就算了，本次仍然生效 */
  }
}

// 读当前版本 + 上次更新的结果。老版本没有这个接口时静默降级，不弹任何错。
async function updInit() {
  let j;
  try {
    const r = await fetch(UPD.base + "/update/state", { cache: "no-store" });
    j = await r.json();
  } catch {
    j = null;
  }
  if (!j || !j.ok) {
    if ($("upd-cur")) $("upd-cur").textContent = "—";
    updPill("不可用", false);
    return false;
  }
  UPD.cur = j.current || "";
  if ($("upd-cur")) $("upd-cur").textContent = UPD.cur ? "v" + UPD.cur : "—";

  let saved = "";
  try {
    saved = localStorage.getItem("cxball.update.src") || "";
  } catch {
    /* 忽略 */
  }
  UPD.source = saved || j.updateSource || "";
  if ($("upd-source")) $("upd-source").value = UPD.source;

  const lr = j.lastResult;
  if (lr && lr.ok) {
    updNote(`<span class="upd-ok">上次已更新到 v${escapeHtml(lr.version || "")}</span>`);
    updPill("已更新", true);
  } else if (lr && !lr.ok) {
    updNote(
      `<span class="upd-err">上次更新没有完成（${escapeHtml(lr.error || "未知原因")}），文件已还原，可以再试一次</span>`
    );
    updPill("失败", false);
  } else {
    updPill("—", false);
  }
  return true;
}

async function updCheck(silent) {
  const src = (($("upd-source") && $("upd-source").value) || UPD.source || "").trim();
  if (!src) {
    if (!silent) updNote('<span class="upd-muted">先在上面填写更新源地址，再点「检查更新」。</span>');
    updPill("未配置", false);
    return;
  }
  const btn = $("btn-upd-check");
  if (btn) btn.disabled = true;
  updPill("检查中", false);
  try {
    const j = await updPost("/update/check", { source: src });
    updRememberSource(src);
    if (!j.hasUpdate) {
      updPill("已最新", false);
      if (!silent) updNote(`<span class="upd-ok">已经是最新版本 v${escapeHtml(j.current)}。</span>`);
      return;
    }
    UPD.latest = j.latest;
    updPill("有新版", true);
    updRenderUpdate(j);
    if (silent) toast(`发现新版本 v${j.latest.version}，可到设置里更新`);
  } catch (e) {
    updPill("检查失败", false);
    if (!silent) updNote(`<span class="upd-err">检查更新失败：${escapeHtml(e.message || String(e))}</span>`);
  } finally {
    if (btn) btn.disabled = false;
  }
}

function updRenderUpdate(j) {
  const l = j.latest || {};
  const mb = l.size ? (l.size / 1048576).toFixed(2) + " MB" : "";
  const head = `v${escapeHtml(l.version || "")}` + (l.date ? `　<span class="upd-muted">${escapeHtml(l.date)}</span>` : "");
  const meta = mb ? `<span class="upd-muted">　更新包 ${mb}</span>` : "";
  updNote(
    `<div class="upd-new">
      <div><span class="upd-ver">${head}</span>${meta}</div>
      <div class="upd-notes">${escapeHtml(l.notes || "本次更新没有附说明。")}</div>
      <button class="btn btn-ghost btn-sm" id="btn-upd-do">立即更新并重启</button>
      <span class="upd-muted">　约 10 秒，期间悬浮球会自动关闭再打开</span>
    </div>`
  );
  const doBtn = $("btn-upd-do");
  if (doBtn) doBtn.onclick = () => updApply();
}

async function updApply() {
  if (UPD.busy) return;
  UPD.busy = true;
  const btn = $("btn-upd-do");
  if (btn) btn.disabled = true;
  try {
    await updPost("/update/apply", { source: UPD.source });
    updWatch();
  } catch (e) {
    UPD.busy = false;
    if (btn) btn.disabled = false;
    updNote(`<span class="upd-err">${escapeHtml(e.message || String(e))}</span>`);
  }
}

// 更新脚本会先杀掉小桥再替换文件，所以轮询失败本身就是「正在替换」的信号，不是错误
function updWatch() {
  clearInterval(UPD.timer);
  updNote('<div>正在准备更新…</div>');
  UPD.timer = setInterval(async () => {
    let p;
    try {
      const r = await fetch(UPD.base + "/update/progress", { cache: "no-store" });
      p = await r.json();
    } catch {
      clearInterval(UPD.timer);
      updNote('<div class="upd-ok">正在替换文件并重启，请稍候…（约 10 秒）</div>');
      return;
    }
    if (!p || !p.ok) return;
    if (p.phase === "downloading") {
      const got = (p.done / 1048576).toFixed(2);
      const all = p.total ? (p.total / 1048576).toFixed(2) + " MB" : "";
      updNote(
        `<div>正在下载更新包 ${got}${all ? " / " + all : " MB"}</div>` +
          `<div class="upd-bar"><i style="width:${p.pct || 0}%"></i></div>`
      );
    } else if (p.phase === "verifying") {
      updNote("<div>正在校验更新包…</div>");
    } else if (p.phase === "extracting") {
      updNote("<div>正在解压…</div>");
    } else if (p.phase === "installing") {
      clearInterval(UPD.timer);
      updNote('<div class="upd-ok">正在重启并完成更新，请稍候…（约 10 秒）</div>');
    } else if (p.phase === "error") {
      clearInterval(UPD.timer);
      UPD.busy = false;
      updNote(`<span class="upd-err">更新失败：${escapeHtml(p.error || "未知原因")}</span>`);
    }
  }, 600);
}

// 离线兜底：拿到别人发的 zip，直接选文件就能装，不需要任何网络
async function updImport(file) {
  if (!file) return;
  if (!/\.zip$/i.test(file.name)) {
    toast("请选择 .zip 格式的更新包");
    return;
  }
  try {
    updNote(`<div>正在读取 ${escapeHtml(file.name)}…</div>`);
    const buf = await file.arrayBuffer();
    let r;
    try {
      r = await fetch(UPD.base + "/update/import", { method: "POST", body: buf });
    } catch {
      throw new Error("更新助手没响应：关掉悬浮球窗口，再从桌面图标重新打开一次");
    }
    const j = await r.json().catch(() => ({ ok: false, error: "更新助手返回的内容看不懂" }));
    if (!j.ok) throw new Error(j.error || "导入失败");
    UPD.busy = true;
    updWatch();
  } catch (e) {
    updNote(`<span class="upd-err">${escapeHtml(e.message || String(e))}</span>`);
  }
}

$("btn-upd-check").onclick = () => updCheck(false);
$("btn-upd-save").onclick = () => {
  const v = ($("upd-source").value || "").trim().replace(/\/+$/, "");
  updRememberSource(v);
  toast(v ? "更新源已保存" : "已清空更新源");
};
$("btn-upd-import").onclick = () => $("upd-file").click();
$("upd-file").onchange = (e) => {
  const f = e.target.files && e.target.files[0];
  e.target.value = "";
  if (f) updImport(f);
};

// ---------- 设置视图 ----------
async function renderSettings() {
  const s = S.settings;
  // 版本信息只取一次，之后靠检查更新刷新
  if (!UPD.cur) updInit();
  $("set-mod-notice").checked = s.modules?.notice !== false;
  $("set-mod-exam").checked = s.modules?.exam !== false;
  $("set-throttle").value = String(s.manualThrottleSec ?? 15);
  // §7.2 登录自动刷新
  $("set-login-auto").checked = s.loginAutoRefresh !== false;
  $("set-login-interval").value = String(s.loginRefreshIntervalSec ?? 15);
  $("set-login-interval").disabled = s.loginAutoRefresh === false;
  // §7.6 缓存清理（互斥置灰）
  const cmode = s.cacheMode ?? "time";
  document.querySelector(`input[name="cache-mode"][value="${cmode}"]`).checked = true;
  $("set-cache-days").value = String(s.cacheDays ?? 7);
  $("set-cache-limit").value = s.cacheLimitMB ?? 200;
  $("set-cache-days").disabled = cmode !== "time";
  $("set-cache-limit").disabled = cmode !== "size";
  bridge.call("cache.stats").then((st) => { $("cache-size").textContent = st.sizeMB + " MB"; }).catch(() => {});
  // §7.1 账号信息
  const meta2 = S.account?.meta || {};
  $("acct-nick").textContent = meta2.nickname || (meta2.uid ? `账号 ${meta2.uid}` : "已登录");
  $("acct-school").textContent = meta2.school || "";
  const av2 = $("acct-avatar");
  if (meta2.avatar) { av2.style.backgroundImage = `url("${meta2.avatar}")`; av2.textContent = ""; }
  else { av2.style.backgroundImage = ""; av2.textContent = "学"; }
  const td = s.timeDisplay ?? "remainingHours";
  $("set-time-remaining").checked = td === "remainingHours" || td === "both";
  $("set-time-deadline").checked = td === "deadline" || td === "both";

  // 悬浮球图案预览（§7.5）：未自定义时展示程序内置默认图案
  const bp = $("ball-preview");
  if (s.ballImage) {
    bp.style.backgroundImage = `url("https://cxball.assets/${s.ballImage}")`;
    bp.textContent = "";
  } else {
    bp.style.backgroundImage = 'url("https://cxball.app/icon.png")';
    bp.style.backgroundSize = "cover";
    bp.textContent = "";
  }

  // 个性化：背景图与透明度
  $("bg-current").textContent = s.background?.image ? `当前：${s.background.image}` : "未设置背景图";
  $("set-bg-opacity").value = s.background?.opacity ?? 75;
  $("bg-opacity-val").textContent = (s.background?.opacity ?? 75) + "%";
  $("set-mod-opacity").value = s.moduleOpacity ?? 92;
  $("mod-opacity-val").textContent = (s.moduleOpacity ?? 92) + "%";
  $("set-autostart").checked = s.autostart === true;   // §7.5 开机自启动，默认不勾选

  // 账号清除键状态（§7.7：仅 1 个账号时「清除多余账号」置灰）
  try {
    const st = await bridge.call("accounts.stats");
    S.acctStats = st;
    $("btn-clear-surplus").disabled = !st.others;
    $("btn-clear-accounts").disabled = !st.total;
    $("btn-clear-all").disabled = !st.total && !st.ignored;
  } catch { S.acctStats = { total: 0, others: 0, ignored: 0 }; }

  // 课程选择（§7.4）：已选 / 未选 两组，未选默认折叠
  renderCourseGroups();

  // 悬浮球 / 面板大小
  winPaint();
}

/// 渲染课程两组：已选中在上、未选中在下（后者默认折叠）。勾选切换即时移动条目。
function renderCourseGroups() {
  const courses = S.snapshot?.courses || [];
  const deselected = new Set(S.account?.state?.deselectedCourses || []);
  const checkedBox = $("course-checked"), uncheckedBox = $("course-unchecked");
  checkedBox.innerHTML = ""; uncheckedBox.innerHTML = "";
  let nChecked = 0, nUnchecked = 0;
  for (const c of courses) {
    const on = !deselected.has(c.courseId);
    const row = document.createElement("label");
    row.className = "row";
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = on;
    cb.onchange = () => toggleCourse(c.courseId, cb.checked);
    row.appendChild(cb);
    row.appendChild(document.createTextNode(" " + (c.courseName || c.courseId)));
    (on ? checkedBox : uncheckedBox).appendChild(row);
    if (on) nChecked++; else nUnchecked++;
  }
  $("checked-count").textContent = nChecked;
  $("unchecked-count").textContent = nUnchecked;
  if (!courses.length) checkedBox.innerHTML = `<div class="empty-tip">暂无课程数据，请先刷新</div>`;
  // 未选为空时不给折叠入口（避免空分组）
  $("group-unchecked-wrap").style.display = nUnchecked ? "" : "none";
}

/// 单课程勾选切换：本地先行更新并即时移动分组，再落盘（失败不回滚，下次刷新以后端为准）。
async function toggleCourse(cid, checked) {
  const st = (S.account.state ??= {});
  const set = new Set(st.deselectedCourses || []);
  if (checked) set.delete(cid); else set.add(cid);
  st.deselectedCourses = [...set];
  renderCourseGroups();
  renderPanel();
  try {
    await bridge.call("courses.setDeselected", { courseIds: st.deselectedCourses });
  } catch { /* 静默：保持本地状态 */ }
}

// ---------- 登录进度条（§8.1）----------
// 用户在登录窗提交后（C# 监听顶层跳转发 login.submitting）开始显示。
// 时长预估：登录校验 + 课程列表 + 每门课作业请求（首次默认 15 门）；真实完成时补齐到 100%。
let _loginTick = null;
const LOGIN_BASE_MS = 4000;      // 登录校验 + 课程列表 + 元数据
const LOGIN_PER_COURSE_MS = 900; // 单门课程作业请求（含 300–500ms 串行节流）

function loginEstimateMs() {
  const known = (S.snapshot?.courses || []).length;
  const count = known || 15;   // 首次登录按默认勾选的 15 门估算
  return LOGIN_BASE_MS + count * LOGIN_PER_COURSE_MS;
}

function startLoginProgress() {
  const wrap = $("login-progress"), bar = $("login-progress-bar");
  if (!wrap || !bar) return;
  const est = loginEstimateMs();
  wrap.classList.remove("hidden");
  bar.style.transition = "none";
  bar.style.width = "0%";
  const t0 = performance.now();
  clearInterval(_loginTick);
  // 缓出曲线推进：起步快、越接近预估终点越慢，停在 92% 等真实结果，避免「假完成」
  _loginTick = setInterval(() => {
    const p = Math.min((performance.now() - t0) / est, 1);
    bar.style.width = (92 * (1 - Math.pow(1 - p, 2.2))).toFixed(1) + "%";
  }, 80);
}

function finishLoginProgress() {
  const wrap = $("login-progress"), bar = $("login-progress-bar");
  if (!wrap || !bar) return;
  clearInterval(_loginTick); _loginTick = null;
  bar.style.transition = "width .26s cubic-bezier(.25, .8, .35, 1)";
  bar.style.width = "100%";
  setTimeout(() => {
    wrap.classList.add("hidden");
    bar.style.transition = "none";
    bar.style.width = "0%";
  }, 460);
}

/// 登录取消/失败：直接收起进度条，不显示「假完成」
function resetLoginProgress() {
  clearInterval(_loginTick); _loginTick = null;
  const wrap = $("login-progress"), bar = $("login-progress-bar");
  if (!wrap || !bar) return;
  wrap.classList.add("hidden");
  bar.style.transition = "none";
  bar.style.width = "0%";
}

bridge.on("login.submitting", () => startLoginProgress());

// ---------- 事件绑定 ----------
$("btn-login").onclick = async () => {
  $("btn-login").disabled = true;
  try {
    const r = await bridge.call("login.open");
    if (r.loggedIn) {
      await reloadInit();
      // §4.1：登录成功即视为一次登录事件，按设置自动刷新；进度条等真实完成后再补满
      if (S.settings?.loginAutoRefresh !== false) await doRefresh({ login: true, quiet: true });
      finishLoginProgress();
      show("view-panel");
      renderPanel();
    } else resetLoginProgress();
  } catch (e) { toast(e.message || "登录失败"); resetLoginProgress(); }
  finally { $("btn-login").disabled = false; }
};

$("btn-refresh").onclick = () => doRefresh();
$("btn-settings").onclick = () => { renderSettings(); switchView("view-panel", "view-settings"); };
$("btn-back").onclick = () => { switchView("view-settings", "view-panel"); renderPanel(); };

// 模块折叠（消息默认折叠，§8.2.2）：切换内容显隐并同步标题箭头
function toggleCollapse(arrowId, contentId) {
  const list = $(contentId);
  list.classList.toggle("hidden");
  const arrow = $(arrowId);
  if (arrow) arrow.textContent = list.classList.contains("hidden") ? "▸" : "▾";
}
$("exam-title").onclick = () => toggleCollapse("exam-arrow", "exam-empty");
$("notice-title").onclick = () => toggleCollapse("notice-arrow", "notice-list");

// 悬浮球右键菜单动作（§8.3：刷新 / 设置 / 退出登录）
bridge.on("menu.action", (p) => {
  if (p?.name === "refresh") doRefresh();
  else if (p?.name === "settings") { renderSettings(); switchView("view-panel", "view-settings"); }
  else if (p?.name === "logout") $("btn-logout").onclick();
});

// 账号元数据后台补抓完成（§3.1）：更新昵称/头像/学校
bridge.on("account.updated", (p) => {
  if (!p?.meta || !S.account) return;
  S.account.meta = p.meta;
  renderPanel();
  // 若用户正停留在设置页，账号卡同步刷新
  if (!$("view-settings").classList.contains("hidden")) renderSettings();
});

$("set-mod-notice").onchange = (e) => saveSettings({ modules: { notice: e.target.checked } });
$("set-mod-exam").onchange = (e) => saveSettings({ modules: { exam: e.target.checked } });
// §7.2 登录自动刷新
$("set-login-auto").onchange = (e) => {
  $("set-login-interval").disabled = !e.target.checked;
  saveSettings({ loginAutoRefresh: e.target.checked });
};
$("set-login-interval").onchange = (e) =>
  saveSettings({ loginRefreshIntervalSec: parseInt(e.target.value, 10) });
// §7.6 缓存清理
document.querySelectorAll('input[name="cache-mode"]').forEach((r) => {
  r.onchange = (e) => {
    const m = e.target.value;
    $("set-cache-days").disabled = m !== "time";
    $("set-cache-limit").disabled = m !== "size";
    saveSettings({ cacheMode: m });
  };
});
$("set-cache-days").onchange = (e) => saveSettings({ cacheDays: parseInt(e.target.value, 10) });
$("set-cache-limit").onchange = (e) => {
  const v = parseInt(e.target.value, 10);
  if (isNaN(v) || v < 100) {
    toast("缓存大小最小 100 MB");
    e.target.value = String(S.settings.cacheLimitMB ?? 200);
    return;
  }
  saveSettings({ cacheLimitMB: v });
};
$("set-throttle").onchange = async (e) => {
  const v = parseInt(e.target.value, 10);
  if (v <= 10 && !(await cxConfirm("不建议：刷新间隔过短会增大平台风控判定风险。\n仍要设置为 " + v + " 秒吗？"))) {
    e.target.value = String(S.settings.manualThrottleSec ?? 15);
    return;
  }
  await saveSettings({ manualThrottleSec: v });
};
// 作业时间显示：两个勾选框组合成 remainingHours | deadline | both | none
const saveTimeDisplay = () => {
  const r = $("set-time-remaining").checked, d = $("set-time-deadline").checked;
  saveSettings({ timeDisplay: r && d ? "both" : r ? "remainingHours" : d ? "deadline" : "none" });
};
$("set-time-remaining").onchange = saveTimeDisplay;
$("set-time-deadline").onchange = saveTimeDisplay;
$("course-all").onclick = async () => {
  const st = (S.account.state ??= {});
  st.deselectedCourses = [];
  renderCourseGroups();
  try { await bridge.call("courses.setDeselected", { courseIds: [] }); } catch {}
  renderPanel();
};
$("course-none").onclick = async () => {
  const st = (S.account.state ??= {});
  st.deselectedCourses = (S.snapshot?.courses || []).map((c) => c.courseId).filter(Boolean);
  renderCourseGroups();
  try { await bridge.call("courses.setDeselected", { courseIds: st.deselectedCourses }); } catch {}
  renderPanel();
};
// 未选中分组：点击标题折叠 / 展开（默认折叠）
$("group-unchecked-title").onclick = () => {
  const wrap = $("group-unchecked-wrap");
  wrap.classList.toggle("collapsed");
  const collapsed = wrap.classList.contains("collapsed");
  $("group-unchecked-title").innerHTML =
    `未选中 (<span id="unchecked-count">${$("unchecked-count").textContent}</span>) ${collapsed ? "▸" : "▾"}`;
};

// ---------- 图片裁剪（§7.5）----------
// 流程：选图 → 内存载入（FileReader 只读字节）→ 弹窗裁剪 → 确定 → canvas 导出 → assets.upload。
// 全程不向源文件路径写入，用户原始图片零改动（无临时落盘、无需事后清理）。
const CROP_PRESET = {
  ball:       { title: "裁剪悬浮球图案", ratio: 1,     outCap: 512, mime: "image/png",  outName: "ball.png" },
  background: { title: "裁剪背景图",     ratio: 5 / 8, outCap: 800, mime: "image/jpeg", outName: "background.jpg" },
};
const CROP = { kind: null, img: null, ratio: 1, scale: 1, dispW: 0, dispH: 0, x: 0, y: 0, w: 0, h: 0, drag: null };

function openCrop(kind, file) {
  const preset = CROP_PRESET[kind];
  const fr = new FileReader();
  fr.onerror = () => toast("无法读取该图片");
  fr.onload = () => {
    const img = new Image();
    img.onerror = () => toast("无法读取该图片");
    img.onload = () => {
      if (!img.naturalWidth || !img.naturalHeight) { toast("无法读取该图片"); return; }
      CROP.kind = kind; CROP.img = img; CROP.ratio = preset.ratio;
      // 等比缩放到弹窗可视尺寸（最长边 320 × 300），显示坐标靠 scale 映射回原图
      CROP.scale = Math.min(320 / img.naturalWidth, 300 / img.naturalHeight, 1);
      CROP.dispW = Math.round(img.naturalWidth * CROP.scale);
      CROP.dispH = Math.round(img.naturalHeight * CROP.scale);
      $("crop-title").textContent = preset.title;
      $("crop-img").src = img.src;
      const stage = $("crop-stage");
      stage.style.width = CROP.dispW + "px";
      stage.style.height = CROP.dispH + "px";
      resetCropFrame();
      $("crop-overlay").classList.remove("hidden");
    };
    img.src = String(fr.result);
  };
  fr.readAsDataURL(file);
}

function resetCropFrame() {
  const r = CROP.ratio;
  let w = CROP.dispW * 0.9, h = w / r;
  if (h > CROP.dispH * 0.9) { h = CROP.dispH * 0.9; w = h * r; }
  CROP.w = Math.round(w); CROP.h = Math.round(h);
  CROP.x = Math.round((CROP.dispW - CROP.w) / 2);
  CROP.y = Math.round((CROP.dispH - CROP.h) / 2);
  paintCropFrame();
}

function paintCropFrame() {
  const f = $("crop-frame");
  f.style.left = CROP.x + "px";  f.style.top = CROP.y + "px";
  f.style.width = CROP.w + "px"; f.style.height = CROP.h + "px";
}

// 四角拖拽：锁定比例、以对角为锚点；用【位移增量】驱动尺寸，
// 而不是把指针绝对坐标当作新角点——否则按下的瞬间框会被吸附到指针处，出现跳变。
const CROP_CORNER = { se: [1, 1], ne: [1, -1], sw: [-1, 1], nw: [-1, -1] };
function resizeCropFrame(corner, d, dx, dy) {
  const [sx, sy] = CROP_CORNER[corner];
  const r = CROP.ratio;
  const ax = sx > 0 ? d.x : d.x + d.w;   // 锚点 x（对角，拖拽期间固定）
  const ay = sy > 0 ? d.y : d.y + d.h;   // 锚点 y
  const maxW = Math.min(sx > 0 ? CROP.dispW - ax : ax, (sy > 0 ? CROP.dispH - ay : ay) * r);
  // 取位移较大的轴驱动尺寸（统一换算成宽度量纲），dx=dy=0 时结果恰为 d.w，按下不跳变
  let w = Math.abs(dx) >= Math.abs(dy) * r ? d.w + sx * dx : d.w + sy * dy * r;
  w = Math.max(Math.min(w, maxW), Math.min(36, maxW));
  const h = w / r;
  CROP.w = Math.round(w); CROP.h = Math.round(h);
  CROP.x = Math.round(sx > 0 ? ax : ax - w);
  CROP.y = Math.round(sy > 0 ? ay : ay - h);
  paintCropFrame();
}

const cropStage = $("crop-stage");
cropStage.onpointerdown = (e) => {
  const handle = e.target.classList?.contains("crop-handle") ? e.target.dataset.h : null;
  CROP.drag = handle
    ? { mode: "resize", corner: handle, px: e.clientX, py: e.clientY, x: CROP.x, y: CROP.y, w: CROP.w, h: CROP.h }
    : { mode: "move", px: e.clientX, py: e.clientY, x: CROP.x, y: CROP.y };
  cropStage.setPointerCapture(e.pointerId);
  e.preventDefault();
};
cropStage.onpointermove = (e) => {
  const d = CROP.drag; if (!d) return;
  const dx = e.clientX - d.px, dy = e.clientY - d.py;
  if (d.mode === "move") {
    CROP.x = Math.round(Math.min(Math.max(d.x + dx, 0), CROP.dispW - CROP.w));
    CROP.y = Math.round(Math.min(Math.max(d.y + dy, 0), CROP.dispH - CROP.h));
    paintCropFrame();
  } else resizeCropFrame(d.corner, d, dx, dy);
};
cropStage.onpointerup = cropStage.onpointercancel = () => { CROP.drag = null; };

$("btn-crop-cancel").onclick = () => $("crop-overlay").classList.add("hidden");
$("btn-crop-reset").onclick = resetCropFrame;
$("btn-crop-ok").onclick = async () => {
  if (!CROP.img) return;
  const preset = CROP_PRESET[CROP.kind];
  // 显示坐标 → 原图自然坐标
  const sx = CROP.x / CROP.scale, sy = CROP.y / CROP.scale;
  const sw = CROP.w / CROP.scale, sh = CROP.h / CROP.scale;
  // 输出分辨率：取裁剪区实际像素，超过上限则等比缩小
  const ow = Math.min(Math.round(sw), preset.outCap);
  const oh = Math.round(ow / CROP.ratio);
  const cv = document.createElement("canvas");
  cv.width = ow; cv.height = oh;
  cv.getContext("2d").drawImage(CROP.img, sx, sy, sw, sh, 0, 0, ow, oh);
  const dataBase64 = cv.toDataURL(preset.mime, 0.92).split(",")[1] || "";
  $("crop-overlay").classList.add("hidden");
  try {
    const r = await bridge.call("assets.upload", { kind: CROP.kind, name: preset.outName, dataBase64 });
    if (CROP.kind === "ball") S.settings.ballImage = r.file;
    else (S.settings.background ??= {}).image = r.file;
    renderSettings();
    if (CROP.kind === "background") applyBackground();
    toast(CROP.kind === "ball" ? "悬浮球图案已更新" : "背景图已更新");
  } catch (err) { toast(err.message || "上传失败"); }
};

$("btn-ball-upload").onclick = () => $("file-ball").click();
$("file-ball").onchange = (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  if (f.size > 15 * 1024 * 1024) { toast("悬浮球图案最大 15MB，请更换图片"); return; }
  openCrop("ball", f);
};
$("btn-ball-reset").onclick = async () => {
  await bridge.call("assets.reset", { kind: "ball" });
  S.settings.ballImage = null;
  renderSettings();
  toast("已恢复默认图案");
};

$("btn-bg-upload").onclick = () => $("file-bg").click();
$("file-bg").onchange = async (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  if (f.size > 30 * 1024 * 1024 &&
      !(await cxConfirm("图片超过 30MB，建议更换以获得更流畅的体验。\n仍要继续使用吗？"))) return;
  openCrop("background", f);
};
$("btn-bg-reset").onclick = async () => {
  await bridge.call("assets.reset", { kind: "background" });
  if (S.settings.background) S.settings.background.image = null;
  renderSettings();
  applyBackground();
};

// 透明度滑块：拖动实时预览，松手才落盘（§7.5 默认 75%）
$("set-bg-opacity").oninput = (e) => {
  const v = parseInt(e.target.value, 10);
  $("bg-opacity-val").textContent = v + "%";
  (S.settings.background ??= {}).opacity = v;
  applyBackground();
};
$("set-bg-opacity").onchange = (e) =>
  saveSettings({ background: { opacity: parseInt(e.target.value, 10) } });

// 模块透明度滑块：拖动实时预览，松手才落盘（§7.5 默认 92%）
$("set-mod-opacity").oninput = (e) => {
  const v = parseInt(e.target.value, 10);
  $("mod-opacity-val").textContent = v + "%";
  S.settings.moduleOpacity = v;
  applyModuleOpacity();
};
$("set-mod-opacity").onchange = (e) =>
  saveSettings({ moduleOpacity: parseInt(e.target.value, 10) });

// 开机自启动（§7.5 默认不勾选）：直接写注册表并落盘
$("set-autostart").onchange = async (e) => {
  const enabled = e.target.checked;
  try {
    const s = await bridge.call("app.autostart", { enabled });
    S.settings.autostart = s.autostart === true;
    e.target.checked = S.settings.autostart;
    toast(enabled ? "已开启开机自启动" : "已关闭开机自启动");
  } catch (err) {
    e.target.checked = !enabled;
    toast("设置失败：" + (err?.message || "未知错误"));
  }
};

// ---------- 三个清除键（§7.7：2 / 2 / 3 次确认） ----------
$("btn-clear-surplus").onclick = async () => {
  const n = S.acctStats?.others ?? 0;
  const nick = S.account?.meta?.nickname || S.account?.meta?.uid || "当前账号";
  if (!(await cxConfirm(`确认后本地只保留当前账号「${nick}」的登录数据，其余 ${n} 个账号的会话、作业快照与配置将全部删除，不可恢复。`, true))) return;
  if (!(await cxConfirm(`再次确认：将清除 ${n} 个多余账号，删除后不可恢复。`, true))) return;
  try {
    const r = await bridge.call("clear.surplus");
    toast(`已清除 ${r.removed ?? 0} 个多余账号`);
    renderSettings();
  } catch (e) { toast(e.message || "清除失败"); }
};

$("btn-clear-accounts").onclick = async () => {
  if (!(await cxConfirm("确认后本地全部账号数据将被删除，当前账号会被强制退出，需要重新登录才能使用。此操作不可恢复。", true))) return;
  if (!(await cxConfirm("再次确认：删除全部账号并强制退出登录？", true))) return;
  try {
    await bridge.call("clear.allAccounts");
    S.account = null;
    S.snapshot = null;
    show("view-login");
    toast("已清除全部账号，请重新登录");
  } catch (e) { toast(e.message || "清除失败"); }
};

$("btn-clear-all").onclick = async () => {
  const n = S.acctStats?.total ?? 0, m = S.acctStats?.ignored ?? 0;
  if (!(await cxConfirm(`将删除全部账号、设置、隐藏规则与日志，软件回到初始状态。\n此操作会删除 ${n} 个账号、${m} 条隐藏规则、全部浏览缓存。`, true))) return;
  if (!(await cxConfirm("删除后无法恢复，也无法通过重新登录找回设置与规则。\n作业快照与账号数据将永久丢失。", true))) return;
  if (!(await cxConfirm("确认执行删除？这是最后一次确认。\n点击后立即开始删除，无法中止。", true))) return;
  try {
    await bridge.call("clear.allData");
    toast("正在清除全部数据，软件即将退出", 6000);
  } catch (e) { toast(e.message || "清除失败"); }
};

$("btn-logout").onclick = async () => {
  if (!(await cxConfirm("退出登录将清除当前会话，需要重新登录。确定退出吗？", true))) return;
  await bridge.call("logout");
  S.account = null;
  S.snapshot = null;
  show("view-login");
};

async function saveSettings(patch) {
  S.settings = await bridge.call("settings.set", { patch });
  renderPanel();
}

// ---------- AI 答题助手 ----------
// 直连用户自备的 OpenAI 兼容接口（DeepSeek / Kimi / 通义 / 智谱 / 硅基流动 / 自定义）。
// 不做任何中转：请求只发往配置里的接口地址，Key 只落本机 localStorage（轻度混淆，非加密）。
const AI_STORE_KEY = "cxball.ai.v1";
const AI_DEFAULT_CFG = {
  provider: "deepseek",
  baseUrl: "https://api.deepseek.com",
  model: "deepseek-flash",
  key: "",
  autoPaste: true,
  kind: "auto",
  mode: "both",
  // 深度思考对计算/逻辑题提升明显，新装用户默认开；老的配置不会被改动
  think: true,
  verify: true,
};
const AI_PRESETS = {
  deepseek: { label: "DeepSeek", baseUrl: "https://api.deepseek.com", models: ["deepseek-flash", "deepseek-v4-pro"] },
  kimi: { label: "Kimi 月之暗面", baseUrl: "https://api.moonshot.cn/v1", models: ["moonshot-v1-8k", "moonshot-v1-32k", "moonshot-v1-8k-vision-preview"] },
  qwen: { label: "通义千问", baseUrl: "https://dashscope.aliyuncs.com/compatible-mode/v1", models: ["qwen-plus", "qwen-max", "qwen-vl-max"] },
  glm: { label: "智谱 GLM", baseUrl: "https://open.bigmodel.cn/api/paas/v4", models: ["glm-4-flash", "glm-4-plus", "glm-4v-plus"] },
  silicon: { label: "硅基流动", baseUrl: "https://api.siliconflow.cn/v1", models: ["deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-VL-72B-Instruct"] },
  custom: { label: "自定义", baseUrl: "", models: [] },
};
const AI_KIND_LABEL = { auto: "", single: "单选题", multi: "多选题", judge: "判断题", blank: "填空题", short: "简答题" };
// DeepSeek 的旧模型名（deepseek-chat / deepseek-reasoner / deepseek-v4-flash）已统一路由到
// DeepSeek-V4.1-Flash，官方现用模型名为 deepseek-flash。读配置时自动迁移，避免历史配置报 404。
const AI_MODEL_ALIAS = {
  "deepseek-chat": "deepseek-flash",
  "deepseek-reasoner": "deepseek-flash",
  "deepseek-v4-flash": "deepseek-flash",
  "deepseek-v4-flash-vision-exp": "deepseek-flash",
};
// DeepSeek V4 默认开启思考模式；答题场景默认关掉以换取速度，「深度思考」勾选后不传参即用服务端默认
function aiIsDeepSeek(baseUrl) {
  return /(^|\/\/|\.)api\.deepseek\.com/i.test(String(baseUrl || ""));
}
const AI = { cfg: null, images: [], busy: false, ctrl: null, raw: "", reason: "" };

// ---------- 用量、费用与余额 ----------
// 单价：元 / 百万 tokens，数组为 [空闲时段, 高峰时段]。
// 高峰 = 北京时间周一至周五 9:00-12:00、14:00-18:00（官方说明不含法定节假日，这里不判断节日）。
// 价格来自 DeepSeek 官方「模型 & 价格」页，仅用于本机估算，实际以账单为准。
const AI_PRICE = {
  "deepseek-flash": { hit: [0.02, 0.04], miss: [1, 2], out: [4, 8] },
  "deepseek-v4-pro": { hit: [0.15, 0.3], miss: [4.5, 9], out: [13.5, 27] },
};
const USAGE_KEY = "cxball.usage.v1";
const USAGE = { cur: null, acc: null };

function aiPeakNow() {
  // 用 UTC 偏移量换算成北京时间，避免依赖系统时区设置
  const t = new Date(Date.now() + (new Date().getTimezoneOffset() + 480) * 60000);
  const d = t.getDay();
  if (d === 0 || d === 6) return false;
  const h = t.getHours();
  return (h >= 9 && h < 12) || (h >= 14 && h < 18);
}

function aiPriceOf(model) {
  const m = String(model || "").toLowerCase();
  if (AI_PRICE[m]) return AI_PRICE[m];
  if (/deepseek/.test(m) && /pro/.test(m)) return AI_PRICE["deepseek-v4-pro"];
  if (/deepseek/.test(m)) return AI_PRICE["deepseek-flash"];
  return null;
}

// 各家字段略有差异：DeepSeek 给 prompt_cache_hit_tokens，OpenAI 给 prompt_tokens_details.cached_tokens
function aiUsageNorm(j) {
  const u = j?.usage || {};
  const pt = Number(u.prompt_tokens) || 0;
  const ct = Number(u.completion_tokens) || 0;
  if (!pt && !ct) return null;
  const hit = Number(u.prompt_cache_hit_tokens ?? u.prompt_tokens_details?.cached_tokens ?? 0) || 0;
  const missRaw = u.prompt_cache_miss_tokens;
  const miss = Number(missRaw == null ? Math.max(0, pt - hit) : missRaw) || 0;
  return { pt, ct, hit, miss, total: Number(u.total_tokens) || pt + ct };
}

function aiCostOf(u, model) {
  const p = aiPriceOf(model);
  if (!p || !u) return null;
  const i = aiPeakNow() ? 1 : 0;
  return (u.hit * p.hit[i] + u.miss * p.miss[i] + u.ct * p.out[i]) / 1e6;
}

function usageToday() {
  return new Date().toLocaleDateString("sv");   // sv 语言环境输出 YYYY-MM-DD
}

function usageLoad() {
  if (USAGE.acc) return USAGE.acc;
  let a = { calls: 0, pt: 0, ct: 0, cost: 0, days: {} };
  try {
    const o = JSON.parse(localStorage.getItem(USAGE_KEY) || "null");
    if (o && typeof o === "object") a = { ...a, ...o, days: o.days || {} };
  } catch { /* 统计损坏就重新开始，不影响答题 */ }
  USAGE.acc = a;
  return a;
}

function usageReset() {
  USAGE.cur = { calls: 0, pt: 0, ct: 0, cost: 0, total: 0, model: "" };
  usagePaint();
}

// 每次请求成功后调一次：本次累积 + 历史累积 + 按天记账
function usageAdd(u, model) {
  if (!u) return;
  const cost = aiCostOf(u, model) || 0;
  if (!USAGE.cur) usageReset();
  const cur = USAGE.cur;
  cur.calls++; cur.pt += u.pt; cur.ct += u.ct; cur.total += u.total; cur.cost += cost; cur.model = model || cur.model;

  const a = usageLoad();
  const day = usageToday();
  a.calls++; a.pt += u.pt; a.ct += u.ct; a.cost += cost;
  a.days[day] = a.days[day] || { calls: 0, pt: 0, ct: 0, cost: 0 };
  const d = a.days[day];
  d.calls++; d.pt += u.pt; d.ct += u.ct; d.cost += cost;
  // 只留最近 120 天，避免 localStorage 越写越大
  const keys = Object.keys(a.days).sort();
  while (keys.length > 120) delete a.days[keys.shift()];
  try { localStorage.setItem(USAGE_KEY, JSON.stringify(a)); } catch { /* 配额满就算了 */ }
  usagePaint();
}

function fmtMoney(v) {
  if (v == null) return "—";
  if (!v) return "¥0.0000";
  if (v < 0.0001) return "¥<0.0001";
  return "¥" + v.toFixed(4);
}
function fmtNum(v) {
  const n = Number(v) || 0;
  if (n >= 1e6) return (n / 1e4).toFixed(1) + " 万";
  return n.toLocaleString("en-US");
}

function usagePaint() {
  const a = usageLoad();
  const cur = USAGE.cur;
  const day = a.days[usageToday()] || { cost: 0, pt: 0, ct: 0, calls: 0 };
  if ($("usage-cost")) $("usage-cost").textContent = cur && cur.calls ? fmtMoney(cur.cost) : "—";
  if ($("usage-tok")) $("usage-tok").textContent = cur && cur.calls ? fmtNum(cur.total) : "—";
  if ($("usage-day")) $("usage-day").textContent = fmtMoney(day.cost || 0);
  if ($("usage-all")) $("usage-all").textContent = fmtMoney(a.cost || 0);
  if ($("usage-hint")) {
    const p = aiPriceOf((AI.cfg || aiLoadCfg()).model || "");
    $("usage-hint").textContent = p
      ? `费用按官方价估算（当前${aiPeakNow() ? "高峰" : "空闲"}时段：输出 ${p.out[aiPeakNow() ? 1 : 0]} 元/百万 tokens），实际以账单为准。`
      : "当前模型没有内置价格表，只统计 tokens 不估算费用；余额仅 DeepSeek 支持查询。";
  }
}

// 余额：DeepSeek 的 /user/balance 与 chat 接口同域，浏览器可直连
async function usageBalance(notify = false) {
  const c = AI.cfg || aiLoadCfg();
  const pill = $("usage-pill");
  const line = $("usage-balance");
  if (!c.key || !aiIsDeepSeek(c.baseUrl)) {
    if (pill) { pill.textContent = "不支持查询"; pill.classList.add("off"); }
    if (line) line.innerHTML = "余额：<b>—</b> <span class=\"muted\">仅 DeepSeek 支持查询</span>";
    return;
  }
  if (pill) { pill.textContent = "查询中…"; pill.classList.add("off"); }
  try {
    const base = String(c.baseUrl).replace(/\/+$/, "").replace(/\/v\d+$/i, "");
    const r = await fetch(base + "/user/balance", { headers: { Authorization: "Bearer " + c.key }, cache: "no-store" });
    if (!r.ok) throw new Error(aiHttpError(r.status, await r.text().catch(() => "")));
    const j = await r.json();
    const infos = j.balance_infos || [];
    const cny = infos.find((x) => String(x.currency || "").toUpperCase() === "CNY") || infos[0];
    if (!cny) throw new Error("接口没返回余额信息");
    const total = Number(cny.total_balance) || 0;
    const gift = Number(cny.granted_balance) || 0;
    const top = Number(cny.topped_up_balance) || 0;
    if (line) {
      line.innerHTML =
        `余额：<b>¥${total.toFixed(2)}</b>` +
        `<span class="muted">（充值 ${top.toFixed(2)} · 赠送 ${gift.toFixed(2)}）</span>` +
        (j.is_available === false ? ' <span class="usage-warn">账户不可用</span>' : "");
    }
    if (pill) { pill.textContent = "¥" + total.toFixed(2); pill.classList.remove("off"); }
    if (notify) toast("余额 ¥" + total.toFixed(2));
  } catch (e) {
    if (pill) { pill.textContent = "查询失败"; pill.classList.add("off"); }
    if (line) line.innerHTML = `余额：<b>—</b> <span class="muted">${escapeHtml(aiErrText(e))}</span>`;
    if (notify) toast("余额查询失败：" + aiErrText(e), 5000);
  }
}


// Key 轻度混淆：XOR + Base64。仅防肉眼扫到，不是加密。
function aiMask(text) {
  const k = "cxball-ai-2026", bytes = new TextEncoder().encode(String(text));
  let bin = "";
  for (let i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i] ^ k.charCodeAt(i % k.length));
  return btoa(bin);
}
function aiUnmask(b64) {
  try {
    const bin = atob(String(b64 || "")), k = "cxball-ai-2026", out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i) ^ k.charCodeAt(i % k.length);
    return new TextDecoder().decode(out);
  } catch { return ""; }
}

function aiLoadCfg() {
  const cfg = { ...AI_DEFAULT_CFG };
  try {
    const o = JSON.parse(localStorage.getItem(AI_STORE_KEY) || "null");
    if (o) {
      Object.assign(cfg, o);
      if (o.keyEnc) cfg.key = aiUnmask(o.keyEnc);
      delete cfg.keyEnc;
    }
  } catch { /* 配置损坏时回落到默认值 */ }
  // 旧配置自愈：模型名换成现行名，接口地址去掉已不需要的 /v1
  const alias = AI_MODEL_ALIAS[String(cfg.model || "").trim()];
  if (alias) cfg.model = alias;
  if (aiIsDeepSeek(cfg.baseUrl)) {
    const b = String(cfg.baseUrl).trim().replace(/\/+$/, "").replace(/\/v\d+$/i, "");
    cfg.baseUrl = /^https?:\/\//i.test(b) ? b : AI_PRESETS.deepseek.baseUrl;
  }
  AI.cfg = cfg;
  return cfg;
}
function aiSaveCfg(patch) {
  if (!AI.cfg) aiLoadCfg();
  Object.assign(AI.cfg, patch || {});
  const o = { ...AI.cfg, keyEnc: AI.cfg.key ? aiMask(AI.cfg.key) : "" };
  delete o.key;
  try { localStorage.setItem(AI_STORE_KEY, JSON.stringify(o)); } catch { /* 隐私模式等写入失败可忽略 */ }
  aiPaintStatus();
}

function aiPaintStatus() {
  const c = AI.cfg || {};
  const ok = !!(c.key && c.baseUrl && c.model);
  const pill = $("ai-pill");
  pill.textContent = ok ? c.model : "未配置";
  pill.title = ok ? `${c.baseUrl} · ${c.model}` : "点下方「模型设置」填入 Key";
  pill.classList.toggle("off", !ok);
}

function aiFillProviders() {
  const sel = $("ai-provider");
  sel.innerHTML = Object.entries(AI_PRESETS)
    .map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("");
}
function aiFillModels(models) {
  $("ai-models").innerHTML = (models || []).map((m) => `<option value="${m}"></option>`).join("");
}

function aiPaintForm() {
  const c = AI.cfg || aiLoadCfg();
  aiFillProviders();
  $("ai-provider").value = AI_PRESETS[c.provider] ? c.provider : "custom";
  $("ai-base").value = c.baseUrl || "";
  $("ai-model").value = c.model || "";
  $("ai-key").value = c.key || "";
  $("ai-auto-paste").checked = c.autoPaste !== false;
  $("ai-think").checked = !!c.think;
  $("ai-kind").value = c.kind || "auto";
  $("ai-mode").value = c.mode || "both";
  aiFillModels(AI_PRESETS[$("ai-provider").value]?.models);
}

function aiToggleCfg(open) {
  const body = $("ai-cfg-body");
  const want = open === undefined ? body.classList.contains("hidden") : !!open;
  body.classList.toggle("hidden", !want);
  $("ai-cfg-arrow").textContent = want ? "▾" : "▸";
}

// 提示词：把「只输出答案」这件事钉死，否则模型容易长篇大论
function aiSystemPrompt() {
  const answerOnly = (AI.cfg?.mode || "both") === "answer";
  const rules = [
    "你是学习通课程的作业助手，帮学生完成客观题（选择、填空、判断）。",
    "作答纪律（在内部执行，不要写出来）：",
    "· 先确认问的是什么：注意「不属于」「错误的是」「不包括」「除了」「至少」「最多」这类反向或边界问法。",
    "· 每个选项都读一遍再定，不要看到第一个像对的就停；几个都像对时，选表述最完整、最没有漏洞的那个。",
    "· 多选题把所有正确项都选上（通常 2~4 个）；判断题注意「一定/必须/所有/只有/完全/均」这类绝对化说法和概念张冠李戴。",
    "· 涉及计算（掩码、进制、取值、比例、利率）一定真算一遍，不要凭印象。",
    "输出要求：",
    "1. 只回答给出的题目，不要复述题干，不要输出寒暄、免责声明或学习建议。",
    "2. 每道题严格按以下结构输出：",
    "【答案】……",
    "【把握】85% · 一句话理由（10 字内，说明凭什么有把握，或为什么没把握）",
    answerOnly ? "（本次不要输出【解析】行）" : "【解析】……",
    "3. 【答案】填写规则：单选题只写一个字母；多选题按字母顺序连写，如 ABC；判断题写「正确」或「错误」；填空题按空位顺序用 ①②③ 分隔，每空只写该空的内容（术语用教材标准写法，数字只写数值），不要连题干一起抄；简答题先给结论，再分 2~3 条要点，150 字以内。",
    "4. 多道题时按题号逐题输出，题号用「1. 2. 3.」开头。",
    "5. 需要计算或推理时在内部完成，只给结论，不输出推演过程。",
    "6. 信息不足无法确定时，仍给出最可能的答案，并在【答案】末尾标注（不确定）。",
    answerOnly ? "" : "7. 【解析】不超过 60 字，说明判断依据即可。",
    "8. 若题型与内容不符（例如标成单选却像多选），按题目实际要求作答。",
  ];
  return rules.filter(Boolean).join("\n");
}

function aiEndpoint(baseUrl) {
  const b = String(baseUrl || "").trim().replace(/\/+$/, "");
  // 已经写成完整端点就不再拼接
  if (/\/chat\/completions$/.test(b)) return b;
  return b + "/chat/completions";
}

// 统一发请求：顺带请求 usage（流式只有带上 stream_options 才会在最后一块返回用量）。
// 少数服务商不认这两个字段会回 400，这时自动去掉重发一次，不影响正常答题。
async function aiPostChat(c, payload, signal) {
  const send = (p) =>
    fetch(aiEndpoint(c.baseUrl), {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + c.key },
      body: JSON.stringify(p),
      signal,
    });
  const res = await send(payload);
  if (res.status !== 400) return res;
  const raw = await res.text().catch(() => "");
  // 有些兼容层不认识 stream_options / thinking，去掉这两个字段重发一次即可
  if (!/stream_options|include_usage|unknown|unrecognized|extra|thinking|max_tokens/i.test(raw)) {
    throw new Error(aiHttpError(400, raw));
  }
  const p2 = { ...payload };
  delete p2.stream_options;
  delete p2.thinking;
  delete p2.max_tokens;
  return send(p2);
}


function aiReadForm() {
  return {
    provider: $("ai-provider").value,
    baseUrl: $("ai-base").value.trim().replace(/\/+$/, ""),
    model: $("ai-model").value.trim(),
    key: $("ai-key").value.trim(),
    autoPaste: $("ai-auto-paste").checked,
    think: $("ai-think").checked,
  };
}

function aiHttpError(status, raw) {
  let detail = "";
  try { const j = JSON.parse(raw); detail = j.error?.message || j.message || ""; }
  catch { detail = String(raw || "").replace(/\s+/g, " ").slice(0, 140); }
  const head =
    status === 401 ? "API Key 无效或已过期" :
    status === 402 ? "账户余额不足" :
    status === 403 ? "没有该模型的调用权限" :
    status === 404 ? "接口地址或模型名不正确" :
    status === 429 ? "请求过于频繁，稍后再试" :
    status >= 500 ? "模型服务端出错" : `请求失败（HTTP ${status}）`;
  return head + (detail ? "：" + detail : "");
}

function aiErrText(e) {
  const m = String(e?.message ?? e);
  if (/Failed to fetch|NetworkError|Load failed|fetch failed/i.test(m)) {
    return "网络请求失败：可能接口地址有误、当前断网，或该服务不允许浏览器跨域调用。可换成 DeepSeek / Kimi（已确认支持跨域），或填写你自己的代理地址。";
  }
  return m;
}

// 结果渲染：轻量 markdown（加粗、行内代码、换行），不做完整解析
function aiRender(text) {
  let h = escapeHtml(text);
  h = h.replace(/【(答案|解析|把握)】/g, '<span class="ai-tag">【$1】</span>');
  h = h.replace(/\*\*([^*\n]+)\*\*/g, "<b>$1</b>");
  h = h.replace(/`([^`\n]+)`/g, "<code>$1</code>");
  return h.replace(/\n/g, "<br>");
}
// 深度思考阶段的占位：正文为空时显示，正文一开始流就切回正常渲染
function aiPaintThinking() {
  const el = $("ai-result");
  el.innerHTML = '<div class="ai-thinking"><span class="ai-dots"></span>深度思考中… 已思考 ' + AI.reason.length + " 字</div>";
  el.scrollTop = el.scrollHeight;
}

function aiPaintResult() {
  const el = $("ai-result");
  el.innerHTML = aiRender(AI.raw) + (AI.busy ? '<span class="ai-cur"></span>' : "");
  el.scrollTop = el.scrollHeight;
}

function aiPaintThumbs() {
  const wrap = $("ai-thumbs");
  wrap.innerHTML = "";
  wrap.classList.toggle("hidden", !AI.images.length);
  AI.images.forEach((src, i) => {
    const box = document.createElement("div");
    box.className = "ai-thumb";
    const img = document.createElement("img");
    img.src = src;
    const del = document.createElement("button");
    del.type = "button";
    del.textContent = "×";
    del.title = "移除这张图";
    del.onclick = () => { AI.images.splice(i, 1); aiPaintThumbs(); };
    box.append(img, del);
    wrap.appendChild(box);
  });
}

// 图片先压到最长边 1600、JPEG 0.85，避免 base64 体积过大拖慢上传
function aiAddImage(file) {
  if (AI.images.length >= 3) { toast("最多一次 3 张图"); return; }
  const fr = new FileReader();
  fr.onerror = () => toast("图片读取失败");
  fr.onload = () => {
    const img = new Image();
    img.onerror = () => toast("图片格式不支持");
    img.onload = () => {
      const max = 1600;
      const s = Math.min(max / img.naturalWidth, max / img.naturalHeight, 1);
      const w = Math.max(1, Math.round(img.naturalWidth * s));
      const h = Math.max(1, Math.round(img.naturalHeight * s));
      const cv = document.createElement("canvas");
      cv.width = w; cv.height = h;
      cv.getContext("2d").drawImage(img, 0, 0, w, h);
      AI.images.push(cv.toDataURL("image/jpeg", 0.85));
      aiPaintThumbs();
    };
    img.src = String(fr.result);
  };
  fr.readAsDataURL(file);
}

async function aiSolve() {
  if (AI.busy) return;
  if (!AI.cfg) aiLoadCfg();
  const text = $("ai-input").value.trim();
  if (!text && !AI.images.length) { toast("先粘贴题目或截图"); $("ai-input").focus(); return; }
  const c = AI.cfg;
  if (!c.key) { aiToggleCfg(true); toast("先填 API Key"); $("ai-key").focus(); return; }
  if (!c.baseUrl || !c.model) { aiToggleCfg(true); toast("接口地址或模型未填"); return; }

  AI.busy = true; AI.raw = ""; AI.reason = "";
  AI.ctrl = new AbortController();
  usageReset();
  $("btn-ai-solve").classList.add("hidden");
  $("btn-ai-stop").classList.remove("hidden");
  $("ai-result").innerHTML = '<span class="ai-cur"></span>';

  const kind = AI_KIND_LABEL[c.kind] || "";
  const userText = (kind ? `题型：${kind}\n\n` : "") + (text || "请识别图片中的题目并作答。");
  const content = AI.images.length
    ? [...AI.images.map((u) => ({ type: "image_url", image_url: { url: u } })), { type: "text", text: userText }]
    : userText;

  try {
    const payload = {
      model: c.model,
      messages: [{ role: "system", content: aiSystemPrompt() }, { role: "user", content }],
      stream: true,
      stream_options: { include_usage: true },
      temperature: 0.3,
    };
    // DeepSeek V4 默认开启思考模式：没勾「深度思考」就显式关掉，答题快很多。
    // 其他服务商不认识该字段，只在 DeepSeek 上发。
    // 直接读复选框（而不是配置值），勾完不点保存也能立刻生效。
    const wantThink = $("ai-think") ? $("ai-think").checked : !!c.think;
    if (aiIsDeepSeek(c.baseUrl) && !wantThink) payload.thinking = { type: "disabled" };

    const res = await aiPostChat(c, payload, AI.ctrl.signal);
    if (!res.ok) throw new Error(aiHttpError(res.status, await res.text().catch(() => "")));

    let used = null;
    if (!res.body) {
      const j = await res.json();
      AI.raw = j.choices?.[0]?.message?.content || "";
      used = aiUsageNorm(j);
      aiPaintResult();
    } else {
      const reader = res.body.getReader();
      const dec = new TextDecoder("utf-8");
      let buf = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split("\n");
        buf = lines.pop();
        for (const line of lines) {
          const t = line.trim();
          if (!t.startsWith("data:")) continue;
          const d = t.slice(5).trim();
          if (!d || d === "[DONE]") continue;
          let j;
          try { j = JSON.parse(d); } catch { continue; }
          if (j.usage) used = aiUsageNorm(j);   // include_usage 时最后一块带用量、choices 为空
          const d0 = j.choices?.[0]?.delta || {};
          // 深度思考时先流 reasoning_content，正文还没开始：给个进度提示，避免看起来像卡住
          if (d0.reasoning_content) {
            AI.reason += d0.reasoning_content;
            if (!AI.raw) aiPaintThinking();
          }
          const delta = d0.content || j.choices?.[0]?.message?.content || "";
          if (delta) { AI.raw += delta; aiPaintResult(); }
        }
      }
    }
    if (used) usageAdd(used, c.model);
    if (!AI.raw.trim()) throw new Error("模型没有返回内容：检查模型名是否支持 chat/completions，或换成该服务商的对话模型");
    aiPaintResult();
  } catch (e) {
    if (e.name === "AbortError") {
      toast("已停止生成");
      aiPaintResult();
    } else {
      const msg = aiErrText(e);
      $("ai-result").innerHTML = `<div class="ai-err">${escapeHtml(msg)}</div>`;
      console.warn("[AI]", e);
    }
  } finally {
    AI.busy = false; AI.ctrl = null;
    $("btn-ai-stop").classList.add("hidden");
    $("btn-ai-solve").classList.remove("hidden");
    if (AI.raw.trim()) aiPaintResult();   // 收尾重绘：去掉光标；中断时保留已生成部分
  }
}

// 只挑出【答案】行，避免把解析一起复制到答题框里
function aiAnswerText() {
  const lines = AI.raw.split(/\r?\n/).filter((l) => l.includes("【答案】"));
  if (!lines.length) return AI.raw.trim();
  const picked = lines.map((l) => l.replace(/^.*?【答案】/, "").trim()).filter(Boolean);
  return (picked.length > 1 ? picked.map((p, i) => `${i + 1}. ${p}`) : picked).join("\n");
}

async function aiTest() {
  const f = aiReadForm();
  if (!f.baseUrl || !f.model) { toast("先填接口地址和模型"); return; }
  if (!f.key) { toast("先填 API Key"); return; }
  const btn = $("btn-ai-test");
  btn.disabled = true; btn.textContent = "测试中…";
  try {
    // 连通性测试只发 1 个 token，思考模式会拖慢甚至占满额度，这里一律关掉
    const tp = { model: f.model, messages: [{ role: "user", content: "ping" }], max_tokens: 1, stream: false };
    if (aiIsDeepSeek(f.baseUrl)) tp.thinking = { type: "disabled" };
    const res = await fetch(aiEndpoint(f.baseUrl), {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + f.key },
      body: JSON.stringify(tp),
    });
    if (!res.ok) throw new Error(aiHttpError(res.status, await res.text().catch(() => "")));
    aiSaveCfg(f);
    toast("连接正常，可以开始答题");
  } catch (e) {
    toast("连接失败：" + aiErrText(e), 6000);
  } finally {
    btn.disabled = false; btn.textContent = "测试连接";
  }
}

// 读取剪贴板文本（未授权就静默跳过，不弹权限框）；manual=true 表示用户主动点击，失败要给提示
async function aiReadClip(manual = false) {
  const box = $("ai-input");
  if (box.value.trim() || AI.images.length) {
    if (manual) toast("输入框已有内容，先清空再读取");
    return false;
  }
  try {
    const t = await navigator.clipboard.readText();
    if (t && t.trim()) {
      box.value = t.trim().slice(0, 6000);
      toast("已从剪贴板填入题目");
      return true;
    }
    if (manual) toast("剪贴板里没有文本，可先复制题目或直接截图粘贴");
    return false;
  } catch {
    if (manual) toast("未获得剪贴板权限，请直接按 Ctrl+V 粘贴");
    return false;
  }
}

async function aiAutoPaste() {
  if (AI.cfg?.autoPaste === false) return;
  if ($("view-ai").classList.contains("hidden")) return;
  aiReadClip(false);
}

function aiEnter() {
  if (!AI.cfg) aiLoadCfg();
  aiPaintForm();
  aiPaintStatus();
  switchView("view-panel", "view-ai");
  if (!AI.cfg.key) aiToggleCfg(true);
  hwApplyMode(false);
  hwPing();
  $("hw-verify").checked = AI.cfg.verify !== false;
  usagePaint();
  usageBalance();
  setTimeout(aiAutoPaste, 80);
  setTimeout(() => { if (!$("ai-input").value) $("ai-input").focus(); }, 160);
}

// ---------- 作业自动写入（本地桥 → WebView2 调试端口） ----------
// 宿主 launcher.exe 只暴露 login.open / auth.setCookies / refresh，没有注入脚本的能力，
// 前端也拿不到跨窗口作业页的 DOM。所以改走本地小桥（app/resources/autofill/bridge.js）：
// 由 WebView2 自带的调试端口在作业页里执行抓题/填题脚本。
// 端口靠用户环境变量 WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS 打开，只需要装一次。
// 超星把「随堂练习」也存成 work（和作业同一条链路、同一个作答页），
// 区别只在标题和是否已交，所以抓题/填题/置信度全都复用。
const PRAC_RE = /随堂|课堂练习|课堂小测|随堂测验/;

const HW = {
  base: "http://127.0.0.1:8799",
  ok: false,
  cdp: false,
  busy: false,
  ctrl: null,
  items: [],
  questions: [],
  workId: "",
  // 上次停在哪个标签页，下次进来还是那个
  mode: (() => {
    try {
      return localStorage.getItem("cxball.hwtab") === "prac" ? "prac" : "hw";
    } catch {
      return "hw";
    }
  })(),
};

function hwSetStatus(html, kind) {
  const el = $("hw-status");
  if (!el) return;
  el.innerHTML = html;
  el.className = "hw-status" + (kind ? " hw-" + kind : "");
  // 出结果时把提示滚进视野，免得用户以为没反应
  if (kind) {
    try { el.scrollIntoView({ block: "nearest", behavior: "smooth" }); } catch { el.scrollIntoView(); }
  }
}

function workIdOf(link) {
  const m = String(link || "").match(/[?&]work(?:id|Id)=([^&#]+)/i);
  return m ? decodeURIComponent(m[1]) : "";
}

async function hwPing() {
  const pill = $("hw-pill");
  try {
    const r = await fetch(HW.base + "/ping", { cache: "no-store" });
    const j = await r.json();
    HW.ok = true;
    HW.cdp = !!j.cdp;
    HW.pages = j.pages || [];
    pill.textContent = j.cdp ? "已就绪" : "需要重开";
    pill.classList.toggle("off", !j.cdp);
    pill.title = j.cdp
      ? "自动写入可用"
      : "还差一步：关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次，它就会自己打开这个开关。";
  } catch {
    HW.ok = false;
    HW.cdp = false;
    HW.pages = [];
    pill.textContent = "未启用";
    pill.classList.add("off");
    pill.title = "自动写入的小助手没启动：关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次。";
  }
  return HW.ok && HW.cdp;
}

async function hwCall(action, payload) {
  let r;
  try {
    r = await fetch(HW.base + "/act", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, payload, workId: HW.workId }),
    });
  } catch {
    const e = new Error("自动写入的小助手没响应。请关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次。");
    e.code = "BRIDGE_DOWN";
    throw e;
  }
  const j = await r.json();
  if (!j.ok) {
    const e = new Error(j.error || "操作失败");
    e.code = j.code;
    throw e;
  }
  return j;
}

function hwFillSelect() {
  const sel = $("hw-select");
  if (!sel) return;
  const prac = HW.mode === "prac";
  const all = (S.snapshot?.items || []).filter((it) => it.link && it.type === "assignment");
  const seen = new Set();
  const uniq = all.filter((it) => (seen.has(it.link) ? false : (seen.add(it.link), true)));
  let list;
  if (prac) {
    // 随堂练习：标题里带「随堂/课堂练习」的才算。已交的也列出来（能看题、能让 AI 重答对照），
    // 但排序把没做的放前面。
    list = uniq
      .filter((it) => PRAC_RE.test(it.title || ""))
      .sort((a, b) => (isUnfinished(b) ? 1 : 0) - (isUnfinished(a) ? 1 : 0) || (b.deadline || 0) - (a.deadline || 0));
  } else {
    // 作业页不重复列随堂练习：它们归在「随堂练习」那个标签里
    list = uniq
      .filter((it) => isUnfinished(it) && !PRAC_RE.test(it.title || ""))
      .sort((a, b) => (a.deadline || 0) - (b.deadline || 0));
  }
  HW.items = list;
  if (!list.length) {
    sel.innerHTML = `<option value="">${
      prac ? "（没找到随堂练习，先刷新数据）" : "（没有未完成的作业，先刷新）"
    }</option>`;
    return;
  }
  sel.innerHTML = list
    .map((it, i) => {
      const d = it.deadline ? new Date(it.deadline) : null;
      const when = d ? ` · ${d.getMonth() + 1}/${d.getDate()} 截止` : "";
      // 已交的统一写「已交」，比「待批阅」短，下拉里不至于被截断
      const st = prac && !isUnfinished(it) ? ` · 已交` : "";
      return `<option value="${i}">${escapeHtml(courseNameOf(it) || "未命名课程")} · ${escapeHtml(
        it.title || "作业"
      )}${escapeHtml(st)}${when}</option>`;
    })
    .join("");
}

// 切标签：标题、说明、主按钮文案都跟着变
function hwApplyMode(reset) {
  const prac = HW.mode === "prac";
  if ($("hw-card-name")) $("hw-card-name").textContent = prac ? "随堂练习" : "作业自动写入";
  if ($("hw-row-label")) $("hw-row-label").textContent = prac ? "练习" : "作业";
  document.querySelectorAll("#hw-seg .seg-btn").forEach((b) => {
    b.classList.toggle("on", b.dataset.mode === HW.mode);
  });
  if (reset) {
    hwPaintList([]);
    hwPaintConf([]);
    const el = $("hw-status");
    if (el) {
      el.className = "hw-status";
      el.innerHTML = prac
        ? "随堂练习与作业是同一套页面：AI 会打开、抓题、作答并写进去。<b>已交的只显示答案、不改动页面</b>，写完你自己点提交。"
        : "AI 会打开作业页、抓题目、作答并把答案写进输入框，<b>不会自动提交</b>，你检查后再点提交。";
    }
  }
  hwFillSelect();
  hwUpdateRunBtn();
}

// 已交的练习不改页面，按钮文案要说清楚
function hwUpdateRunBtn() {
  const btn = $("btn-hw-run");
  if (!btn) return;
  const it = HW.items[Number($("hw-select")?.value)];
  const ro = HW.mode === "prac" && it && !isUnfinished(it);
  btn.textContent = ro ? "AI 作答（不写入）" : "AI 作答并写入";
  btn.classList.toggle("btn-primary", !ro);
  btn.classList.toggle("btn-ghost", !!ro);
}

function hwPick() {
  const v = $("hw-select").value;
  const empty = HW.mode === "prac" ? "先选一份随堂练习" : "先选一份未完成的作业";
  if (v === "" || v == null) {
    toast(empty);
    return null;
  }
  const it = HW.items[Number(v)];
  if (!it) {
    toast(empty);
    return null;
  }
  HW.workId = workIdOf(it.link);
  return it;
}

// 打开作业页：和「去做作业」同一条路，靠宿主放行的新窗口，共用登录态
function hwOpen(it) {
  const url = it?.link;
  if (!url) return;
  let w = null;
  try { w = window.open(url, "_blank"); } catch { w = null; }
  if (!w) {
    const a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener noreferrer";
    document.body.appendChild(a); a.click(); a.remove();
  }
}

// 等作业页把题目渲染出来（页面刚打开时题目还在异步加载）
async function hwWaitPage(timeout = 35000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    if (HW.ctrl?.signal.aborted) throw new DOMException("取消", "AbortError");
    try {
      const j = await hwCall("info");
      const d = j.data || {};
      if (d.count > 0) return d;
      hwSetStatus("题目页已打开，正在等题目加载…");
    } catch (e) {
      if (e.code === "CDP_DOWN") throw e;
      if (e.code === "NO_MATCH") throw e;
      hwSetStatus("正在等题目页窗口出现…");
    }
    await new Promise((r) => setTimeout(r, 1200));
  }
  // 超时了，查清楚是「没开页面」还是「开了但认不出题」，别只丢一句含糊的错
  await hwPing();
  const pages = HW.pages || [];
  if (!pages.length) {
    throw new Error(
      "没检测到学习通窗口。作业页必须开在悬浮球弹出的窗口里 —— 用你自己的 Edge / Chrome 打开的话，AI 是看不到页面的。点「先看题目」重新进一次"
    );
  }
  throw new Error(
    `学习通窗口已打开（${String(pages[0].url || "").slice(0, 50)}），但 35 秒内没读到题目。可能还停在登录页/课程首页，或者题目在 iframe 里 —— 点「诊断页面」看具体情况`
  );
}

function hwParseJson(s) {
  let t = String(s || "").trim();
  t = t.replace(/^```(?:json)?\s*/i, "").replace(/```\s*$/, "").trim();
  const a = t.indexOf("{"), b = t.lastIndexOf("}");
  if (a >= 0 && b > a) t = t.slice(a, b + 1);
  try { return JSON.parse(t); } catch { return null; }
}

// 提示词：题目本身的表述 + 一套「防低级错」的作答纪律。
// 之前只写「逐题作答」，模型容易只看第一个像对的选项、漏看反向问法，
// 所以这里把「反向问法 / 读完所有选项 / 多选选全 / 判断题绝对化 / 填空按空数」都点明。
function hwPrompt(part, opts) {
  const o = opts || {};
  const fresh = !!o.fresh;
  const ctx = String(o.ctx || "").trim();
  const lines = part.map((q) => {
    const optsTxt = q.options.length ? "\n选项：\n" + q.options.map((x) => `${x.label}. ${x.text}`).join("\n") : "";
    const blanks = q.type === "blank" ? `（共 ${q.fields || 1} 个空）` : "";
    return `第${q.n}题 [${q.type}]${blanks}\n题干：${q.stem}${optsTxt}`;
  });
  return (
    (ctx ? `作业信息：${ctx}\n` : "") +
    (fresh
      ? `下面 ${part.length} 道题，请独立地从头做一遍（不要参考任何先前的结论）。只输出 JSON，不要解释，不要代码块。\n`
      : `下面 ${part.length} 道题，逐题作答。只输出 JSON，不要解释，不要代码块。\n`) +
    `作答纪律（在心里执行，不要写出来）：\n` +
    `1. 先确认题目问的是什么：特别注意「不属于」「错误的是」「不包括」「除了」「至少」「最多」这类反向或边界问法，别按习惯选。\n` +
    `2. 每个选项都要读一遍再定，不要看到第一个像对的就停；几个选项都像对时，比较哪个表述最完整、最没有漏洞。\n` +
    `3. 单选题只有一个答案；多选题把所有正确项都选上（正确项通常是 2~4 个），明显正确的不要漏。\n` +
    `4. 判断题先看有没有「一定/必须/所有/只有/完全/均」这类绝对化说法，以及概念是否张冠李戴。\n` +
    `5. 填空题按空位顺序给，每空只写这一空的内容：术语用教材标准写法，数字只写数值，不要整句抄题干。\n` +
    `6. 需要计算的题（子网/掩码/进制/取值/比例）一定要真算一遍，别凭印象。\n` +
    `7. 题干或选项明显缺失、被截断时，按最通行的教材结论作答，并在 why 里写「题干不全」。\n` +
    `\n输出格式：{"answers":[{"n":1,"pick":"A","conf":95,"why":"理由≤14字"},{"n":4,"blanks":["第一空","第二空"],"conf":88},{"n":5,"text":"简答内容","conf":70}]}\n` +
    `- single 单选：pick 一个字母；multi 多选：pick 字母连写（如 ABD）；judge 判断：pick 填「正确」或「错误」；\n` +
    `- blank 填空：blanks 数组，元素个数必须等于该题的空数，按顺序；short 简答：text 填正文：先给结论，再分 2~3 条要点，150 字以内，不写「答：」。\n` +
    `- conf：0-100 的真实把握。能直接确定的 90+；需要推理或题干有歧义的 70-85；靠猜或信息不足的 70 以下。不要一律给高分。\n` +
    `- why：可省略，≤14 字，写依据（例如「私有地址范围」「公式算得 62 个」）。\n\n` +
    lines.join("\n\n")
  );
}

// 「准确率优先」开关：默认开。开着时每道客观题都会独立做第二遍，不一致再裁决。
function hwAccOn() {
  const box = $("hw-verify");
  return box ? !!box.checked : true;
}

// 裁决用更强的模型：DeepSeek 上从 flash 升到 pro。别家没有已知的强档就不换。
function aiStrongerModel(c) {
  const m = String(c?.model || "");
  if (aiIsDeepSeek(c?.baseUrl) && m === "deepseek-flash") return "deepseek-v4-pro";
  return m;
}

async function hwAskBatch(c, part, opts) {
  const o = opts || {};
  const fresh = !!o.fresh;
  const model = o.model || c.model;
  const think = o.think !== undefined ? !!o.think : !!$("ai-think")?.checked;
  const payload = {
    model,
    messages: [
      { role: "system", content: "你是严谨的学科答题助手：先在心里推理，再只输出 JSON。" },
      { role: "user", content: hwPrompt(part, { fresh, ctx: o.ctx }) },
    ],
    // 首答走低温求稳；复核换成高温，避免两次落在同一个坑里
    temperature: o.temp != null ? o.temp : fresh ? 0.85 : 0.1,
    stream: false,
  };
  // 思考模式会占用输出额度，给足上限，避免 JSON 在末尾被截断（截断就整批作废）
  if (aiIsDeepSeek(c.baseUrl)) payload.max_tokens = 8192;
  // 思考模式对计算/推理题提升明显；准确率优先时强制开，省 token 的档位才关
  if (aiIsDeepSeek(c.baseUrl) && !think) payload.thinking = { type: "disabled" };
  const res = await aiPostChat(c, payload, HW.ctrl?.signal);
  if (!res.ok) throw new Error(aiHttpError(res.status, await res.text().catch(() => "")));
  const j = await res.json();
  usageAdd(aiUsageNorm(j), model);   // 每批都记账，跑长作业时能看到花费在涨
  const body = j.choices?.[0]?.message?.content || "";
  const obj = hwParseJson(body);
  if (!obj || !Array.isArray(obj.answers)) {
    throw new Error("模型返回的不是预期 JSON，可以点「先看题目」后用下面的题目框逐题求解");
  }
  return obj.answers.map((a) => {
    if (!a || typeof a !== "object") return a;
    const raw = a.conf ?? a.confidence ?? a.把握 ?? null;
    const n = parseInt(raw, 10);
    a.conf = Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : null;
    if (a.why) a.why = String(a.why).slice(0, 24);
    return a;
  });
}

// 把模型返回的答案对回题目：模型时常用错题号、漏题、或干脆不给 n，
// 直接按下标硬对会让整卷错位（一题错，后面全错），所以按 n 优先、位置兜底。
function hwAlignBatch(part, got) {
  const list = (got || []).filter((a) => a && typeof a === "object");
  list.forEach((a, i) => {
    const n = parseInt(a.n, 10);
    if (!(n >= 1) && part[i]) a.n = part[i].n;
    else a.n = n;
  });
  const byN = new Map();
  list.forEach((a) => { if (!byN.has(String(a.n))) byN.set(String(a.n), a); });
  // 只认题号对得上的：按位置硬塞会把「补答某一题」的结果错贴到别的题上
  return part.map((q) => byN.get(String(q.n)) || null);
}

// 填空/简答按页面上的空数对齐，多截少补，免得写进去错位
function hwFitBlanks(qs, answers) {
  const byN = new Map(qs.map((q) => [String(q.n), q]));
  answers.forEach((a) => {
    const q = byN.get(String(a.n));
    if (!q || !a) return;
    if (q.type !== "blank") return;
    const want = Math.max(1, Number(q.fields) || 1);
    let vals = Array.isArray(a.blanks) ? a.blanks.map((x) => String(x == null ? "" : x).trim()) : [];
    if (!vals.length && (a.text || a.pick)) vals = String(a.text || a.pick).split(/[；;\n]+/).map((s) => s.trim());
    while (vals.length < want) vals.push("");
    a.blanks = vals.slice(0, want);
  });
  return answers;
}

async function hwAsk(questions, ctx) {
  const c = AI.cfg || aiLoadCfg();
  if (!c.key) throw new Error("先在「模型设置」里填 API Key");
  if (!c.baseUrl || !c.model) throw new Error("接口地址或模型未填");
  const acc = hwAccOn();
  // 准确率优先时开思考模式，每批少放几题，让每题都有足够推演；速度档才 6 题一批
  const BATCH = acc ? 4 : 6;
  const think = acc || !!$("ai-think")?.checked;
  const out = [];
  for (let i = 0; i < questions.length; i += BATCH) {
    const part = questions.slice(i, i + BATCH);
    hwSetStatus(
      `AI 作答中… 第 ${i + 1}-${Math.min(i + BATCH, questions.length)} 题 / 共 ${questions.length} 题` +
        (acc ? "<br><span style=\"color:#86909C\">准确率优先：这一步会思考，比平时慢一些</span>" : "")
    );
    const got = await hwAskBatch(c, part, { ctx, think, temp: 0.1 });
    hwAlignBatch(part, got).forEach((a, k) => {
      if (a) out.push(a);
      else out.push({ n: part[k].n, conf: null });
    });
  }
  // 漏答的题单独补一次：空着交上去就是丢分
  const miss = questions.filter((q) => {
    const a = out.find((x) => String(x.n) === String(q.n));
    return !hwHasAnswer(a);
  });
  if (miss.length) {
    hwSetStatus(`有 ${miss.length} 题没给出答案，正在单独补答…`);
    try {
      const got = await hwAskBatch(c, miss, { ctx, think, temp: 0.2 });
      hwAlignBatch(miss, got).forEach((a, k) => {
        if (!hwHasAnswer(a)) return;
        const i = out.findIndex((x) => String(x.n) === String(miss[k].n));
        if (i >= 0) out[i] = a;
      });
    } catch { /* 补答失败不影响已经拿到的答案 */ }
  }
  return hwFitBlanks(questions, out);
}

// 答案归一：选择题比字母集合，判断题统一成 T/F，填空题比去标点后的文字，简答不参与比对。
// 注意判断题返回的是「正确/错误」而不是字母，老写法按 [A-H] 过滤会变成空串，
// 结果判断题既不参与复核、还会被当成「没答」重复提问。
function hwNormAnswer(a) {
  if (!a) return "";
  if (a.pick) {
    const s = String(a.pick).trim();
    if (!/[A-Ha-h]/.test(s) || /正确|错误/.test(s)) {
      if (/正确|对|是|√|true|错误|错|否|×|false/i.test(s)) {
        const yes = /正确|对|是|√|true/i.test(s) && !/不正确|错误|错|否|×|false/i.test(s);
        return yes ? "T" : "F";
      }
    }
    return s.toUpperCase().replace(/[^A-H]/g, "").split("").sort().join("");
  }
  if (Array.isArray(a.blanks) && a.blanks.length) {
    return a.blanks.map((x) => String(x).replace(/[\s，。、,.;；:：!？]/g, "")).join("|");
  }
  return "";
}

// 有没有真的给出内容（简答的 text 也算），用于判断「这题是不是漏答了」
function hwHasAnswer(a) {
  if (!a || typeof a !== "object") return false;
  if (Array.isArray(a.blanks) && a.blanks.some((x) => String(x == null ? "" : x).trim())) return true;
  return !!(String(a.pick || "").trim() || String(a.text || "").trim());
}

// 展示用：把归一化后的 T/F 换回中文
function hwShowAnswer(v) {
  const s = String(v || "");
  return s === "T" ? "正确" : s === "F" ? "错误" : s;
}

// 准确率优先：所有客观题都独立再做一遍（换个温度、明确说「别参考上次」）。
// 两遍一致 → 基本可以放心；不一致 → 拿两种答案连同题干交给更强的模型裁决。
// 旧逻辑是「只复核 AI 自评 <70 的题」，但模型自评普遍虚高（常常全给 95），
// 等于什么题都不复核 —— 这就是正确率上不去的主因之一。
async function hwConsensus(questions, answers, ctx) {
  const c = AI.cfg || aiLoadCfg();
  const obj = questions.filter((q) => q.type !== "short" && q.type !== "unknown");
  if (!obj.length) return { checked: 0, same: 0, diff: [], arb: 0 };
  const BATCH = 4;
  const second = [];
  for (let i = 0; i < obj.length; i += BATCH) {
    const part = obj.slice(i, i + BATCH);
    if (HW.ctrl?.signal.aborted) throw new DOMException("取消", "AbortError");
    hwSetStatus(
      `准确率优先：第 ${i + 1}-${Math.min(i + BATCH, obj.length)} 题独立再做一遍…（共 ${obj.length} 题）`
    );
    const got = await hwAskBatch(c, part, { fresh: true, ctx, think: true, temp: 0.85 });
    hwAlignBatch(part, got).forEach((a, k) => {
      if (!a) return;
      a.n = part[k].n;
      second.push(a);
    });
  }
  const s2 = new Map(second.map((a) => [String(a.n), a]));
  let same = 0;
  const diff = [];
  const pending = [];
  obj.forEach((q) => {
    const a = answers.find((x) => String(x.n) === String(q.n));
    const b = s2.get(String(q.n));
    if (!a || !b) return;
    const x = hwNormAnswer(a), y = hwNormAnswer(b);
    if (!x || !y) return;
    if (x === y) {
      same++;
      a.conf = Math.max(a.conf || 0, 96);
      a.verify = "same";
      if (!a.why && b.why) a.why = b.why;
    } else {
      a.conf = Math.min(a.conf == null ? 60 : a.conf, 55);
      a.verify = "diff";
      a.alt = hwShowAnswer(y);   // 另一种答案，面板里会显示，方便人工扫一眼
      a.altWhy = String(b.why || "").slice(0, 24);
      diff.push(q.n);
      pending.push({ q, a, b });
    }
  });
  let arb = 0;
  if (pending.length) {
    try { arb = await hwArbitrate(c, pending, ctx); } catch { /* 裁决失败就保留原答案并标黄 */ }
  }
  return { checked: obj.length, same, diff, arb };
}

// 分歧裁决：只对不一致的题发一次请求，用更强的模型（DeepSeek 上 flash → pro）
async function hwArbitrate(c, pending, ctx) {
  const model = aiStrongerModel(c);
  const body = pending.map(({ q, a, b }) => {
    const optsTxt = q.options.length ? "\n选项：\n" + q.options.map((x) => `${x.label}. ${x.text}`).join("\n") : "";
    const one = (x) => (Array.isArray(x.blanks) && x.blanks.length ? x.blanks.join(" / ") : x.text || x.pick || "");
    return (
      `第${q.n}题 [${q.type}]\n题干：${q.stem}${optsTxt}\n` +
      `甲：${one(a)}${a.why ? `（依据：${a.why}）` : ""}\n` +
      `乙：${one(b)}${b.why ? `（依据：${b.why}）` : ""}`
    );
  });
  const prompt =
    (ctx ? `作业信息：${ctx}\n` : "") +
    `下面 ${pending.length} 道题，两份独立作答给出了不同答案（也可能两份都错）。请自己重新判断，给出你认为正确的那个。\n` +
    `只输出 JSON：{"answers":[{"n":1,"pick":"A","conf":90,"why":"≤14字"}]}\n` +
    `题型规则同前：single 一个字母、multi 字母连写、judge「正确/错误」、blank 用 blanks 数组（按空位顺序）。\n\n` +
    body.join("\n\n");
  hwSetStatus(`第 ${pending.map((x) => x.q.n).join("、")} 题两次结果不一致，正在用更强的模型裁决…`);
  const payload = {
    model,
    messages: [
      { role: "system", content: "你是学科老师，负责核对答案，只输出 JSON。" },
      { role: "user", content: prompt },
    ],
    temperature: 0.2,
    stream: false,
  };
  if (aiIsDeepSeek(c.baseUrl)) payload.max_tokens = 8192;
  const res = await aiPostChat(c, payload, HW.ctrl?.signal);
  if (!res.ok) throw new Error(aiHttpError(res.status, await res.text().catch(() => "")));
  const j = await res.json();
  usageAdd(aiUsageNorm(j), model);
  const obj = hwParseJson(j.choices?.[0]?.message?.content || "");
  if (!obj || !Array.isArray(obj.answers)) return 0;
  let n = 0;
  pending.forEach(({ q, a, b }) => {
    const pick = obj.answers.find((x) => String(x.n) === String(q.n));
    if (!pick) return;
    const y = hwNormAnswer(pick);
    if (!y) return;
    const yA = hwNormAnswer(a), yB = hwNormAnswer(b);
    const agreed = y === yA || y === yB;
    if (Array.isArray(pick.blanks) && pick.blanks.length) {
      a.blanks = pick.blanks;
      delete a.pick;
    } else if (pick.pick || pick.text) {
      delete a.blanks;
      if (pick.pick) a.pick = pick.pick;
      if (pick.text) a.text = pick.text;
    }
    a.conf = agreed ? 90 : 80;
    a.verify = agreed ? "arb" : "arb3";   // arb3 = 三份答案两两不同，最该人工看
    a.why = String(pick.why || "").slice(0, 24);
    // 提示里显示「另一种答案」：给和最终答案不一样的那一份
    a.alt = hwShowAnswer(y === yA ? yB : yA);
    n++;
  });
  return n;
}

// 置信度面板：平均分 + 高/中/低分布 + 需要人工看的题
function hwPaintConf(answers, review) {
  const box = $("hw-conf");
  if (!box) return;
  const list = (answers || []).filter((a) => a && a.conf != null);
  if (!list.length) {
    box.classList.add("hidden");
    box.innerHTML = "";
    return;
  }
  const avg = Math.round(list.reduce((s, a) => s + a.conf, 0) / list.length);
  const hi = list.filter((a) => a.conf >= 85).length;
  const mid = list.filter((a) => a.conf >= 60 && a.conf < 85).length;
  const lo = list.filter((a) => a.conf < 60).length;
  const total = list.length || 1;
  const cls = avg >= 85 ? "c-hi" : avg >= 65 ? "c-mid" : "c-lo";
  const lowNs = list.filter((a) => a.conf < 60).map((a) => a.n);

  let note = "";
  if (review && review.failed) {
    note = "复核请求没成功，下面只是首答结果，提交前建议自己扫一遍。";
  } else if (review && review.checked) {
    if (review.diff && review.diff.length) {
      note =
        `第 ${review.diff.join("、")} 题两遍答案不一样，` +
        (review.arb ? "已经用更强的模型重新判过，标 ⚠ 的仍建议你亲自看一眼。" : "建议提交前手动核对。");
    } else {
      note = `${review.checked} 道客观题各独立做了两遍，答案完全一致。`;
    }
  } else if (lo) {
    note = `第 ${lowNs.join("、")} 题把握较低，提交前建议手动核一遍。`;
  }

  box.classList.remove("hidden");
  box.innerHTML =
    `<div class="conf-row"><span>答案可靠度</span><b class="conf-avg ${cls}">${avg}%</b>` +
    `<span class="conf-legend">高 ${hi} · 中 ${mid} · 低 ${lo}</span></div>` +
    `<div class="conf-bar">` +
    `<i style="flex:${hi};background:#16a34a"></i>` +
    `<i style="flex:${mid};background:#f59e0b"></i>` +
    `<i style="flex:${lo};background:#dc2626"></i>` +
    `</div>` +
    (note ? `<div class="conf-note">${escapeHtml(note)}</div>` : "");
}

function hwPaintList(questions, answers) {
  const box = $("hw-list");
  if (!box) return;
  if (!questions?.length) {
    box.classList.add("hidden");
    box.innerHTML = "";
    return;
  }
  const confOf = new Map(
    (answers || []).filter((a) => a && a.conf != null).map((a) => [String(a.n), a])
  );
  box.classList.remove("hidden");
  box.innerHTML = questions
    .map((q) => {
      const a = confOf.get(String(q.n));
      const c = a ? a.conf : null;
      const unsure = !!a && (a.verify === "diff" || a.verify === "arb3");
      // 鼠标停上去能看到 AI 给的答案和依据，扫一眼就知道哪题不像话，不用翻页面
      const picked = a ? (Array.isArray(a.blanks) ? a.blanks.join(" / ") : a.text || a.pick || "") : "";
      const tip = a ? `${picked}${a.why ? " · " + a.why : ""}${a.alt ? "（另一答案：" + a.alt + "）" : ""}` : "";
      const tag =
        c == null
          ? ""
          : `<span class="conf-tag ${c >= 85 ? "c-hi" : c >= 60 ? "c-mid" : "c-lo"}">${c}%${unsure ? " ⚠" : ""}</span>`;
      return (
        `<div class="hw-q" title="${escapeHtml(tip)}"><span class="hw-qn">${q.n}</span>` +
        `<span class="hw-qt">${escapeHtml(AI_KIND_LABEL[q.type] || "题目")}</span>` +
        `<span class="hw-qs">${escapeHtml(q.stem.slice(0, 62))}</span>${tag}</div>`
      );
    })
    .join("");
}

async function hwGrab(it, open = true) {
  if (!(await hwPing())) {
    hwSetStatus(
      "自动写入暂时用不了，还差一小步。<br>" +
        "请先<b>关掉悬浮球窗口</b>，再从桌面的 <b>学习通悬浮球</b> 图标重新打开一次，" +
        "然后重新点一次「AI 作答并写入」。<br>" +
        "<span style=\"color:#86909C\">重开时程序会自己把需要的开关打开，不需要做别的设置。</span>",
      "err"
    );
    return null;
  }
  HW.ctrl = new AbortController();
  hwPaintConf([]);      // 新一轮抓题先清掉上一轮的置信度，避免看到旧数字
  if (open && it) {
    hwSetStatus("正在打开题目页…");
    hwOpen(it);
  }
  const info = await hwWaitPage();
  hwSetStatus(`页面识别到 ${info.count} 道题，正在抓题干…`);
  const ex = await hwCall("extract");
  HW.questions = ex.data.questions || [];
  hwPaintList(HW.questions);
  if (!HW.questions.length) hwSetStatus("没抓到题目：这个页面的结构可能不是作业页（比如进的是课程首页）。", "warn");
  return HW.questions;
}

async function hwRun() {
  if (HW.busy) return;
  const it = hwPick();
  if (!it) return;
  // 随堂练习里已经交过的：只让 AI 重答显示，不往页面里写
  const readonly = HW.mode === "prac" && !isUnfinished(it);
  HW.busy = true;
  HW.ctrl = new AbortController();
  usageReset();
  $("btn-hw-run").disabled = true;
  try {
    const qs = await hwGrab(it, true);
    if (!qs || !qs.length) return;
    // 把课程名 / 作业名一起给模型：同一道题在不同课程里答案可能不一样（教材版本不同）
    const ctx = [courseNameOf(it), it.title].filter(Boolean).join(" · ");
    hwSetStatus(`抓到 ${qs.length} 道题，开始让 AI 作答…`);
    const answers = await hwAsk(qs, ctx);
    // 模型给的题号不可全信：漏了或越界的按顺序补，否则整卷会错位
    const byN = new Map(qs.map((q) => [String(q.n), q]));
    answers.forEach((a, i) => {
      if (!a || typeof a !== "object") return;
      const n = parseInt(a.n, 10);
      if (!(n >= 1 && n <= qs.length)) {
        if (qs[i]) a.n = qs[i].n;
      } else {
        a.n = n;
      }
      // 顺带带上题干：抓题到回填之间页面常会重渲染，标记会失效，靠它重新认题
      const q = byN.get(String(a.n));
      if (q && q.stem) a.stem = q.stem.slice(0, 120);
      // 再带上第一个选项的文字：防止选项被错取成相邻题的，填前就能校验
      if (q && q.options && q.options[0] && q.options[0].text) a.opt0 = q.options[0].text.slice(0, 20);
    });

    // 准确率优先：客观题全部独立做第二遍，不一致的交给更强的模型裁决（可关）
    let review = null;
    if (hwAccOn()) {
      try {
        review = await hwConsensus(qs, answers, ctx);
      } catch (e) {
        if (e.name === "AbortError") throw e;
        review = { failed: true, checked: 0, same: 0, diff: [] };
      }
    }
    hwPaintList(qs, answers);
    hwPaintConf(answers, review);

    const withConf = answers.filter((a) => a && a.conf != null);
    const avg = withConf.length ? Math.round(withConf.reduce((s, a) => s + a.conf, 0) / withConf.length) : null;
    const tail = avg != null ? ` · 把握 ${avg}%` : "";
    const diffNote = review?.diff?.length ? `，第 ${review.diff.join("、")} 题两遍答案不同` : "";

    // 已交过的练习只给答案参考，绝不动页面上的内容
    if (readonly) {
      hwSetStatus(
        `这份已经交过了，<b>没有写入页面</b>。AI 的 ${answers.length} 个答案显示在下面${tail}${diffNote}，可以对照着看。`,
        "ok"
      );
      return;
    }

    hwSetStatus(`AI 给出 ${answers.length} 个答案，正在写进网页…`);
    const res = await hwCall("fill", { answers });
    const d = res.data || {};
    const fails = (d.items || []).filter((x) => !x.ok);
    if (fails.length) {
      let why = fails[0].why || "没找到输入框";
      if (d.scanned === 0) why = "页面上已经没有题目，可能跳到别的页面了";
      const hint = d.scanned === 0 ? "点「先看题目」重新进作业页，再点一次写入。" : "这几题请手动补，其余核对后提交。";
      hwSetStatus(
        `已写入 ${d.ok}/${d.total} 题（页面识别到 ${d.scanned ?? "?"} 道题）${tail}。没填上：第 ${fails
          .map((f) => f.n)
          .join("、")} 题（${why}）。${hint}`,
        "warn"
      );
    } else {
      hwSetStatus(`✅ ${d.ok} 道题全部写入${tail}${diffNote}。回到作业页核对一遍，再自己点提交。`, "ok");
    }
  } catch (e) {
    if (e.name === "AbortError") hwSetStatus("已取消。");
    else hwSetStatus("出错了：" + String(e.message || e), "err");
  } finally {
    HW.busy = false;
    HW.ctrl = null;
    $("btn-hw-run").disabled = false;
    usagePaint();
  }
}

document.querySelectorAll("#hw-seg .seg-btn").forEach((b) => {
  b.onclick = () => {
    HW.mode = b.dataset.mode === "prac" ? "prac" : "hw";
    try { localStorage.setItem("cxball.hwtab", HW.mode); } catch { /* 忽略 */ }
    hwApplyMode(true);
    hwPing();
  };
});
$("hw-select").onchange = () => hwUpdateRunBtn();

$("hw-title").onclick = () => {
  const body = $("hw-body");
  const open = body.classList.toggle("hidden");
  $("hw-arrow").textContent = open ? "▸" : "▾";
  if (!open) { hwPing(); hwFillSelect(); }
};
$("btn-hw-grab").onclick = async () => {
  const it = hwPick();
  if (!it) return;
  $("btn-hw-grab").disabled = true;
  try {
    const qs = await hwGrab(it, true);
    if (qs?.length) hwSetStatus(`识别到 ${qs.length} 道题，结构没问题的话可以点「AI 作答并写入」。`, "ok");
  } catch (e) {
    hwSetStatus("出错了：" + String(e.message || e), "err");
  } finally {
    $("btn-hw-grab").disabled = false;
  }
};
$("btn-hw-run").onclick = hwRun;
$("btn-hw-debug").onclick = async () => {
  $("btn-hw-debug").disabled = true;
  try {
    hwSetStatus("正在检查页面结构…");
    const r = await hwCall("debug");
    const d = r.data || {};
    const hits = (d.counts || []).filter((c) => c.hit > 0).map((c) => `${c.sel}×${c.hit}`).join("、") || "一个都没命中";
    const per = (d.perRoot || []).map((x) => `${x.doc}:${x.hit}题`).join("，");
    const first = (d.questions || [])[0];
    hwSetStatus(
      `页面：<b>${escapeHtml(String(d.url || "").slice(0, 90))}</b><br>` +
        `识别到 <b>${(d.questions || []).length}</b> 道题，输入控件 ${d.controls} 个，iframe ${d.frames} 个<br>` +
        `各文档：${escapeHtml(per || "-")}<br>` +
        `命中选择器：${escapeHtml(hits)}<br>` +
        (first
          ? `第 1 题：[${first.type}] 输入框 ${first.fields} / 选项 ${first.options}<br>「${escapeHtml(first.head)}」`
          : "没认出题目容器 —— 可能不在作业页，或这个页面是把题目放在跨域 iframe 里。"),
      (d.questions || []).length ? "ok" : "warn"
    );
  } catch (e) {
    hwSetStatus("诊断失败：" + String(e.message || e), "err");
  } finally {
    $("btn-hw-debug").disabled = false;
  }
};

// ---------- 悬浮球 / 面板大小 ----------
// 宿主 CxBall.Shell 只开放了少数几个 action，没有改窗口尺寸的接口，所以由本地小桥
// （win.js）从外部用 Win32 SetWindowPos 调面板窗和悬浮球窗；前端再把页面 zoom 设成
// 同一比例，视觉上就是整体等比放大（字和按钮一起变大），布局不会被拉变形。
const WIN = { base: "http://127.0.0.1:8799", scale: 1, ball: 64, busy: false, again: false };
const WIN_W = 400, WIN_H = 608;   // 基准窗口 400x640，WebView 视口 400x608

function winLoad() {
  try {
    const o = JSON.parse(localStorage.getItem("cxball.win.v1") || "{}");
    const s = Number(o.scale);
    if (s >= 0.85 && s <= 1.35) WIN.scale = Math.round(s * 100) / 100;
  } catch { /* 忽略 */ }
}

function winSave() {
  try { localStorage.setItem("cxball.win.v1", JSON.stringify({ scale: WIN.scale, ball: WIN.ball })); } catch { /* 忽略 */ }
}

function winPaint() {
  const s = Math.round(WIN.scale * 100);
  $("set-panel-scale").value = String(s);
  $("panel-scale-val").textContent = s + "%";
}

/// 页面比例只跟宿主窗口的实际宽度走：窗口宽 / 400 就是该用的 zoom。
/// 好处是不用去猜 DPI（本机 200% 缩放下 400 窗口的 CSS 视口只有 287），
/// 窗宽和 zoom 同时按同一比例变，布局宽度就恒定不变，只有物理像素变大。
function applyZoom(panelW) {
  const z = Math.max(0.5, Math.min(2, (Number(panelW) || WIN_W) / WIN_W));
  document.documentElement.style.zoom = String(Math.round(z * 1000) / 1000);
}

async function winApply(silent) {
  if (WIN.busy) { WIN.again = true; return; }
  WIN.busy = true;
  try {
    const r = await fetch(WIN.base + "/win/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scale: WIN.scale, ball: WIN.ball }),
    });
    const j = await r.json();
    if (!j.ok) {
      // 面板关着时宿主把窗口挪去了屏幕外，这时改不了尺寸。
      // 不能拿一个假的宽度去算 zoom（会把页面放大错），等面板下次打开再补。
      if (j.found === false && silent) return;
      throw new Error(j.error || "调整失败");
    }
    applyZoom(j.panelW);
  } catch (e) {
    if (!silent) {
      const msg = /fetch|NetworkError|Failed/i.test(String(e.message))
        ? "这次没生效：重开一次悬浮球后再调，就会记住"
        : String(e.message || "调整失败");
      toast(msg);
    }
  } finally {
    WIN.busy = false;
    if (WIN.again) { WIN.again = false; winApply(true); }
  }
}

winLoad();
$("set-panel-scale").oninput = () => { $("panel-scale-val").textContent = $("set-panel-scale").value + "%"; };
$("set-panel-scale").onchange = () => {
  WIN.scale = Number($("set-panel-scale").value) / 100;
  winSave(); winPaint(); winApply(false);
};

/// 对时：查窗口真实宽度，和「保存的比例」不一致就重设一次。
/// 面板每次被打开都会走这里 —— 宿主关面板时窗口被挪走改不了尺寸，
/// 打开后补上，用户看到的才是自己调过的大小。
async function winSync() {
  if (WIN.busy) return;
  try {
    const r = await fetch(WIN.base + "/win/state", { cache: "no-store" });
    const j = await r.json();
    if (!j || !j.found) return;
    const want = Math.round(WIN_W * WIN.scale);
    if (Math.abs(j.panelW - want) <= 2) { applyZoom(j.panelW); return; }
    await winApply(true);
  } catch { /* 小桥没起就算了，不影响主功能 */ }
}

// 面板打开/重新获得焦点时对一次尺寸（宿主显示面板会拿走焦点）
window.addEventListener("focus", () => { winSync(); });
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") winSync();
});

// ---------- 课程文档下载（本地桥 /docs/*） ----------
// 学习通「课程 → 资料」里的文件由小桥直连带 Cookie 请求，下载也由小桥流式落盘，
// 网页端只负责列目录、勾选、显示进度，所以几百 MB 的文件也不会卡住面板。
const DOCS = {
  base: "http://127.0.0.1:8799",
  ok: false,
  mode: "files",       // files=课程资料 / hw=作业附件
  courses: [],         // 全量课程（学习通返回的全部）
  shown: [],           // 过滤后真正出现在下拉里的课程
  cur: null,
  path: [],            // 面包屑（不含根）：[{id,name}]
  items: [],
  sel: new Map(),      // id -> {id,name,relPath}
  enc: "",
  taskId: "",
  timer: null,
  polling: false,
  dir: "",
};

// 作业附件（本地桥 /hw/*）：作业列表来自宿主快照，附件清单实时读作业页
const HWD = {
  list: [],            // 当前课程下的作业（去重后）
  cur: null,
  items: [],           // 当前作业的附件 [{id,href,name,size,kind}]
  sel: new Set(),      // 选中项下标
  pending: null,       // 从主面板右键进来时待定位的作业
};

// 课程筛选：与设置页「课程选择」共用同一个 deselectedCourses，
// 所以在设置里取消勾选的课，文档页下拉里也不会出现。
const DF = { draft: new Set(), all: [] };

function docsDeselected() {
  return new Set(((S.account?.state?.deselectedCourses) || []).map(String));
}

/// 下拉里要显示的课程：全量减掉已取消勾选的；若全被隐藏则兜底显示全部，免得下拉空着没法操作
function docsVisibleCourses() {
  const off = docsDeselected();
  const vis = DOCS.courses.filter((c) => !off.has(String(c.courseId)));
  return vis.length ? vis : DOCS.courses.slice();
}

/// 重建课程下拉。返回 0 表示有可选课程。
function docsPaintCourses() {
  const sel = $("docs-course");
  DOCS.shown = docsVisibleCourses();
  const seen = {};
  sel.innerHTML = DOCS.shown.length
    ? DOCS.shown
        .map((c, i) => {
          // 同名课程（不同班级）带上次序号，避免下拉里分不清
          seen[c.name] = (seen[c.name] || 0) + 1;
          const label = seen[c.name] > 1 ? `${c.name} (${seen[c.name]})` : c.name;
          return `<option value="${i}">${escapeHtml(label)}</option>`;
        })
        .join("")
    : '<option value="">（没有课程）</option>';
  const hidden = DOCS.courses.length - DOCS.shown.length;
  const btn = $("btn-docs-filter");
  if (btn) btn.title = hidden ? `已隐藏 ${hidden} 门课程，点这里调整` : "只保留想看的课程";
  return DOCS.shown.length ? 0 : -1;
}

function dfOpen() {
  if (!DOCS.courses.length) { toast("还没读到课程列表"); return; }
  DF.all = DOCS.courses.map((c) => ({ id: String(c.courseId), name: c.name || String(c.courseId) }));
  DF.draft = new Set(docsVisibleCourses().map((c) => String(c.courseId)));
  $("df-list").innerHTML = DF.all
    .map(
      (c) =>
        `<label class="df-item"><input type="checkbox" data-id="${escapeHtml(c.id)}" ${DF.draft.has(c.id) ? "checked" : ""}><span>${escapeHtml(c.name)}</span></label>`,
    )
    .join("");
  $("df-list").querySelectorAll("input").forEach((cb) => {
    cb.onchange = () => {
      if (cb.checked) DF.draft.add(cb.dataset.id);
      else DF.draft.delete(cb.dataset.id);
    };
  });
  $("docs-filter-overlay").classList.remove("hidden");
}

function dfClose() {
  $("docs-filter-overlay").classList.add("hidden");
}

/// 课程太多且从没筛过时，自动弹一次，省得翻几十门
function docsMaybeFilterTip() {
  if (DOCS.courses.length < 12) return;
  if (docsDeselected().size) return;
  try {
    if (localStorage.getItem("cxball.docs.tipped")) return;
    localStorage.setItem("cxball.docs.tipped", "1");
  } catch { /* 忽略 */ }
  setTimeout(dfOpen, 500);
}

async function dfCommit() {
  const raw = new Map(DOCS.courses.map((c) => [String(c.courseId), c.courseId]));
  const off = DF.all.filter((c) => !DF.draft.has(c.id)).map((c) => (raw.has(c.id) ? raw.get(c.id) : c.id));
  const st = (S.account.state ??= {});
  st.deselectedCourses = off;
  const keepId = DOCS.cur ? String(DOCS.cur.courseId) : "";
  dfClose();
  docsPaintCourses();
  let idx = DOCS.shown.findIndex((c) => String(c.courseId) === keepId);
  if (idx < 0) idx = 0;
  if (DOCS.shown.length) {
    $("docs-course").value = String(idx);
    docsOpenCourse(idx);
  } else {
    $("docs-list").innerHTML = '<div class="doc-empty">没有可看的课程</div>';
  }
  toast(off.length ? `已隐藏 ${off.length} 门课程` : "已显示全部课程");
  try {
    await bridge.call("courses.setDeselected", { courseIds: off });
  } catch { /* 静默：本地状态已生效 */ }
}


const DOC_ICON = (name, folder) => {
  if (folder) return "📁";
  const ext = (String(name).split(".").pop() || "").toLowerCase();
  if (["zip", "rar", "7z", "tar", "gz"].includes(ext)) return "🗜";
  if (ext === "pdf") return "📕";
  if (["doc", "docx", "wps"].includes(ext)) return "📘";
  if (["ppt", "pptx", "pps"].includes(ext)) return "📙";
  if (["xls", "xlsx", "csv"].includes(ext)) return "📗";
  if (["png", "jpg", "jpeg", "gif", "webp", "bmp"].includes(ext)) return "🖼";
  if (["mp4", "avi", "mkv", "mov", "flv"].includes(ext)) return "🎬";
  return "📄";
};

function fmtSize(n) {
  const v = Number(n) || 0;
  if (v < 1024) return v + " B";
  if (v < 1048576) return (v / 1024).toFixed(0) + " KB";
  if (v < 1073741824) return (v / 1048576).toFixed(1) + " MB";
  return (v / 1073741824).toFixed(2) + " GB";
}

async function docsApi(p, opt = {}) {
  let r;
  try {
    r = await fetch(DOCS.base + p, { cache: "no-store", ...opt });
  } catch {
    const e = new Error("资料小助手没响应。请关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次。");
    e.code = "BRIDGE_DOWN";
    throw e;
  }
  let j;
  try { j = await r.json(); } catch { throw new Error("读取失败，重开一次悬浮球再试"); }
  if (!j.ok) {
    const e = new Error(j.error || "请求失败");
    e.code = j.code;
    throw e;
  }
  return j;
}

function docsPaintPill(text, ok) {
  const pill = $("docs-pill");
  pill.textContent = text;
  pill.classList.toggle("off", !ok);
}

function docsCrumb() {
  const el = $("docs-crumb");
  let html = `<a data-crumb="-1">全部文件</a>`;
  DOCS.path.forEach((p, i) => {
    html += ` <span class="sep">/</span> <a data-crumb="${i}">${escapeHtml(p.name)}</a>`;
  });
  el.innerHTML = html;
  el.querySelectorAll("a").forEach((a) => {
    a.onclick = () => {
      const i = Number(a.dataset.crumb);
      DOCS.path = i < 0 ? [] : DOCS.path.slice(0, i + 1);
      docsLoadDir();
    };
  });
}

function docsPaintList() {
  const box = $("docs-list");
  if (!DOCS.items.length) {
    box.innerHTML = '<div class="doc-empty">这个目录里没有文件</div>';
    return;
  }
  box.innerHTML = DOCS.items
    .map((it, i) => {
      const on = DOCS.sel.has(it.id);
      const meta = it.folder
        ? it.online
          ? "在线课件（需在网页里看）"
          : "文件夹"
        : [it.size, it.owner, it.time].filter(Boolean).join(" · ");
      return (
        `<div class="doc-row${it.folder ? " folder" : ""}${on ? " on" : ""}" data-i="${i}">` +
        (it.folder
          ? `<span class="doc-ck" style="width:13px"></span>`
          : `<input class="doc-ck" type="checkbox" ${on ? "checked" : ""} tabindex="-1">`) +
        `<span class="doc-ico">${DOC_ICON(it.name, it.folder)}</span>` +
        `<div class="doc-main"><div class="doc-name">${escapeHtml(it.name)}</div>` +
        (meta ? `<div class="doc-meta">${escapeHtml(meta)}</div>` : "") +
        `</div></div>`
      );
    })
    .join("");
}

function docsPaintSel() {
  const n = DOCS.sel.size;
  const btn = $("btn-docs-dl");
  btn.textContent = n ? `下载选中 (${n})` : "下载选中 (0)";
  btn.disabled = !n || !!DOCS.taskId;
}

async function docsLoadDir() {
  if (!DOCS.cur) return;
  docsCrumb();
  $("docs-list").innerHTML = '<div class="doc-empty">加载中…</div>';
  const top = DOCS.path[DOCS.path.length - 1];
  const body = {
    courseId: DOCS.cur.courseId,
    clazzId: DOCS.cur.clazzId,
    cpi: DOCS.cur.cpi,
    enc: DOCS.enc,
  };
  if (top) {
    body.folderId = top.id;
    body.folderName = top.name;
    body.parentId = (DOCS.path[DOCS.path.length - 2] || {}).id || "";
  }
  try {
    const j = await docsApi("/docs/list", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    DOCS.items = j.items || [];
    if (j.enc) DOCS.enc = j.enc;
    docsPaintList();
  } catch (e) {
    $("docs-list").innerHTML = `<div class="doc-empty">${escapeHtml(e.message)}</div>`;
    if (e.code === "NO_LOGIN") docsPaintPill("登录失效", false);
  }
}

async function docsOpenCourse(idx) {
  const c = DOCS.shown[idx];
  if (!c) return;
  DOCS.cur = c;
  DOCS.path = [];
  DOCS.enc = "";
  DOCS.sel.clear();
  docsPaintSel();
  // 作业附件页只需要课程号去筛作业列表，不必去拉资料目录
  if (DOCS.mode === "hw") {
    await hwdCourseChanged();
    return;
  }
  await docsLoadDir();
}

async function docsLoadCourses() {
  const sel = $("docs-course");
  sel.innerHTML = '<option value="">加载中…</option>';
  $("docs-list").innerHTML = '<div class="doc-empty">正在读取课程…</div>';
  try {
    const j = await docsApi("/docs/courses");
    DOCS.courses = j.courses || [];
    if (!DOCS.dir) {
      DOCS.dir = j.dir || "";
      $("docs-dir").value = DOCS.dir;
    }
    docsPaintPill("已就绪", true);
    if (!DOCS.courses.length) {
      sel.innerHTML = '<option value="">（没有找到课程）</option>';
      $("docs-list").innerHTML = '<div class="doc-empty">没有找到课程，请确认已登录学习通</div>';
      return;
    }
    docsPaintCourses();
    // 默认回到上次看的课程（只在上次那门还显示着的时候）
    let keep = 0;
    try {
      const last = localStorage.getItem("cxball.docs.course");
      const hit = DOCS.shown.findIndex((c) => String(c.courseId) === last);
      if (hit >= 0) keep = hit;
    } catch { /* 忽略 */ }
    sel.value = String(keep);
    docsOpenCourse(keep);
    docsMaybeFilterTip();
  } catch (e) {
    docsPaintPill("未就绪", false);
    sel.innerHTML = '<option value="">（读取失败）</option>';
    $("docs-list").innerHTML = `<div class="doc-empty">${escapeHtml(e.message)}</div>`;
    if (e.code === "CDP_DOWN") {
      $("docs-hint").innerHTML = "读不到学习通页面：关掉悬浮球窗口，再从桌面「学习通悬浮球」图标重新打开一次，然后点「重试」。";
    }
  }
}

function docsToggle(it) {
  if (DOCS.taskId) { toast("正在下载，等这次结束再改选择"); return; }
  if (DOCS.sel.has(it.id)) DOCS.sel.delete(it.id);
  else {
    DOCS.sel.set(it.id, {
      id: it.id,
      name: it.name,
      relPath: DOCS.path.map((p) => p.name),
    });
  }
  docsPaintList();
  docsPaintSel();
}

function docsSelectAll() {
  if (DOCS.taskId) return;
  const files = DOCS.items.filter((i) => !i.folder);
  if (!files.length) { toast("当前目录没有可下载的文件"); return; }
  const allOn = files.every((f) => DOCS.sel.has(f.id));
  for (const f of files) {
    if (allOn) DOCS.sel.delete(f.id);
    else DOCS.sel.set(f.id, { id: f.id, name: f.name, relPath: DOCS.path.map((p) => p.name) });
  }
  docsPaintList();
  docsPaintSel();
}

function docsProgressPaint(j) {
  const wrap = $("docs-progress");
  wrap.classList.remove("hidden");
  const pct = j.total ? Math.round((j.done / j.total) * 100) : 0;
  // 当前文件大小未知时，用「已完成个数」推进度条，避免看起来卡死
  const curPct = j.fileTotal ? Math.min(99, (j.fileBytes / j.fileTotal) * (100 / j.total)) : 0;
  $("docs-bar-in").style.width = Math.min(100, pct + curPct) + "%";
  if (j.state === "running") {
    const cur = j.current
      ? `正在下载：${escapeHtml(j.current)}` + (j.fileTotal ? ` · ${fmtSize(j.fileBytes)} / ${fmtSize(j.fileTotal)}` : "")
      : "准备中…";
    $("docs-pinfo").innerHTML = `${j.done} / ${j.total} 个已完成${j.failed ? ` · ${j.failed} 个失败` : ""}<br>${cur}`;
  }
}

async function docsDownload() {
  // 作业附件走另一套接口（云盘直链），其余流程完全一样
  if (DOCS.mode === "hw") return hwdDownload();
  const files = [...DOCS.sel.values()];
  if (!files.length) { toast("先选中要下载的文件"); return; }
  if (!DOCS.cur) { toast("课程还没加载好，稍等一下再试"); return; }
  const dir = $("docs-dir").value.trim();
  if (!dir) { toast("请先选择保存文件夹"); return; }
  DOCS.dir = dir;
  try { localStorage.setItem("cxball.docs.dir", dir); } catch { /* 忽略 */ }
  if (DOCS.cur) {
    try { localStorage.setItem("cxball.docs.course", DOCS.cur.courseId); } catch { /* 忽略 */ }
  }
  $("btn-docs-dl").disabled = true;
  try {
    const j = await docsApi("/docs/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        courseId: DOCS.cur.courseId,
        clazzId: DOCS.cur.clazzId,
        cpi: DOCS.cur.cpi,
        courseName: DOCS.cur.name,
        dir,
        flat: !$("docs-subdir").checked,
        files,
      }),
    });
    DOCS.taskId = j.taskId;
    $("btn-docs-stop").classList.remove("hidden");
    $("btn-docs-stop").disabled = false;
    docsProgressPaint({ state: "running", total: files.length, done: 0, failed: 0, current: "", fileBytes: 0, fileTotal: 0 });
    docsPoll();
  } catch (e) {
    $("btn-docs-dl").disabled = false;
    toast(e.message || "下载失败");
  }
}

function docsPoll() {
  clearTimeout(DOCS.timer);
  const tick = async () => {
    try {
      const j = await docsApi("/docs/progress?id=" + encodeURIComponent(DOCS.taskId));
      docsProgressPaint(j);
      if (j.state === "running") {
        DOCS.timer = setTimeout(tick, 700);
        return;
      }
      docsFinish(j);
    } catch (e) {
      // 任务过期（小桥重启过）：别无限重试，直接收尾
      if (/不存在|过期/.test(String(e.message || ""))) {
        docsFinish({ state: "done", done: 0, failed: 0, files: [], dir: "" });
        return;
      }
      // 小桥临时取不到进度：继续等，别把下载判死
      DOCS.timer = setTimeout(tick, 1500);
    }
  };
  tick();
}

function docsFinish(j) {
  DOCS.taskId = "";
  clearTimeout(DOCS.timer);
  $("btn-docs-stop").classList.add("hidden");
  $("docs-bar-in").style.width = "100%";
  const ok = j.done || 0;
  const bad = j.failed || 0;
  const errs = (j.files || []).filter((f) => f.state === "error").slice(0, 3);
  $("docs-pinfo").innerHTML =
    `<b>${ok ? "已完成" : "已结束"}</b>：成功 ${ok} 个${bad ? `，失败 ${bad} 个` : ""}` +
    (errs.length ? `<br>` + errs.map((f) => `· ${escapeHtml(f.name)}：${escapeHtml(f.error)}`).join("<br>") : "") +
    (j.dir ? `<br>保存位置：${escapeHtml(j.dir)}` : "");
  if (j.state === "stopped") $("docs-pinfo").innerHTML += "<br>已停止，未下载的文件没有写入。";
  if (DOCS.mode === "hw") {
    HWD.sel.clear();
    hwdPaintList();
    hwdPaintSel();
  } else {
    DOCS.sel.clear();
    docsPaintList();
    docsPaintSel();
  }
  // 成功后顺手打开文件夹，省得用户自己找
  if (ok && j.dir) docsApi("/docs/open", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ dir: j.dir }) }).catch(() => {});
}

async function docsPickDir() {
  const btn = $("btn-docs-pick");
  btn.disabled = true;
  toast("已弹出文件夹选择窗口，请到任务栏找一下");
  try {
    const j = await docsApi("/docs/pickdir", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dir: $("docs-dir").value.trim() }),
    });
    if (j.dir) {
      DOCS.dir = j.dir;
      $("docs-dir").value = j.dir;
      try { localStorage.setItem("cxball.docs.dir", j.dir); } catch { /* 忽略 */ }
      toast("保存位置已设置");
    } else {
      toast("没有选择文件夹");
    }
  } catch (e) {
    toast(e.message || "打开选择窗口失败");
  } finally {
    btn.disabled = false;
  }
}

async function docsOpenDir() {
  const dir = $("docs-dir").value.trim();
  if (!dir) { toast("还没有设置保存文件夹"); return; }
  try {
    const j = await docsApi("/docs/open", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ dir }),
    });
    if (!j.ok) toast("打不开这个路径，可能不存在");
  } catch (e) {
    toast(e.message || "打开失败");
  }
}

// ---------- 作业附件下载（本地桥 /hw/*） ----------
// 为什么单独做一块：作业页里的附件是「云附件 iframe」，点开是在线预览，
// 真正的下载按钮要页面脚本放行，悬浮球的宿主又没接管下载事件，所以点了多半没反应。
// 这里由小桥用 Cookie 直接读作业页 HTML，拿到云盘 objectid，再取直链流式落盘。

/// 当前课程下的作业：同一个 work 可能在快照里出现两条（/work/task 和 examApi），
/// 只留能直接读到附件页的那种，保证点开就是作业正文。
function hwdAssignments(courseId) {
  const all = (S.snapshot?.items || []).filter((it) => it.type === "assignment" && it.link);
  const byWork = new Map();
  for (const it of all) {
    if (courseId && String(it.courseId || "") !== String(courseId)) continue;
    const wid = workIdOf(it.link) || it.link;
    const cur = byWork.get(wid);
    const good = /\/work\/task/i.test(it.link);
    if (!cur || (good && !/\/work\/task/i.test(cur.link))) byWork.set(wid, { ...it, workId: wid });
  }
  const list = [...byWork.values()];
  // 最近布置的排前面（截止时间越晚越新）
  list.sort((a, b) => (b.deadline || 0) - (a.deadline || 0));
  return list;
}

function hwdPaintSel() {
  const n = HWD.sel.size;
  const btn = $("btn-docs-dl");
  if (DOCS.mode === "hw") btn.textContent = `下载附件 (${n})`;
  btn.disabled = !n || !!DOCS.taskId;
}

function hwdPaintList() {
  const box = $("hwd-list");
  if (!HWD.items.length) {
    box.innerHTML = '<div class="doc-empty">这份作业没有附件（纯文本题目，或附件在正文图片里）</div>';
    return;
  }
  box.innerHTML = HWD.items
    .map((it, i) => {
      const on = HWD.sel.has(i);
      const tag = it.kind === "mine" ? "我的提交" : "老师附件";
      const meta = [it.size, tag].filter(Boolean).join(" · ");
      return (
        `<div class="doc-row${on ? " on" : ""}" data-i="${i}">` +
        `<input class="doc-ck" type="checkbox" ${on ? "checked" : ""} tabindex="-1">` +
        `<span class="doc-ico">${DOC_ICON(it.name)}</span>` +
        `<div class="doc-main"><div class="doc-name">${escapeHtml(it.name)}</div>` +
        `<div class="doc-meta">${escapeHtml(meta)}</div></div></div>`
      );
    })
    .join("");
  hwdPaintSel();
}

/// 切课程时重建「作业」下拉，并自动读第一份（或右键指定的那份）的附件
async function hwdCourseChanged() {
  const cid = DOCS.cur ? String(DOCS.cur.courseId) : "";
  HWD.list = hwdAssignments(cid);
  HWD.cur = null;
  HWD.items = [];
  HWD.sel.clear();
  const sel = $("hwd-sel");
  if (!HWD.list.length) {
    sel.innerHTML = '<option value="">（这门课没有作业）</option>';
    hwdPaintList();
    hwdPaintSel();
    return;
  }
  const p = (y) => String(y).padStart(2, "0");
  sel.innerHTML = HWD.list
    .map((a, i) => {
      const d = a.deadline ? new Date(a.deadline) : null;
      const tail = d ? `（${p(d.getMonth() + 1)}-${p(d.getDate())} 截止）` : "";
      return `<option value="${i}">${escapeHtml((a.title || "作业") + tail)}</option>`;
    })
    .join("");

  let pick = 0;
  if (HWD.pending && HWD.pending.workId) {
    const i = HWD.list.findIndex((a) => String(a.workId) === String(HWD.pending.workId));
    if (i >= 0) pick = i;
  } else {
    try {
      const last = localStorage.getItem("cxball.hwd.work");
      const i = HWD.list.findIndex((a) => String(a.workId) === last);
      if (i >= 0) pick = i;
    } catch { /* 忽略 */ }
  }
  HWD.pending = null;
  sel.value = String(pick);
  await hwdLoad();
}

async function hwdLoad() {
  const a = HWD.list[Number($("hwd-sel").value || 0)];
  if (!a) return;
  HWD.cur = a;
  HWD.sel.clear();
  HWD.items = [];
  $("btn-docs-dl").disabled = true;
  $("hwd-list").innerHTML = '<div class="doc-empty">正在读取作业页…</div>';
  try {
    const j = await docsApi("/hw/attach", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ link: a.link }),
    });
    // 老师给的在前，自己的提交在后
    HWD.items = [
      ...(j.teacher || []).map((x) => ({ ...x, kind: "teacher" })),
      ...(j.mine || []).map((x) => ({ ...x, kind: "mine" })),
    ];
    try { localStorage.setItem("cxball.hwd.work", String(a.workId || "")); } catch { /* 忽略 */ }
    hwdPaintList();
  } catch (e) {
    $("hwd-list").innerHTML = `<div class="doc-empty">${escapeHtml(e.message)}</div>`;
    if (e.code === "NO_LOGIN") docsPaintPill("登录失效", false);
  }
}

function hwdToggle(i) {
  if (DOCS.taskId) { toast("正在下载，等这次结束再改选择"); return; }
  const it = HWD.items[i];
  if (!it) return;
  if (HWD.sel.has(i)) HWD.sel.delete(i);
  else HWD.sel.add(i);
  hwdPaintList();
}

function hwdSelectAll() {
  if (DOCS.taskId) return;
  if (!HWD.items.length) { toast("这份作业没有附件"); return; }
  const allOn = HWD.items.every((_, i) => HWD.sel.has(i));
  HWD.sel.clear();
  if (!allOn) HWD.items.forEach((_, i) => HWD.sel.add(i));
  hwdPaintList();
}

async function hwdDownload() {
  const files = [...HWD.sel]
    .sort((a, b) => a - b)
    .map((i) => HWD.items[i])
    .filter(Boolean)
    .map((x) => ({ id: x.id, href: x.href, name: x.name }));
  if (!files.length) { toast("先选中要下载的附件"); return; }
  const dir = $("docs-dir").value.trim();
  if (!dir) { toast("请先选择保存文件夹"); return; }
  DOCS.dir = dir;
  try { localStorage.setItem("cxball.docs.dir", dir); } catch { /* 忽略 */ }
  $("btn-docs-dl").disabled = true;
  try {
    const j = await docsApi("/hw/download", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        courseName: DOCS.cur?.name || "作业附件",
        hwName: HWD.cur?.title || "作业附件",
        dir,
        flat: !$("docs-subdir").checked,
        files,
      }),
    });
    DOCS.taskId = j.taskId;
    $("btn-docs-stop").classList.remove("hidden");
    $("btn-docs-stop").disabled = false;
    docsProgressPaint({ state: "running", total: files.length, done: 0, failed: 0, current: "", fileBytes: 0, fileTotal: 0 });
    docsPoll();
  } catch (e) {
    $("btn-docs-dl").disabled = false;
    toast(e.message || "下载失败");
  }
}

/// 切换「课程资料 / 作业附件」
function docsSetMode(m) {
  DOCS.mode = m === "hw" ? "hw" : "files";
  $("btn-tab-files").classList.toggle("on", DOCS.mode === "files");
  $("btn-tab-hw").classList.toggle("on", DOCS.mode === "hw");
  $("docs-pane-files").classList.toggle("hidden", DOCS.mode !== "files");
  $("docs-pane-hw").classList.toggle("hidden", DOCS.mode !== "hw");
  $("docs-hint").innerHTML =
    DOCS.mode === "hw"
      ? "附件直接来自作业页本身（老师发的 + 你自己提交的），通过云盘直链下载，不会改动线上任何内容。"
      : "资料列表来自学习通「课程 → 资料」，只读取和下载，不会改动线上任何内容。";
  try { localStorage.setItem("cxball.docs.mode", DOCS.mode); } catch { /* 忽略 */ }
  if (DOCS.mode === "hw") hwdPaintSel();
  else docsPaintSel();
}

/// 主面板右键「下载附件」→ 直接进作业附件页并定位到这份作业
function hwdOpenFor(it) {
  HWD.pending = { courseId: String(it.courseId || ""), workId: workIdOf(it.link), title: it.title };
  docsEnter("hw");
}

/// 小桥可能还在启动（启动脚本是先后台起 bridge.js 再开窗口），所以这里等几秒再判定，
/// 免得刚开机那会儿手快点进来就被判成"没运行"。
async function docsPingWait(tries = 6, gap = 1200) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(DOCS.base + "/ping", { cache: "no-store" });
      return await r.json();
    } catch {
      await new Promise((r) => setTimeout(r, gap));
    }
  }
  return null;
}

async function docsEnter(forceMode) {
  $("docs-dir").value = DOCS.dir || $("docs-dir").value || "";
  if (!DOCS.dir) {
    try { DOCS.dir = localStorage.getItem("cxball.docs.dir") || ""; } catch { /* 忽略 */ }
    $("docs-dir").value = DOCS.dir;
  }
  // 没指定就用上次的模式（右键「下载附件」进来会强制 homework 模式）
  let mode = forceMode;
  if (!mode) {
    try { mode = localStorage.getItem("cxball.docs.mode") || "files"; } catch { mode = "files"; }
  }
  docsSetMode(mode);
  switchView("view-panel", "view-docs");
  docsPaintPill("连接中…", false);
  const p = await docsPingWait();
  if (!p) {
    DOCS.ok = false;
    docsPaintPill("未启动", false);
    // 别让下拉一直停在"加载中…"，给出能看懂的状态和一个重试入口
    $("docs-course").innerHTML = '<option value="">（还没连上）</option>';
    $("docs-list").innerHTML =
      '<div class="doc-empty">课程列表还没读出来。<br>' +
      "先关掉悬浮球窗口，再从桌面的「学习通悬浮球」图标重新打开一次，然后点下面的「重新连接」。</div>";
    $("docs-hint").innerHTML =
      '<button class="btn btn-ghost btn-sm" id="btn-docs-retry">重新连接</button>' +
      '<span class="hint-inline">重开一次通常就能连上</span>';
    const rb = $("btn-docs-retry");
    if (rb) rb.onclick = () => docsEnter(forceMode);
    return;
  }
  DOCS.ok = true;
  // 上次可能留了个「重试连接小桥」按钮，连上了就换回默认说明
  const hintEl = $("docs-hint");
  if (hintEl && $("btn-docs-retry")) {
    hintEl.innerHTML = "资料列表来自学习通「课程 → 资料」，只读取和下载，不会改动线上任何内容。";
  }
  if (p.hwFiles) docsPaintPill("已就绪", true);
  else if (p.docs) docsPaintPill("部分可用", false);
  else docsPaintPill("部分可用", false);
  if (!DOCS.courses.length) await docsLoadCourses();
  else {
    // 每次进来按最新的课程勾选重排下拉（设置页可能刚改过）
    const keepId = HWD.pending?.courseId || (DOCS.cur ? String(DOCS.cur.courseId) : "");
    docsPaintCourses();
    const idx = Math.max(0, DOCS.shown.findIndex((c) => String(c.courseId) === keepId));
    if (DOCS.shown.length) {
      $("docs-course").value = String(idx);
      const changed = !DOCS.cur || String(DOCS.shown[idx].courseId) !== String(DOCS.cur.courseId);
      if (changed || HWD.pending) await docsOpenCourse(idx);
      else if (DOCS.mode === "hw") await hwdCourseChanged();
    }
    docsPaintSel();
    hwdPaintSel();
  }
}

$("btn-docs").onclick = () => docsEnter();
$("btn-docs-back").onclick = () => { switchView("view-docs", "view-panel"); renderPanel(); };
$("btn-tab-files").onclick = () => {
  if (DOCS.taskId) { toast("正在下载，等这次结束再切换"); return; }
  docsSetMode("files");
  if (DOCS.cur && !DOCS.items.length) docsLoadDir();
  else if (DOCS.cur) docsCrumb();
};
$("btn-tab-hw").onclick = async () => {
  if (DOCS.taskId) { toast("正在下载，等这次结束再切换"); return; }
  docsSetMode("hw");
  // 切过来时作业列表可能是空的（刚进面板时没建过），这里补一次
  if (!HWD.list.length || String(HWD.list[0]?.courseId || "") !== String(DOCS.cur?.courseId || "")) await hwdCourseChanged();
};
$("hwd-sel").onchange = () => {
  if (DOCS.taskId) { toast("正在下载，先停止再切换作业"); return; }
  hwdLoad();
};
$("hwd-list").onclick = (e) => {
  const row = e.target.closest(".doc-row");
  if (!row) return;
  hwdToggle(Number(row.dataset.i));
};
$("btn-hwd-all").onclick = hwdSelectAll;
$("btn-hwd-none").onclick = () => {
  if (DOCS.taskId) return;
  HWD.sel.clear();
  hwdPaintList();
};
$("btn-hwd-reload").onclick = () => {
  if (DOCS.taskId) { toast("正在下载，等这次结束再读取"); return; }
  hwdLoad();
};
$("btn-docs-filter").onclick = dfOpen;
$("btn-df-cancel").onclick = dfClose;
$("btn-df-ok").onclick = dfCommit;
$("btn-df-all").onclick = () => {
  DF.draft = new Set(DF.all.map((c) => c.id));
  $("df-list").querySelectorAll("input").forEach((cb) => { cb.checked = true; });
};
$("btn-df-none").onclick = () => {
  DF.draft.clear();
  $("df-list").querySelectorAll("input").forEach((cb) => { cb.checked = false; });
};
$("docs-filter-overlay").onclick = (e) => { if (e.target === $("docs-filter-overlay")) dfClose(); };
$("docs-course").onchange = (e) => {
  if (DOCS.taskId) { toast("正在下载，先停止再切换课程"); return; }
  docsOpenCourse(Number(e.target.value));
};
$("docs-list").onclick = (e) => {
  const row = e.target.closest(".doc-row");
  if (!row) return;
  const it = DOCS.items[Number(row.dataset.i)];
  if (!it) return;
  if (it.folder) {
    if (it.online) { toast("「教师课件」是在线课件，请在学习通网页里打开"); return; }
    if (DOCS.taskId) { toast("正在下载，先停止再换目录"); return; }
    DOCS.path.push({ id: it.id, name: it.name });
    docsLoadDir();
  } else {
    docsToggle(it);
  }
};
$("btn-docs-all").onclick = docsSelectAll;
$("btn-docs-none").onclick = () => {
  if (DOCS.taskId) return;
  DOCS.sel.clear();
  docsPaintList();
  docsPaintSel();
};
$("btn-docs-reload").onclick = () => docsLoadDir();
$("btn-docs-pick").onclick = docsPickDir;
$("btn-docs-open").onclick = docsOpenDir;
$("btn-docs-dl").onclick = docsDownload;
$("btn-docs-stop").onclick = async () => {
  if (!DOCS.taskId) return;
  $("btn-docs-stop").disabled = true;
  try {
    await docsApi("/docs/stop", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: DOCS.taskId }),
    });
    toast("正在停止…");
  } catch { /* 忽略 */ }
};
$("docs-dir").onchange = () => {
  DOCS.dir = $("docs-dir").value.trim();
  try { localStorage.setItem("cxball.docs.dir", DOCS.dir); } catch { /* 忽略 */ }
};
$("docs-subdir").onchange = () => {
  try { localStorage.setItem("cxball.docs.subdir", $("docs-subdir").checked ? "1" : "0"); } catch { /* 忽略 */ }
};
try {
  if (localStorage.getItem("cxball.docs.subdir") === "0") $("docs-subdir").checked = false;
  DOCS.dir = localStorage.getItem("cxball.docs.dir") || "";
  $("docs-dir").value = DOCS.dir;
} catch { /* 忽略 */ }

// ---------- 课程讨论（独立窗口） ----------
// 宿主没有抓取讨论区的接口，也不允许跨域读 chaoxing.com，所以讨论数据由用户粘贴群消息、
// 经 AI 拆成结构化记录后存本机。这里只负责把独立窗口打开；宿主拦截弹窗时降级为面板内整页 iframe。
const DISCUSS_URL = "discuss.html?v=6";

function openDiscuss() {
  let w = null;
  try {
    w = window.open(DISCUSS_URL, "cxball-discuss", "width=480,height=720,menubar=no,toolbar=no,location=no,status=no");
  } catch { w = null; }
  if (w && !w.closed) {
    try { w.focus(); } catch { /* 跨窗口聚焦失败可忽略 */ }
    return;
  }
  // 弹窗被拦截：用面板内整页 iframe 兜底，功能与独立窗口一致
  $("discuss-frame").src = DISCUSS_URL;
  $("discuss-host").classList.remove("hidden");
}

$("btn-discuss").onclick = openDiscuss;

window.addEventListener("message", (e) => {
  if (e.data?.type === "cxball-discuss-close") $("discuss-host").classList.add("hidden");
});

$("btn-ai").onclick = () => aiEnter();
$("btn-ai-back").onclick = () => { switchView("view-ai", "view-panel"); renderPanel(); };
$("btn-ai-solve").onclick = aiSolve;
$("btn-ai-stop").onclick = () => AI.ctrl?.abort();
$("btn-ai-clear").onclick = () => {
  $("ai-input").value = "";
  AI.images = []; aiPaintThumbs();
  AI.raw = "";
  $("ai-result").innerHTML = '<div class="empty-tip">粘贴题目后点「求解」</div>';
  $("ai-input").focus();
};
$("btn-ai-copy").onclick = () => {
  const t = aiAnswerText();
  if (!t) { toast("还没有结果"); return; }
  copyText(t);
  toast("答案已复制");
};
$("ai-cfg-title").onclick = () => aiToggleCfg();
$("hw-verify").onchange = () => aiSaveCfg({ verify: $("hw-verify").checked });
$("usage-title").onclick = () => {
  const body = $("usage-body");
  const open = body.classList.toggle("hidden");
  $("usage-arrow").textContent = open ? "▸" : "▾";
  usagePaint();
  if (!open) usageBalance();
};
$("btn-usage-refresh").onclick = () => usageBalance(true);
$("btn-usage-reset").onclick = () => {
  if (!confirm("清零本机记录的 token 与费用统计？（不影响账户余额）")) return;
  USAGE.acc = { calls: 0, pt: 0, ct: 0, cost: 0, days: {} };
  USAGE.cur = null;
  try { localStorage.removeItem(USAGE_KEY); } catch { /* 忽略 */ }
  usagePaint();
  toast("统计已清零");
};
$("ai-provider").onchange = (e) => {
  const p = AI_PRESETS[e.target.value];
  if (!p) return;
  $("ai-base").value = p.baseUrl;
  $("ai-model").value = p.models[0] || "";
  aiFillModels(p.models);
};
$("ai-kind").onchange = (e) => aiSaveCfg({ kind: e.target.value });
$("ai-mode").onchange = (e) => aiSaveCfg({ mode: e.target.value });
$("btn-ai-save").onclick = () => {
  const f = aiReadForm();
  if (f.baseUrl && !/^https?:\/\//i.test(f.baseUrl)) { toast("接口地址需以 http:// 或 https:// 开头"); return; }
  aiSaveCfg(f);
  toast("已保存");
};
$("btn-ai-test").onclick = aiTest;
$("btn-ai-paste").onclick = () => aiReadClip(true);

// 截图直接 Ctrl+V：拦截纯图片粘贴，走压缩后入列；文本粘贴保持默认行为
$("ai-input").addEventListener("paste", (e) => {
  const files = [...(e.clipboardData?.items || [])]
    .filter((i) => i.kind === "file" && /^image\//.test(i.type))
    .map((i) => i.getAsFile())
    .filter(Boolean);
  if (!files.length) return;
  e.preventDefault();
  files.slice(0, 3).forEach(aiAddImage);
});
$("ai-input").addEventListener("dragover", (e) => e.preventDefault());
$("ai-input").addEventListener("drop", (e) => {
  const files = [...(e.dataTransfer?.files || [])].filter((f) => /^image\//.test(f.type));
  if (!files.length) return;
  e.preventDefault();
  files.slice(0, 3).forEach(aiAddImage);
});
// Ctrl+Enter 快速求解
$("ai-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) { e.preventDefault(); aiSolve(); }
});

// ---------- 启动 ----------
async function reloadInit() {
  const r = await bridge.call("app.init");
  S.settings = r.settings;
  if (r.loggedIn) {
    S.account = r.account;
    S.snapshot = r.snapshot || S.snapshot;
    (S.account.state ??= {});
  }
  return r;
}

(async () => {
  // 宿主每次启动面板都是 400x640，所以页面按 zoom=1 起步；上次调过大小的话下面会再恢复一次。
  applyZoom(WIN_W);
  const r = await reloadInit();
  if (r.loggedIn) {
    show("view-panel");
    renderPanel();
    // §3.3 / §4.1：启动恢复会话算一次登录事件 → 按设置自动刷新（登录冷却内静默沿用旧快照）
    if (S.settings?.loginAutoRefresh !== false) doRefresh({ login: true, quiet: true });
  } else {
    if (r.sessionExpired) toast("登录状态已失效，请重新登录");
    show("view-login");
  }
  // 每次都按保存的比例对一次窗口（宿主启动时是默认 400x640，窗口尺寸得靠这里恢复）。
  // 启动时面板可能还是关着的（改不了），所以错开重试几次；之后面板一获得焦点 winSync 还会再补。
  // 每次启动先对一次窗口尺寸
  [900, 2500, 5000].forEach((ms) => setTimeout(() => winSync(), ms));
  // 起来一会儿后静默看一眼有没有新版本：不打扰，只在真有新版时冒一句提示
  setTimeout(() => { updInit().then((ok) => { if (ok) updCheck(true); }); }, 8000);
})();
